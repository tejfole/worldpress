(function () {
    'use strict';

    function checkboxGroupItems(form, key) {
        return Array.prototype.slice.call(form.querySelectorAll('input[data-szegbp-checkbox-group-item="' + key.replace(/"/g, '\\"') + '"]'));
    }

    function getFieldValue(form, key) {
        var matrix = Array.prototype.slice.call(form.querySelectorAll('input[data-szegbp-matrix-item="' + key.replace(/"/g, '\"') + '"]'));
        if (matrix.length) {
            return matrix.filter(function (item) { return item.checked; })
                .map(function (item) { return item.getAttribute('data-cell-label') || ''; })
                .filter(Boolean)
                .join(', ');
        }
        var group = checkboxGroupItems(form, key);
        if (group.length) {
            return group.filter(function (item) { return item.checked; })
                .map(function (item) { return item.getAttribute('data-option-label') || item.value || ''; })
                .filter(Boolean)
                .join(', ');
        }
        var field = form.elements['fields[' + key + ']'];
        if (!field) {
            return '';
        }
        if (field.tagName && field.tagName.toLowerCase() === 'select') {
            return field.selectedIndex > 0 ? field.options[field.selectedIndex].text : '';
        }
        if (typeof field.length === 'number' && !field.tagName) {
            var checkedRadio = Array.prototype.find.call(field, function (item) { return item.checked; });
            if (checkedRadio) {
                return checkedRadio.getAttribute('data-option-label') || checkedRadio.value || '';
            }
            return '';
        }
        if ((field.type || '').toLowerCase() === 'radio') {
            var selected = form.querySelector('input[name="fields[' + key.replace(/"/g, '\"') + ']"]:checked');
            return selected ? (selected.getAttribute('data-option-label') || selected.value || '') : '';
        }
        if ((field.type || '').toLowerCase() === 'checkbox') {
            return field.checked ? '☒' : '☐';
        }
        return field.value || '';
    }

    function updatePreview(box) {
        var form = box.querySelector('form.szegbp-form');
        if (!form) {
            return;
        }
        box.querySelectorAll('[data-preview-field]').forEach(function (target) {
            var key = target.getAttribute('data-preview-field');
            var value = getFieldValue(form, key).trim();
            target.textContent = value || '—';
        });

        var frame = box.querySelector('[data-szegbp-html-preview-frame]');
        var htmlTemplate = box.querySelector('template[data-szegbp-pdf-html-template]');
        if (frame && htmlTemplate && htmlTemplate.innerHTML.trim() !== '') {
            var labels = {};
            try {
                labels = JSON.parse(box.getAttribute('data-preview-labels') || '{}');
            } catch (e) {
                labels = {};
            }
            frame.srcdoc = fillHtmlTemplate(htmlTemplate.innerHTML, collectFields(form), labels, box);
        }
    }

    function formatDate(value) {
        if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
            return value || '';
        }
        var parts = value.split('-');
        return parts[0] + '. ' + parts[1] + '. ' + parts[2] + '.';
    }

    function fileSafe(value) {
        return (value || '')
            .toString()
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '') || 'szegbp-nyomtatvany';
    }

    function valueOrLine(value, chars) {
        value = (value || '').toString().trim();
        if (value !== '') {
            return value;
        }
        return '…'.repeat(chars || 18);
    }

    function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
        text = (text || '').toString().replace(/\s+/g, ' ').trim();
        if (text === '') {
            return y;
        }
        var words = text.split(' ');
        var line = '';
        for (var n = 0; n < words.length; n += 1) {
            var testLine = line ? line + ' ' + words[n] : words[n];
            if (ctx.measureText(testLine).width > maxWidth && line) {
                ctx.fillText(line, x, y);
                line = words[n];
                y += lineHeight;
            } else {
                line = testLine;
            }
        }
        if (line) {
            ctx.fillText(line, x, y);
            y += lineHeight;
        }
        return y;
    }

    function drawCentered(ctx, text, x, y, width) {
        var oldAlign = ctx.textAlign;
        ctx.textAlign = 'center';
        ctx.fillText(text, x + width / 2, y);
        ctx.textAlign = oldAlign;
    }

    function drawSignature(ctx, x, y, width, caption) {
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + width, y);
        ctx.stroke();
        ctx.font = '20px Arial, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(caption, x + width / 2, y + 30);
        ctx.textAlign = 'left';
    }

    function collectFields(form) {
        var data = {};
        Array.prototype.forEach.call(form.querySelectorAll('[name^="fields["]'), function (field) {
            if (field.matches('[data-szegbp-matrix-item]')) {
                var matrixName = field.getAttribute('data-szegbp-matrix-item') || '';
                var matrixToken = field.getAttribute('data-option-token') || '';
                if (matrixToken) { data[matrixToken] = field.checked ? '☒' : '☐'; }
                if (!Object.prototype.hasOwnProperty.call(data, matrixName)) { data[matrixName] = ''; }
                if (field.checked) {
                    var cellLabel = field.getAttribute('data-cell-label') || '';
                    data[matrixName] = data[matrixName] ? data[matrixName] + ', ' + cellLabel : cellLabel;
                }
                return;
            }
            var groupMatch = field.name.match(/^fields\[([^\]]+)\]\[\]$/);
            if (groupMatch && field.matches('[data-szegbp-checkbox-group-item]')) {
                var groupKey = groupMatch[1];
                if (!Object.prototype.hasOwnProperty.call(data, groupKey)) {
                    data[groupKey] = getFieldValue(form, groupKey);
                }
                var token = field.getAttribute('data-option-token') || '';
                if (token) {
                    data[token] = field.checked ? '☒' : '☐';
                }
                return;
            }
            var match = field.name.match(/^fields\[([^\]]+)\]$/);
            if (!match) {
                return;
            }
            if ((field.type || '').toLowerCase() === 'radio' && (field.hasAttribute('data-szegbp-underline-choice-item') || field.hasAttribute('data-szegbp-radio-item'))) {
                var radioKey = match[1];
                var radioToken = radioKey + '_' + String(field.value || '').toLowerCase().replace(/[^a-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
                if (field.checked) {
                    data[radioKey] = field.getAttribute('data-option-label') || field.value || '';
                    data[radioKey + '__key'] = field.value || '';
                } else if (!Object.prototype.hasOwnProperty.call(data, radioKey)) {
                    data[radioKey] = '';
                    data[radioKey + '__key'] = '';
                }
                if (field.hasAttribute('data-szegbp-radio-item') && radioToken) { data[radioToken] = field.checked ? '☒' : '☐'; }
                return;
            }
            var fieldKey = match[1];
            data[fieldKey] = getFieldValue(form, fieldKey);
            if (field.tagName && field.tagName.toLowerCase() === 'select') {
                var selectedOption = field.selectedIndex >= 0 ? field.options[field.selectedIndex] : null;
                data[fieldKey + '__key'] = selectedOption && field.selectedIndex > 0 ? (selectedOption.value || '') : '';
            }
        });
        return data;
    }

    function escapeHtml(value) {
        return (value || '').toString()
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function getTemplateValue(data, key, labels, box) {
        if (key === '_form_title') {
            return (box.querySelector('.szegbp-form-header h2') || {}).textContent || 'Iskolai nyomtatvány';
        }
        if (key === '_form_description') {
            var headerParagraph = box.querySelector('.szegbp-form-header p:not(.szegbp-forms-eyebrow):not(.szegbp-forms-privacy-note)');
            return headerParagraph ? headerParagraph.textContent : '';
        }
        var value = data[key] || '';
        if (/datuma|datum|ervenyes/i.test(key)) {
            value = formatDate(value);
        }
        return value;
    }

    function getChoiceOptions(box, key) {
        var all = {};
        try { all = JSON.parse(box.getAttribute('data-choice-options') || '{}') || {}; } catch (e) { all = {}; }
        return all[key] && typeof all[key] === 'object' ? all[key] : {};
    }

    function underlineChoiceHtml(key, explicitFirst, explicitSecond, data, box) {
        var options = getChoiceOptions(box, key);
        var optionKeys = Object.keys(options);
        var first = explicitFirst || (optionKeys[0] ? options[optionKeys[0]] : 'Igen');
        var second = explicitSecond || (optionKeys[1] ? options[optionKeys[1]] : 'Nem');
        var selectedKey = data[key + '__key'] || '';
        var selectedLabel = (data[key] || '').toString();
        var firstSelected = !!((optionKeys[0] && (selectedKey === optionKeys[0] || selectedLabel === options[optionKeys[0]])) || selectedLabel === first);
        var secondSelected = !!((optionKeys[1] && (selectedKey === optionKeys[1] || selectedLabel === options[optionKeys[1]])) || selectedLabel === second);
        var firstHtml = '<span' + (firstSelected ? ' style="text-decoration:underline;text-decoration-thickness:1px;text-underline-offset:2px;"' : '') + '>' + escapeHtml(first) + '</span>';
        var secondHtml = '<span' + (secondSelected ? ' style="text-decoration:underline;text-decoration-thickness:1px;text-underline-offset:2px;"' : '') + '>' + escapeHtml(second) + '</span>';
        return firstHtml + ' / ' + secondHtml;
    }

    function fillHtmlTemplate(templateHtml, data, labels, box) {
        var html = templateHtml.replace(/\{\{\s*underline_choice:([a-zA-Z0-9_\-]+)(?:\|([^{}|]*?)\|([^{}]*?))?\s*\}\}/g, function (match, key, first, second) {
            return underlineChoiceHtml(key, (first || '').trim(), (second || '').trim(), data, box);
        });
        return html.replace(/\{\{\s*([a-zA-Z0-9_\-]+)\s*\}\}/g, function (match, key) {
            return escapeHtml(getTemplateValue(data, key, labels, box));
        });
    }

    function loadDocument(frame, html) {
        return new Promise(function (resolve, reject) {
            var timer = setTimeout(function () { cleanup(); reject(new Error('A dokumentum betöltése túllépte az időkorlátot.')); }, 15000);
            function cleanup() { clearTimeout(timer); frame.removeEventListener('load', loaded); }
            async function loaded() {
                try {
                    var doc = frame.contentDocument;
                    if (doc.fonts) { await doc.fonts.ready; }
                    await Promise.all(Array.from(doc.images).map(function (img) {
                        if (img.complete) { if (!img.naturalWidth) { throw new Error('Nem tölthető be egy dokumentumkép.'); } return; }
                        return new Promise(function (ok, fail) { img.onload = ok; img.onerror = function () { fail(new Error('Nem tölthető be egy dokumentumkép.')); }; });
                    }));
                    cleanup(); resolve(doc);
                } catch (error) { cleanup(); reject(error); }
            }
            frame.addEventListener('load', loaded);
            frame.srcdoc = html;
        });
    }

    function blobToDataUrl(blob) {
        return new Promise(function (resolve, reject) {
            var reader = new FileReader();
            reader.onload = function () { resolve(reader.result); };
            reader.onerror = function () { reject(new Error('Egy dokumentumerőforrást nem sikerült beágyazni.')); };
            reader.readAsDataURL(blob);
        });
    }

    async function inlineDocumentResources(doc) {
        var links = Array.from(doc.querySelectorAll('link[rel~="stylesheet"]'));
        for (var i = 0; i < links.length; i += 1) {
            var link = links[i];
            try {
                var rules = link.sheet && link.sheet.cssRules ? Array.from(link.sheet.cssRules).map(function (rule) { return rule.cssText; }).join('\n') : '';
                if (!rules.trim()) {
                    var href = link.href || link.getAttribute('href') || '';
                    if (!href) { throw new Error('hiányzó CSS-hivatkozás'); }
                    var cssResponse = await fetch(href, { credentials: 'same-origin' });
                    if (!cssResponse.ok) { throw new Error('HTTP ' + cssResponse.status); }
                    rules = await cssResponse.text();
                }
                var style = doc.createElement('style');
                style.textContent = rules;
                doc.head.appendChild(style);
                link.remove();
            } catch (error) {
                throw new Error('A HTML sablon külső stíluslapját nem lehet a PDF-be beágyazni. Importáld a HTML-t önálló, beágyazott CSS-sel.');
            }
        }

        var images = Array.from(doc.images);
        for (var n = 0; n < images.length; n += 1) {
            var img = images[n];
            var src = img.getAttribute('src') || '';
            if (!src || /^data:/i.test(src)) { continue; }
            try {
                var response = await fetch(img.src, { credentials: 'same-origin' });
                if (!response.ok) { throw new Error('HTTP ' + response.status); }
                var blob = await response.blob();
                img.setAttribute('src', await blobToDataUrl(blob));
            } catch (error) {
                throw new Error('A HTML sablon egyik képe nem ágyazható be a PDF-be. Használj azonos domainről elérhető vagy data URL-ként beágyazott képet.');
            }
        }
    }

    async function canvasFromHtmlTemplate(box, form, templateHtml, dataOverride) {
        var data = dataOverride || collectFields(form);
        var html = fillHtmlTemplate(templateHtml, data, {}, box);
        var frame = document.createElement('iframe');
        frame.setAttribute('sandbox', 'allow-same-origin');
        frame.style.cssText = 'position:fixed;left:-10000px;top:0;width:794px;height:1123px;border:0;';
        document.body.appendChild(frame);
        try {
            var doc = await loadDocument(frame, html);
            var reset = doc.createElement('style');
            reset.textContent = 'html,body{margin:0!important;padding:0!important;background:#fff!important}';
            doc.head.appendChild(reset);
            await inlineDocumentResources(doc);
            var bottom = Math.max(doc.body.scrollHeight, doc.documentElement.scrollHeight);
            var right = Math.max(doc.body.scrollWidth, doc.documentElement.scrollWidth);
            Array.from(doc.body.querySelectorAll('*')).forEach(function (el) {
                var rect = el.getBoundingClientRect();
                bottom = Math.max(bottom, rect.bottom); right = Math.max(right, rect.right);
            });
            // A közvetlen PDF-generátor jelenleg egyetlen A4 oldalt készít.
            // Kis renderelési eltérést tolerálunk, de többoldalas tartalomnál látható hibát adunk.
            if (bottom > 1127 || right > 798) {
                throw new Error('A közvetlen Kitöltött PDF jelenleg egyetlen A4 oldalt támogat. A dokumentum ennél hosszabb vagy szélesebb; használd a Nyomtatás gombot (Mentés PDF-ként), amely több oldalt is tud kezelni.');
            }
            // HTML DOM -> XML: br, img és a HTML-entitások is szabályos XHTML-ként kerülnek az SVG-be.
            var xhtml = new XMLSerializer().serializeToString(doc.documentElement);
            var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="794" height="1123"><foreignObject width="100%" height="100%">' + xhtml + '</foreignObject></svg>';
            var img = await new Promise(function (resolve, reject) {
                var image = new Image();
                image.onload = function () { resolve(image); };
                image.onerror = function () { reject(new Error('A HTML sablonból nem sikerült képet készíteni.')); };
                image.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
            });
            var canvas = document.createElement('canvas');
            canvas.width = 1240; canvas.height = 1754;
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            return canvas;
        } finally { frame.remove(); }
    }

    function drawTestnevelesPdf(form) {
        var data = collectFields(form);
        var canvas = document.createElement('canvas');
        var w = 1240;
        var h = 1754;
        canvas.width = w;
        canvas.height = h;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#111111';
        ctx.strokeStyle = '#111111';
        ctx.lineWidth = 2;
        ctx.textBaseline = 'top';

        var m = 92;
        var y = 76;
        var contentW = w - 2 * m;

        ctx.font = '23px Arial, sans-serif';
        ctx.fillText(valueOrLine(data.igazgato_neve, 16) + ' igazgató részére', m, y);
        ctx.textAlign = 'right';
        ctx.fillText('Intézményi ikt.sz.: ' + valueOrLine(data.iktatoszam, 10), w - m, y);
        ctx.textAlign = 'left';
        y += 42;

        ctx.font = '22px Arial, sans-serif';
        ctx.fillText('Budapest I. Kerületi Szilágyi Erzsébet Gimnázium', m, y); y += 30;
        ctx.fillText('OM: 035219', m, y); y += 30;
        ctx.fillText('1016 Budapest, Mészáros utca 5-7.', m, y); y += 72;

        ctx.font = 'bold 34px Arial, sans-serif';
        drawCentered(ctx, 'Felmentési kérelem', m, y, contentW);
        y += 46;
        ctx.font = 'bold 23px Arial, sans-serif';
        drawCentered(ctx, 'a mindennapos testnevelés keretében megszervezett tanórán való részvétel alól', m, y, contentW);
        y += 76;

        ctx.font = '24px Arial, sans-serif';
        var p1 = 'Alulírott ' + valueOrLine(data.szulo_neve, 24) + ' (szülő) a 2011. évi CXC. törvény 27. § (11) bekezdése alapján kérem hozzájárulását, hogy ' +
            valueOrLine(data.tanulo_neve, 24) + ' (gyermek, tanuló neve) ' + valueOrLine(data.osztaly, 8) + ' osztályos tanuló a mindennapos testnevelés keretében megszervezett heti öt testnevelés órából a ' +
            valueOrLine(data.kivaltott_nap, 8) + ' napon a ' + valueOrLine(data.ora_1, 4) + '. órát és a ' + valueOrLine(data.ora_2, 4) + '. órát a heti edzéslátogatással válthassa ki.';
        y = wrapText(ctx, p1, m, y, contentW, 34);
        y += 24;

        ctx.font = 'bold 25px Arial, sans-serif';
        ctx.fillText('Indoklás:', m, y);
        y += 39;
        ctx.font = '24px Arial, sans-serif';
        var p2 = 'Gyermekem igazolt sportolói jogviszonyban álló versenyző, versenyengedéllyel rendelkezik, a ' +
            valueOrLine(data.sportszervezet_neve, 30) + ' sportszervezet keretei között szervezett heti ' +
            valueOrLine(data.edzes_alkalom, 4) + ' alkalommal, ' + valueOrLine(data.edzes_napok, 22) + ' napokon edzéslátogatáson vesz részt.';
        y = wrapText(ctx, p2, m, y, contentW, 34);
        y += 38;

        ctx.font = '23px Arial, sans-serif';
        ctx.fillText('Dátum: ' + valueOrLine(formatDate(data.keltezes_datuma), 18), m, y + 12);
        drawSignature(ctx, w - m - 390, y + 40, 390, 'szülő / nagykorú tanuló aláírása');
        y += 110;

        ctx.font = 'bold 22px Arial, sans-serif';
        ctx.fillText('A versenyengedély bemutatása szükséges.', m, y);
        y += 48;

        ctx.beginPath();
        ctx.moveTo(m, y);
        ctx.lineTo(w - m, y);
        ctx.stroke();
        y += 38;

        ctx.font = 'bold 29px Arial, sans-serif';
        drawCentered(ctx, 'Sportszervezet igazolása', m, y, contentW);
        y += 55;

        ctx.font = '23px Arial, sans-serif';
        var p3 = 'Igazolom, hogy a fent nevezett tanuló egyesületünkkel igazolt sportolói jogviszonyban álló, versenyengedéllyel rendelkező versenyzője, aki az alábbiak szerint vesz részt az edzéseken:';
        y = wrapText(ctx, p3, m, y, contentW, 32);
        y += 20;

        function row(label, value) {
            ctx.font = 'bold 22px Arial, sans-serif';
            ctx.fillText(label, m, y);
            ctx.font = '22px Arial, sans-serif';
            y = wrapText(ctx, valueOrLine(value, 18), m + 430, y, contentW - 430, 30);
            y += 9;
        }

        row('A sportszervezet/egyesület neve:', data.sportszervezet_neve);
        row('A tanuló sportága:', data.sportag);
        row('Versenyengedély száma:', data.versenyengedely_szama);
        row('Versenyengedély érvényessége:', valueOrLine(formatDate(data.versenyengedely_ervenyes_tol), 10) + '-tól ' + valueOrLine(formatDate(data.versenyengedely_ervenyes_ig), 10) + '-ig');
        row('Az edző neve:', data.edzo_neve);
        row('A tanuló edzéseinek időpontjai:', data.edzes_idopontok);

        y += 22;
        ctx.font = '23px Arial, sans-serif';
        ctx.fillText('Dátum: ' + valueOrLine(formatDate(data.sport_igazolas_datuma), 18), m, y + 12);
        drawSignature(ctx, w - m - 470, y + 40, 470, 'sportegyesület képviselőjének aláírása, bélyegzője');

        return canvas;
    }

    function drawGenericPdf(box, form) {
        var title = (box.querySelector('.szegbp-form-header h2') || {}).textContent || 'Iskolai nyomtatvány';
        var labels = {};
        try {
            labels = JSON.parse(box.getAttribute('data-preview-labels') || '{}');
        } catch (e) {
            labels = {};
        }

        var data = collectFields(form);
        var canvas = document.createElement('canvas');
        var w = 1240;
        var h = 1754;
        canvas.width = w;
        canvas.height = h;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#111111';
        ctx.strokeStyle = '#111111';
        ctx.lineWidth = 2;
        ctx.textBaseline = 'top';

        var m = 96;
        var y = 90;
        var contentW = w - 2 * m;
        ctx.font = 'bold 28px Arial, sans-serif';
        ctx.fillText('Szilágyi Erzsébet Gimnázium', m, y);
        y += 54;
        ctx.font = 'bold 42px Arial, sans-serif';
        y = wrapText(ctx, title, m, y, contentW, 52);
        y += 36;

        var overflow = false;
        Object.keys(data).forEach(function (key) {
            if (overflow) {
                return;
            }
            if (y > h - 220) {
                overflow = true;
                return;
            }
            var label = labels[key] || key;
            var value = data[key] || '';
            if (/datuma|datum|ervenyes/i.test(key)) {
                value = formatDate(value);
            }
            ctx.font = 'bold 23px Arial, sans-serif';
            ctx.fillText(label + ':', m, y);
            ctx.font = '23px Arial, sans-serif';
            y = wrapText(ctx, valueOrLine(value, 24), m + 360, y, contentW - 360, 32);
            y += 18;
        });

        if (overflow || y > h - 220) {
            throw new Error('szegbp-generic-pdf-overflow');
        }

        y = Math.max(y + 55, h - 210);
        ctx.font = '23px Arial, sans-serif';
        ctx.fillText('Dátum: ' + '…'.repeat(22), m, y);
        drawSignature(ctx, w - m - 420, y + 28, 420, 'aláírás');
        return canvas;
    }

    function base64ToBytes(base64) {
        var binary = atob(base64);
        var len = binary.length;
        var bytes = new Uint8Array(len);
        for (var i = 0; i < len; i += 1) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    }

    function textBytes(text) {
        return new TextEncoder().encode(text);
    }

    function concatBytes(parts) {
        var length = parts.reduce(function (sum, part) { return sum + part.length; }, 0);
        var out = new Uint8Array(length);
        var offset = 0;
        parts.forEach(function (part) {
            out.set(part, offset);
            offset += part.length;
        });
        return out;
    }

    function pdfFromCanvas(canvas) {
        var dataUrl = canvas.toDataURL('image/jpeg', 0.92);
        var imageBytes = base64ToBytes(dataUrl.split(',')[1]);
        var landscape = canvas.width > canvas.height;
        var pageW = landscape ? 841.89 : 595.28;
        var pageH = landscape ? 595.28 : 841.89;
        var content = 'q\n' + pageW.toFixed(2) + ' 0 0 ' + pageH.toFixed(2) + ' 0 0 cm\n/Im0 Do\nQ\n';
        var contentBytes = textBytes(content);
        var parts = [];
        var offsets = [0];
        var pos = 0;
        function add(part) {
            if (typeof part === 'string') {
                part = textBytes(part);
            }
            parts.push(part);
            pos += part.length;
        }
        function obj(num, header, streamBytes) {
            offsets[num] = pos;
            add(num + ' 0 obj\n');
            add(header);
            if (streamBytes) {
                add('\nstream\n');
                add(streamBytes);
                add('\nendstream');
            }
            add('\nendobj\n');
        }

        add('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
        obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
        obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
        obj(3, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + pageW.toFixed(2) + ' ' + pageH.toFixed(2) + '] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>');
        obj(4, '<< /Type /XObject /Subtype /Image /Width ' + canvas.width + ' /Height ' + canvas.height + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + imageBytes.length + ' >>', imageBytes);
        obj(5, '<< /Length ' + contentBytes.length + ' >>', contentBytes);
        var startxref = pos;
        add('xref\n0 6\n');
        add('0000000000 65535 f \n');
        for (var i = 1; i <= 5; i += 1) {
            add(String(offsets[i]).padStart(10, '0') + ' 00000 n \n');
        }
        add('trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n' + startxref + '\n%%EOF');
        return new Blob([concatBytes(parts)], { type: 'application/pdf' });
    }

    function downloadBlob(blob, filename) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.setTimeout(function () {
            URL.revokeObjectURL(url);
        }, 1000);
    }


    function parsePdfFieldMap(box) {
        var previewUrl = box.getAttribute('data-pdf-map-preview') || '';
        var map = [];
        try {
            map = JSON.parse(box.getAttribute('data-pdf-field-map') || '[]') || [];
        } catch (e) {
            map = [];
        }
        return { previewUrl: previewUrl, map: Array.isArray(map) ? map : [] };
    }

    function loadImage(url) {
        return new Promise(function (resolve, reject) {
            var img = new Image();
            img.onload = function () { resolve(img); };
            img.onerror = function () { reject(new Error('A PDF mezőtérkép háttérképe nem tölthető be.')); };
            img.src = url;
        });
    }

    function drawMappedText(ctx, value, x, y, maxWidth, fontPx, align) {
        value = (value || '').toString().replace(/\r/g, '').trim();
        if (!value) {
            return;
        }
        var lineHeight = fontPx * 1.22;
        var paragraphs = value.split('\n');
        var oldAlign = ctx.textAlign;
        ctx.textAlign = align || 'left';
        var anchorX = x;
        if (ctx.textAlign === 'center') {
            anchorX = x + maxWidth / 2;
        } else if (ctx.textAlign === 'right') {
            anchorX = x + maxWidth;
        }

        paragraphs.forEach(function (paragraph) {
            var words = paragraph.split(/\s+/).filter(Boolean);
            if (!words.length) {
                y += lineHeight;
                return;
            }
            var line = '';
            words.forEach(function (word) {
                var test = line ? line + ' ' + word : word;
                if (line && ctx.measureText(test).width > maxWidth) {
                    ctx.fillText(line, anchorX, y, maxWidth);
                    y += lineHeight;
                    line = word;
                } else {
                    line = test;
                }
            });
            if (line) {
                ctx.fillText(line, anchorX, y, maxWidth);
                y += lineHeight;
            }
        });
        ctx.textAlign = oldAlign;
    }

    async function canvasFromPdfMap(box, form, dataOverride, blankOnly) {
        var config = parsePdfFieldMap(box);
        if (!config.previewUrl || !config.map.length) {
            return null;
        }
        var img = await loadImage(config.previewUrl);
        var canvas = document.createElement('canvas');
        if (img.width > img.height) {
            canvas.width = 1754;
            canvas.height = 1240;
        } else {
            canvas.width = 1240;
            canvas.height = 1754;
        }
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        if (blankOnly) {
            return canvas;
        }

        var data = dataOverride || collectFields(form);
        ctx.fillStyle = '#111111';
        ctx.textBaseline = 'top';
        config.map.forEach(function (item) {
            if (!item || !item.field) {
                return;
            }
            var value = data[item.field] || '';
            if (/datuma|datum|ervenyes/i.test(item.field)) {
                value = formatDate(value);
            }
            var fontSize = parseFloat(item.font_size || 12);
            var pointWidth = canvas.width > canvas.height ? 841.89 : 595.28;
            var fontPx = Math.max(14, fontSize * (canvas.width / pointWidth));
            var x = Math.max(0, parseFloat(item.x || 0)) / 100 * canvas.width;
            var y = Math.max(0, parseFloat(item.y || 0)) / 100 * canvas.height;
            var width = Math.max(3, parseFloat(item.width || 35)) / 100 * canvas.width;
            ctx.font = fontPx.toFixed(1) + 'px Arial, sans-serif';
            drawMappedText(ctx, value, x, y, width, fontPx, item.align || 'left');
        });
        return canvas;
    }

    async function createPdf(box, form) {
        if (typeof TextEncoder === 'undefined') {
            alert('A közvetlen PDF-készítést ez a böngésző nem támogatja. Próbáld Chrome, Edge vagy Firefox böngészővel.');
            return;
        }
        if (typeof form.reportValidity === 'function' && !form.reportValidity()) {
            return;
        }
        updatePreview(box);
        var slug = box.getAttribute('data-form-slug') || '';
        var htmlTemplate = box.querySelector('template[data-szegbp-pdf-html-template]');
        if (!htmlTemplate || htmlTemplate.innerHTML.trim() === '') {
            alert('Ehhez az űrlaphoz nincs HTML sablon beállítva. A kitöltött PDF kizárólag a mentett HTML sablonból készül.');
            return;
        }

        var canvas;
        try {
            canvas = await canvasFromHtmlTemplate(box, form, htmlTemplate.innerHTML);
        } catch (e) {
            console.error('SZEGBP PDF HTML sablon hiba:', e);
            alert(e.message || 'A kitöltött PDF nem készíthető el az aktív HTML sablonból.');
            return;
        }
        if (!canvas) {
            alert('A kitöltött PDF nem készíthető el az aktív HTML sablonból.');
            return;
        }
        var title = (box.querySelector('.szegbp-form-header h2') || {}).textContent || slug || 'nyomtatvany';
        var blob = pdfFromCanvas(canvas);
        downloadBlob(blob, fileSafe(title) + '-kitoltott.pdf');
    }

    async function createBlankPdf(button) {
        alert('Az üres PDF nem generálódik. Az Üres PDF letöltése kizárólag az adminban külön feltöltött PDF-fájlt adja vissza változtatás nélkül.');
    }

    function initForm(box) {
        var form = box.querySelector('form.szegbp-form');
        if (!form) {
            return;
        }

        form.addEventListener('input', function () {
            updatePreview(box);
        });
        form.addEventListener('change', function () {
            updatePreview(box);
        });

        var pdfButton = box.querySelector('[data-szegbp-pdf]');
        if (pdfButton) {
            pdfButton.addEventListener('click', function () {
                createPdf(box, form);
            });
        }

        var printButton = box.querySelector('[data-szegbp-print]');
        if (printButton) {
            printButton.addEventListener('click', function () {
                if (typeof form.reportValidity === 'function' && !form.reportValidity()) {
                    return;
                }
                var htmlTemplate = box.querySelector('template[data-szegbp-pdf-html-template]');
                if (htmlTemplate && htmlTemplate.innerHTML.trim() !== '') {
                    var printFrame = document.createElement('iframe');
                    printFrame.style.cssText = 'position:fixed;left:-10000px;top:0;width:794px;height:1123px;border:0';
                    printFrame.setAttribute('sandbox', 'allow-same-origin allow-modals');
                    document.body.appendChild(printFrame);
                    loadDocument(printFrame, fillHtmlTemplate(htmlTemplate.innerHTML, collectFields(form), {}, box)).then(function () {
                        printFrame.contentWindow.addEventListener('afterprint', function () { printFrame.remove(); }, { once: true });
                        printFrame.contentWindow.focus(); printFrame.contentWindow.print();
                    }).catch(function (error) { printFrame.remove(); alert(error.message); });
                    return;
                }

                alert('Ehhez az űrlaphoz nincs HTML sablon beállítva. A Nyomtatás ugyanazt a HTML sablont használja, mint a kitöltött PDF.');
            });
        }

        var clearButton = box.querySelector('[data-szegbp-clear]');
        if (clearButton) {
            clearButton.addEventListener('click', function () {
                form.reset();
                window.setTimeout(function () {
                    updatePreview(box);
                }, 0);
            });
        }

        updatePreview(box);
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-szegbp-form]').forEach(initForm);
        document.querySelectorAll('[data-szegbp-blank-pdf]').forEach(function (button) {
            button.addEventListener('click', function () {
                createBlankPdf(button);
            });
        });
    });

    window.addEventListener('afterprint', function () {
        document.body.classList.remove('szegbp-form-printing');
    });
}());
