(function () {
    'use strict';

    function slugify(value) {
        var map = {
            'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ö': 'o', 'ő': 'o', 'ú': 'u', 'ü': 'u', 'ű': 'u',
            'Á': 'a', 'É': 'e', 'Í': 'i', 'Ó': 'o', 'Ö': 'o', 'Ő': 'o', 'Ú': 'u', 'Ü': 'u', 'Ű': 'u'
        };
        return String(value || '')
            .replace(/[áéíóöőúüűÁÉÍÓÖŐÚÜŰ]/g, function (ch) { return map[ch] || ch; })
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '_')
            .replace(/^_+|_+$/g, '')
            .substring(0, 60);
    }

    function parseAdvanced(text) {
        return String(text || '').split(/\r?\n/).map(function (line) {
            var parts = line.split('|');
            if (!parts[0]) {
                return null;
            }
            return {
                name: parts[0] || '',
                label: parts[1] || parts[0] || '',
                type: parts[2] || 'text',
                required: parts[3] === '1',
                placeholder: parts[4] || '',
                options: (parts[5] || '').replace(/;/g, '\n')
            };
        }).filter(Boolean);
    }

    function escapeAttribute(value) {
        return String(value || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
    }

    function fillRow(row, field) {
        var name = row.querySelector('[data-szegbp-field-name]');
        var label = row.querySelector('[data-szegbp-field-label]');
        var type = row.querySelector('[data-szegbp-field-type]');
        var required = row.querySelector('[data-szegbp-field-required]');
        var placeholder = row.querySelector('[data-szegbp-field-placeholder]');
        var options = row.querySelector('[data-szegbp-field-options]');

        if (name) { name.value = field.name || ''; }
        if (label) { label.value = field.label || ''; }
        if (type) { type.value = field.type || 'text'; }
        if (required) { required.checked = !!field.required; }
        if (placeholder) { placeholder.value = field.placeholder || ''; }
        if (options) {
            if (field.options && typeof field.options === 'object' && !Array.isArray(field.options)) {
                options.value = Object.keys(field.options).map(function (key) {
                    return key + '=' + field.options[key];
                }).join('\n');
            } else {
                options.value = field.options || '';
            }
        }
    }

    function updateRowUi(row) {
        if (!row) { return; }
        var name = row.querySelector('[data-szegbp-field-name]');
        var label = row.querySelector('[data-szegbp-field-label]');
        var type = row.querySelector('[data-szegbp-field-type]');
        var summary = row.querySelector('[data-szegbp-row-summary]');
        var typeLabel = row.querySelector('[data-szegbp-row-type]');
        var badge = row.querySelector('[data-szegbp-row-badge]');
        var typeValue = type ? type.value : 'text';
        var selectedText = type && type.options[type.selectedIndex] ? type.options[type.selectedIndex].text : typeValue;
        row.classList.toggle('is-section', typeValue === 'section');
        row.classList.toggle('has-options', typeValue === 'select' || typeValue === 'radio' || typeValue === 'checkbox_group' || typeValue === 'checkbox_matrix' || typeValue === 'underline_choice');
        row.classList.toggle('no-placeholder', typeValue === 'checkbox' || typeValue === 'radio' || typeValue === 'checkbox_group' || typeValue === 'checkbox_matrix' || typeValue === 'underline_choice' || typeValue === 'section');
        if (summary) { summary.textContent = (label && label.value.trim()) || (name && name.value.trim()) || (typeValue === 'section' ? 'Új szekció' : 'Új mező'); }
        if (typeLabel) { typeLabel.textContent = selectedText; }
        if (badge) { badge.textContent = typeValue === 'section' ? 'Szekció' : 'Mező'; }
    }

    function setRowCollapsed(row, collapsed) {
        if (!row) { return; }
        row.classList.toggle('is-collapsed', !!collapsed);
        var button = row.querySelector('[data-szegbp-toggle-row]');
        if (button) {
            button.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
            button.textContent = collapsed ? '▸' : '▾';
            button.title = collapsed ? 'Kinyitás' : 'Összecsukás';
        }
        updateRowUi(row);
    }

    function rowToLine(row) {
        var name = row.querySelector('[data-szegbp-field-name]');
        var label = row.querySelector('[data-szegbp-field-label]');
        var type = row.querySelector('[data-szegbp-field-type]');
        var required = row.querySelector('[data-szegbp-field-required]');
        var placeholder = row.querySelector('[data-szegbp-field-placeholder]');
        var options = row.querySelector('[data-szegbp-field-options]');

        var nameValue = slugify(name ? name.value : '');
        if (name && name.value !== nameValue) {
            name.value = nameValue;
        }
        if (!nameValue) {
            return '';
        }

        var labelValue = label ? label.value.trim() : nameValue;
        var typeValue = type ? type.value : 'text';
        var requiredValue = required && required.checked ? '1' : '0';
        var placeholderValue = placeholder ? placeholder.value.replace(/\|/g, ' ').trim() : '';
        var optionsValue = '';

        if (typeValue === 'section') {
            requiredValue = '0';
            placeholderValue = '';
        }

        if ((typeValue === 'select' || typeValue === 'radio' || typeValue === 'checkbox_group' || typeValue === 'checkbox_matrix' || typeValue === 'underline_choice') && options) {
            optionsValue = options.value
                .split(/\r?\n|;/)
                .map(function (item) { return item.trim().replace(/\|/g, ' '); })
                .filter(Boolean)
                .join(';');
        }

        return [
            nameValue,
            labelValue.replace(/\|/g, ' ').trim() || nameValue,
            typeValue,
            requiredValue,
            placeholderValue,
            optionsValue
        ].join('|');
    }

    function updateOrder(builder) {
        Array.prototype.forEach.call(builder.querySelectorAll('[data-szegbp-field-row]'), function (row, index) {
            var order = row.querySelector('[data-szegbp-field-order]');
            if (order) {
                order.textContent = String(index + 1);
            }
        });
    }

    function syncFromRows(builder) {
        var lines = Array.prototype.map.call(builder.querySelectorAll('[data-szegbp-field-row]'), rowToLine)
            .filter(Boolean);
        var value = lines.join('\n');
        var hidden = builder.querySelector('[data-szegbp-field-definition]');
        var advanced = builder.querySelector('[data-szegbp-advanced-definition]');
        if (hidden) {
            hidden.value = value;
        }
        if (advanced && document.activeElement !== advanced) {
            advanced.value = value;
        }
        updateOrder(builder);
    }

    function createRow(builder, field) {
        var template = builder.querySelector('[data-szegbp-field-template]');
        var row;
        if (template && 'content' in template) {
            row = template.content.firstElementChild.cloneNode(true);
        } else if (template) {
            var holder = document.createElement('tbody');
            holder.innerHTML = template.innerHTML;
            row = holder.firstElementChild;
        }
        if (!row) {
            return null;
        }
        fillRow(row, field || {});
        return row;
    }

    function initializeBuilder(builder) {
        var rows = builder.querySelector('[data-szegbp-field-rows]');
        var hidden = builder.querySelector('[data-szegbp-field-definition]');
        var advanced = builder.querySelector('[data-szegbp-advanced-definition]');
        var presets = {};

        try {
            presets = JSON.parse(builder.getAttribute('data-presets') || '{}') || {};
        } catch (error) {
            presets = {};
        }

        if (!rows) {
            return;
        }

        builder.addEventListener('input', function (event) {
            if (event.target.matches('[data-szegbp-field-label]')) {
                var row = event.target.closest('[data-szegbp-field-row]');
                var name = row ? row.querySelector('[data-szegbp-field-name]') : null;
                if (name && !name.dataset.touched && name.value.trim() === '') {
                    name.value = slugify(event.target.value);
                }
            }
            if (event.target.matches('[data-szegbp-field-name]')) {
                event.target.dataset.touched = '1';
            }
            if (event.target === advanced) {
                if (hidden) {
                    hidden.value = advanced.value;
                }
                var parsed = parseAdvanced(advanced.value);
                if (parsed.length) {
                    rows.innerHTML = '';
                    parsed.forEach(function (field) {
                        var row = createRow(builder, field);
                        if (row) {
                            rows.appendChild(row);
                        }
                    });
                    updateOrder(builder);
                }
                return;
            }
            if (event.target.closest('[data-szegbp-field-row]')) {
                updateRowUi(event.target.closest('[data-szegbp-field-row]'));
                syncFromRows(builder);
            }
        });

        builder.addEventListener('change', function (event) {
            if (event.target.closest('[data-szegbp-field-row]')) {
                updateRowUi(event.target.closest('[data-szegbp-field-row]'));
                syncFromRows(builder);
            }
        });

        builder.addEventListener('click', function (event) {
            var addButton = event.target.closest('[data-szegbp-add-field]');
            var addSection = event.target.closest('[data-szegbp-add-section]');
            var toggleRow = event.target.closest('[data-szegbp-toggle-row]');
            var collapseAll = event.target.closest('[data-szegbp-collapse-all]');
            var expandAll = event.target.closest('[data-szegbp-expand-all]');
            var insertPreset = event.target.closest('[data-szegbp-insert-preset]');
            var deleteButton = event.target.closest('[data-szegbp-delete-field]');
            var moveUp = event.target.closest('[data-szegbp-move-up]');
            var moveDown = event.target.closest('[data-szegbp-move-down]');

            if (addButton) {
                event.preventDefault();
                var row = createRow(builder, { name: '', label: '', type: 'text', required: false, placeholder: '', options: '' });
                if (row) {
                    rows.appendChild(row);
                    updateRowUi(row);
                    setRowCollapsed(row, false);
                    var label = row.querySelector('[data-szegbp-field-label]');
                    if (label) {
                        label.focus();
                    }
                    syncFromRows(builder);
                }
            }

            if (addSection) {
                event.preventDefault();
                var sectionIndex = String(Date.now()).slice(-8);
                var sectionRow = createRow(builder, { name: 'szekcio_' + sectionIndex, label: 'Új szekció', type: 'section', required: false, placeholder: '', options: '' });
                if (sectionRow) {
                    rows.appendChild(sectionRow);
                    updateRowUi(sectionRow);
                    setRowCollapsed(sectionRow, false);
                    var sectionLabel = sectionRow.querySelector('[data-szegbp-field-label]');
                    if (sectionLabel) { sectionLabel.focus(); sectionLabel.select(); }
                    syncFromRows(builder);
                }
            }

            if (toggleRow) {
                event.preventDefault();
                var rowToToggle = toggleRow.closest('[data-szegbp-field-row]');
                setRowCollapsed(rowToToggle, !rowToToggle.classList.contains('is-collapsed'));
            }

            if (collapseAll) {
                event.preventDefault();
                Array.prototype.forEach.call(rows.querySelectorAll('[data-szegbp-field-row]'), function (row) { setRowCollapsed(row, true); });
            }

            if (expandAll) {
                event.preventDefault();
                Array.prototype.forEach.call(rows.querySelectorAll('[data-szegbp-field-row]'), function (row) { setRowCollapsed(row, false); });
            }

            if (insertPreset) {
                event.preventDefault();
                var select = builder.querySelector('[data-szegbp-preset-select]');
                var preset = select && presets[select.value] ? presets[select.value] : null;
                if (preset) {
                    var row = createRow(builder, preset);
                    if (row) {
                        rows.appendChild(row);
                        updateRowUi(row);
                        setRowCollapsed(row, false);
                        syncFromRows(builder);
                    }
                    select.value = '';
                }
            }

            if (deleteButton) {
                event.preventDefault();
                var rowToDelete = deleteButton.closest('[data-szegbp-field-row]');
                if (rowToDelete && window.confirm('Biztosan törlöd ezt a mezőt? A törlés a Mentés gomb megnyomásakor válik véglegessé.')) {
                    rowToDelete.remove();
                    syncFromRows(builder);
                }
            }

            if (moveUp || moveDown) {
                event.preventDefault();
                var rowToMove = event.target.closest('[data-szegbp-field-row]');
                if (rowToMove && moveUp && rowToMove.previousElementSibling) {
                    rows.insertBefore(rowToMove, rowToMove.previousElementSibling);
                }
                if (rowToMove && moveDown && rowToMove.nextElementSibling) {
                    rows.insertBefore(rowToMove.nextElementSibling, rowToMove);
                }
                syncFromRows(builder);
            }
        });

        Array.prototype.forEach.call(rows.querySelectorAll('[data-szegbp-field-row]'), function (row) { updateRowUi(row); setRowCollapsed(row, true); });

        if (hidden && !hidden.value && advanced && advanced.value) {
            hidden.value = advanced.value;
        }
        syncFromRows(builder);
    }



    function initializeHtmlTemplateImporter(input) {
        var card = input.closest('td') || input.parentElement;
        if (!card) { return; }
        var textarea = card.querySelector('[data-szegbp-html-template]');
        var details = card.querySelector('[data-szegbp-html-editor]');
        var feedback = card.querySelector('[data-szegbp-html-import-feedback]');
        var status = card.querySelector('[data-szegbp-html-status]');
        if (!textarea) { return; }

        input.addEventListener('change', function () {
            var file = input.files && input.files[0] ? input.files[0] : null;
            if (!file) { return; }
            var name = String(file.name || '');
            if (!/\.html?$/i.test(name)) {
                if (feedback) { feedback.hidden = false; feedback.className = 'szegbp-html-import-feedback is-error'; feedback.textContent = 'Csak .html vagy .htm fájl olvasható be.'; }
                input.value = '';
                return;
            }
            if (file.size > 1024 * 1024) {
                if (feedback) { feedback.hidden = false; feedback.className = 'szegbp-html-import-feedback is-error'; feedback.textContent = 'A HTML fájl legfeljebb 1 MB lehet.'; }
                input.value = '';
                return;
            }
            function normalizeWordHtml(html) {
                html = String(html || '');
                html = html.replace(/<meta\s+http-equiv=["']?Content-Type["']?\s+content=["']text\/html;\s*charset=[^"']+["']\s*\/?>(?:\s*)/ig, '<meta charset="utf-8">');
                html = html.replace(/<meta\s+charset=[^>]+>/ig, '<meta charset="utf-8">');
                html = html.replace(/<link\s+[^>]*(?:File-List|themeData|colorSchemeMapping)[^>]*>/ig, '');
                html = html.replace(/<!--\[if\s+gte\s+mso\s+9\]>\s*<xml>[\s\S]*?<\/xml>\s*<!\[endif\]-->/ig, '');
                html = html.replace(/\{\{([\s\S]*?)\}\}/g, function (_, inner) {
                    var box = document.createElement('div');
                    box.innerHTML = inner;
                    var key = (box.textContent || box.innerText || '')
                        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                        .toLowerCase().replace(/[^a-z0-9_-]+/g, '');
                    return key ? '{{' + key + '}}' : '';
                });
                if (/class=["']?WordSection1["']?/i.test(html) && html.indexOf('szegbp-word-html-normalize') === -1) {
                    var css = '<style id="szegbp-word-html-normalize">html{background:#eef0ec}body{margin:0!important;background:#eef0ec!important}div.WordSection1{width:210mm;min-height:297mm;box-sizing:border-box;margin:18px auto!important;padding:23.6mm 25mm 8mm 22.5mm;background:#fff;box-shadow:0 8px 28px rgba(0,0,0,.16)}@media(max-width:900px){div.WordSection1{width:100%;min-height:0;margin:0!important;padding:20px;box-shadow:none}}</style>';
                    html = html.replace(/<\/head>/i, css + '</head>');
                }
                return html;
            }

            var reader = new FileReader();
            reader.onload = function () {
                var html = normalizeWordHtml(String(reader.result || ''));
                textarea.value = html;
                textarea.dispatchEvent(new Event('input', { bubbles: true }));
                if (details) { details.open = true; }
                if (feedback) { feedback.hidden = false; feedback.className = 'szegbp-html-import-feedback is-success'; feedback.textContent = 'Beolvasva: ' + name + '. Most nyomd meg a Mentés gombot.'; }
                if (status) {
                    status.className = 'szegbp-template-status is-inline';
                    status.innerHTML = '<strong>Beolvasott HTML sablon:</strong><span>' + name.replace(/[&<>"']/g, function(ch){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch]; }) + '</span><span class="szegbp-template-status__hint">A fájl tartalma a szerkesztőbe került. Mentés után ez lesz az aktív HTML sablon.</span>';
                }
                textarea.focus();
            };
            reader.onerror = function () {
                if (feedback) { feedback.hidden = false; feedback.className = 'szegbp-html-import-feedback is-error'; feedback.textContent = 'A HTML fájl beolvasása nem sikerült.'; }
            };
            reader.readAsText(file, 'UTF-8');
        });
    }



    function initializeDirectPreviewSubmit(button) {
        if (!button) { return; }
        button.addEventListener('click', function () {
            var form = button.closest('form');
            if (!form) { return; }
            var textarea = form.querySelector('[data-szegbp-html-template]');
            var hidden = form.querySelector('[data-szegbp-preview-html]');
            if (textarea && hidden) {
                hidden.value = textarea.value || '';
            }
        });
    }

    function initializePdfMap(root) {
        var stage = root.querySelector('[data-szegbp-pdf-map-stage]');
        var hidden = root.querySelector('[data-szegbp-pdf-map-json]');
        if (!stage || !hidden) {
            return;
        }

        var fields = [];
        var map = [];
        try {
            fields = JSON.parse(root.getAttribute('data-fields') || '[]') || [];
        } catch (e) {
            fields = [];
        }
        try {
            map = JSON.parse(hidden.value || '[]') || [];
        } catch (e) {
            map = [];
        }

        var fieldLabels = {};
        fields.forEach(function (field) {
            if (field && field.name) {
                fieldLabels[field.name] = field.label || field.name;
            }
        });

        var select = root.querySelector('[data-szegbp-pdf-map-field]');
        var add = root.querySelector('[data-szegbp-pdf-map-add]');
        var addAll = root.querySelector('[data-szegbp-pdf-map-add-all]');
        var selectedText = root.querySelector('[data-szegbp-pdf-map-selected]');
        var xInput = root.querySelector('[data-szegbp-map-x]');
        var yInput = root.querySelector('[data-szegbp-map-y]');
        var widthInput = root.querySelector('[data-szegbp-map-width]');
        var fontInput = root.querySelector('[data-szegbp-map-font]');
        var alignInput = root.querySelector('[data-szegbp-map-align]');
        var remove = root.querySelector('[data-szegbp-map-remove]');
        var selectedIndex = -1;

        function clamp(value, min, max) {
            value = parseFloat(value);
            if (!isFinite(value)) {
                return min;
            }
            return Math.max(min, Math.min(max, value));
        }

        function normalizeItem(item) {
            var x = clamp(item.x, 0, 100);
            return {
                field: item.field || '',
                x: x,
                y: clamp(item.y, 0, 100),
                width: clamp(item.width, 3, Math.max(3, 100 - x)),
                font_size: clamp(item.font_size, 7, 36),
                align: ['left', 'center', 'right'].indexOf(item.align) >= 0 ? item.align : 'left'
            };
        }

        map = map.map(normalizeItem).filter(function (item) {
            return !!fieldLabels[item.field];
        });

        function syncHidden() {
            hidden.value = JSON.stringify(map);
        }

        function populateSelect() {
            if (!select) {
                return;
            }
            var current = select.value;
            select.innerHTML = '';
            fields.forEach(function (field) {
                if (!field || !field.name) {
                    return;
                }
                var opt = document.createElement('option');
                opt.value = field.name;
                opt.textContent = field.label || field.name;
                select.appendChild(opt);
            });
            if (current) {
                select.value = current;
            }
        }

        function updateProperties() {
            var item = selectedIndex >= 0 && map[selectedIndex] ? map[selectedIndex] : null;
            if (selectedText) {
                selectedText.textContent = item ? (fieldLabels[item.field] || item.field) + ' — {{' + item.field + '}}' : 'Nincs kijelölve.';
            }
            [xInput, yInput, widthInput, fontInput, alignInput, remove].forEach(function (control) {
                if (control) {
                    control.disabled = !item;
                }
            });
            if (!item) {
                return;
            }
            if (xInput) { xInput.value = item.x.toFixed(1); }
            if (yInput) { yInput.value = item.y.toFixed(1); }
            if (widthInput) { widthInput.value = item.width.toFixed(1); }
            if (fontInput) { fontInput.value = item.font_size.toFixed(0); }
            if (alignInput) { alignInput.value = item.align; }
        }

        function render() {
            Array.prototype.forEach.call(stage.querySelectorAll('[data-szegbp-pdf-map-item]'), function (node) {
                node.remove();
            });
            map.forEach(function (item, index) {
                var node = document.createElement('button');
                node.type = 'button';
                node.className = 'szegbp-pdf-map-item' + (index === selectedIndex ? ' is-selected' : '');
                node.setAttribute('data-szegbp-pdf-map-item', String(index));
                node.style.left = item.x + '%';
                node.style.top = item.y + '%';
                node.style.width = item.width + '%';
                var previewImg = stage.querySelector('img');
                var pointWidth = previewImg && previewImg.naturalWidth > previewImg.naturalHeight ? 841.89 : 595.28;
                var stageScale = (stage.clientWidth || 794) / pointWidth;
                node.style.fontSize = Math.max(9, item.font_size * stageScale) + 'px';
                node.style.textAlign = item.align;
                node.textContent = fieldLabels[item.field] || item.field;

                node.addEventListener('click', function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    selectedIndex = index;
                    render();
                });

                node.addEventListener('pointerdown', function (event) {
                    if (event.button !== undefined && event.button !== 0) {
                        return;
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    selectedIndex = index;
                    var rect = stage.getBoundingClientRect();
                    var current = map[index];
                    var startX = event.clientX;
                    var startY = event.clientY;
                    var baseX = current.x;
                    var baseY = current.y;

                    function move(ev) {
                        var dx = (ev.clientX - startX) / rect.width * 100;
                        var dy = (ev.clientY - startY) / rect.height * 100;
                        current.x = clamp(baseX + dx, 0, Math.max(0, 100 - current.width));
                        current.y = clamp(baseY + dy, 0, 98);
                        syncHidden();
                        node.style.left = current.x + '%';
                        node.style.top = current.y + '%';
                        updateProperties();
                    }

                    function up() {
                        window.removeEventListener('pointermove', move);
                        window.removeEventListener('pointerup', up);
                        render();
                    }

                    window.addEventListener('pointermove', move);
                    window.addEventListener('pointerup', up);
                });

                stage.appendChild(node);
            });
            syncHidden();
            updateProperties();
        }

        function hasField(name) {
            return map.some(function (item) { return item.field === name; });
        }

        function addField(name, offset) {
            if (!name || !fieldLabels[name] || hasField(name)) {
                return false;
            }
            map.push(normalizeItem({
                field: name,
                x: 8,
                y: Math.min(88, 8 + ((offset || map.length) * 4.2)),
                width: 38,
                font_size: 12,
                align: 'left'
            }));
            selectedIndex = map.length - 1;
            return true;
        }

        if (add) {
            add.addEventListener('click', function (event) {
                event.preventDefault();
                if (select && addField(select.value, map.length)) {
                    render();
                }
            });
        }

        if (addAll) {
            addAll.addEventListener('click', function (event) {
                event.preventDefault();
                fields.forEach(function (field, index) {
                    if (field && field.name) {
                        addField(field.name, index);
                    }
                });
                render();
            });
        }

        function updateSelectedFromControls() {
            if (selectedIndex < 0 || !map[selectedIndex]) {
                return;
            }
            var item = map[selectedIndex];
            if (xInput) { item.x = clamp(xInput.value, 0, Math.max(0, 100 - item.width)); }
            if (yInput) { item.y = clamp(yInput.value, 0, 98); }
            if (widthInput) {
                item.width = clamp(widthInput.value, 3, Math.max(3, 100 - item.x));
            }
            if (fontInput) { item.font_size = clamp(fontInput.value, 7, 36); }
            if (alignInput) { item.align = alignInput.value; }
            render();
        }

        [xInput, yInput, widthInput, fontInput, alignInput].forEach(function (control) {
            if (control) {
                control.addEventListener('input', updateSelectedFromControls);
                control.addEventListener('change', updateSelectedFromControls);
            }
        });

        if (remove) {
            remove.addEventListener('click', function (event) {
                event.preventDefault();
                if (selectedIndex < 0 || !map[selectedIndex]) {
                    return;
                }
                map.splice(selectedIndex, 1);
                selectedIndex = -1;
                render();
            });
        }

        stage.addEventListener('click', function () {
            selectedIndex = -1;
            render();
        });

        var backgroundImage = stage.querySelector('img');
        if (backgroundImage && !backgroundImage.complete) {
            backgroundImage.addEventListener('load', render);
        }
        populateSelect();
        render();
    }

    document.addEventListener('DOMContentLoaded', function () {
        Array.prototype.forEach.call(document.querySelectorAll('[data-szegbp-field-builder]'), initializeBuilder);
        Array.prototype.forEach.call(document.querySelectorAll('[data-szegbp-html-import]'), initializeHtmlTemplateImporter);
        Array.prototype.forEach.call(document.querySelectorAll('[data-szegbp-preview-submit]'), initializeDirectPreviewSubmit);
        Array.prototype.forEach.call(document.querySelectorAll('[data-szegbp-pdf-map]'), initializePdfMap);
    });
}());
