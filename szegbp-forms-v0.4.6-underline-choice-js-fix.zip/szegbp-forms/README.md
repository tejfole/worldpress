# SZEGBP Forms v0.4.6

- Javítva: a böngészős HTML-előnézet/PDF adatgyűjtése select mezőknél is eltárolja a `mező__key` értéket.
- Javítva: az `underline_choice` explicit sablonszövegnél is felismeri a kiválasztott feliratot.
- PHP/DOCX oldali korábbi kompatibilitás megmaradt.

## 0.4.5 – aláhúzandó választás kompatibilitás

- Az `underline_choice` sablonhelyőrző most `select`, `radio` és `underline_choice` mezőkkel is működik.
- A select mező elmenti a kiválasztott opció kulcsát is (`mező__key`).
- HTML/PDF előnézetnél a kiválasztott címke alapján is felismerhető az aláhúzandó opció.
- DOCX-ben ugyanez a három egyválasztós mezőtípus támogatott.

## 0.4.4 – radio és jelölőnégyzet-mátrix

Új mezőtípusok:

- **Egyszeres választás (radio)** – egyetlen opció választható. A `{{mezőnév}}` a kiválasztott feliratot adja; a `{{mezőnév_opció}}` helyőrzők `☒` / `☐` értéket adnak.
- **Jelölőnégyzet-mátrix** – sor × oszlop választások iskolai kérelmekhez és nyilatkozatokhoz. Admin szintaxis:
  - `row:tobbletido=Időhosszabbítás (többletidő)`
  - `row:segedeszkoz=Segédeszköz használata`
  - `col:magyar=Magyar nyelv`
  - `col:matematika=Matematika`

A sablonban a cellák például:

- `{{kedvezmenyek_tobbletido_magyar}}`
- `{{kedvezmenyek_tobbletido_matematika}}`
- `{{kedvezmenyek_segedeszkoz_magyar}}`

A cellák a kitöltött DOCX-ben és HTML/PDF-ben `☒` vagy `☐` értéket kapnak.

A v0.4.3 aláhúzással jelölt választása és a négy külön dokumentumforrás-modell változatlanul megmaradt.
