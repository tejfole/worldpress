<?php
/**
 * Plugin Name: SZEGBP Űrlapok és Nyomtatványok
 * Description: Böngészőben kitölthető, nyomtatható, üresen is letölthető iskolai nyomtatványok. Az adatokat nem menti adatbázisba.
 * Version: 0.4.6
 * Author: SZEGBP
 * Text Domain: szegbp-forms
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SZEGBP_Forms_Plugin
{
    public const VERSION = '0.4.5';
    private const OPTION_NAME = 'szegbp_forms_settings';
    private const NONCE_ACTION = 'szegbp_forms_docx';
    public const CONTENT_CAPABILITY = 'szegbp_manage_forms';

    private static ?self $instance = null;

    private function content_menu_capability(): string
    {
        return current_user_can(self::CONTENT_CAPABILITY) ? self::CONTENT_CAPABILITY : 'manage_options';
    }

    private function can_manage_content(): bool
    {
        return current_user_can(self::CONTENT_CAPABILITY) || current_user_can('manage_options');
    }

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('init', [$this, 'migrate_document_templates'], 5);
        add_action('init', [$this, 'register_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_post_szegbp_forms_docx', [$this, 'handle_docx_download']);
        add_action('admin_post_nopriv_szegbp_forms_docx', [$this, 'handle_docx_download']);
        add_action('admin_post_szegbp_forms_blank_docx', [$this, 'handle_blank_docx_download']);
        add_action('admin_post_nopriv_szegbp_forms_blank_docx', [$this, 'handle_blank_docx_download']);
        add_action('admin_post_szegbp_forms_preview', [$this, 'handle_admin_preview']);
        add_action('plugins_loaded', [$this, 'register_platform_services'], 20);
        add_action('szegbp_platform_file_transfers_register', [$this, 'register_file_transfers']);
        add_action('szegbp_platform_register_file_transfers', [$this, 'register_file_transfers']);
    }

    public function migrate_document_templates(): void
    {
        if (get_option('szegbp_forms_document_model_version', '') === '0.4.2') { return; }
        $settings = get_option(self::OPTION_NAME, []);
        if (!is_array($settings)) { return; }
        $changed = false;
        $complete = true;
        $migrate = function (array &$form) use (&$changed, &$complete): void {
            if (trim((string)($form['pdf_html_template'] ?? '')) !== '' || empty($form['pdf_html_file'])) { return; }
            $file = $this->get_template_file_from_relative((string)$form['pdf_html_file'], 'html');
            $html = $file !== null ? file_get_contents($file['path']) : false;
            if (!is_string($html) || trim($html) === '' || strlen($html) > 1024 * 1024) { $complete = false; return; }
            $form['pdf_html_template'] = $this->sanitize_pdf_html_template($html);
            $changed = true;
        };
        foreach ($settings as $slug => &$form) {
            if ($slug === '_custom_forms' && is_array($form)) {
                foreach ($form as &$custom) { if (is_array($custom)) { $migrate($custom); } }
                unset($custom);
            } elseif (is_array($form) && substr((string)$slug, 0, 1) !== '_') { $migrate($form); }
        }
        unset($form);
        if ($changed) { update_option(self::OPTION_NAME, $settings, false); }
        if ($complete) { update_option('szegbp_forms_document_model_version', '0.4.2', false); }
    }

    public function register_shortcode(): void
    {
        add_shortcode('szegbp_forms', [$this, 'shortcode_forms']);
        add_shortcode('szegbp_form', [$this, 'shortcode_single_form']);
        add_shortcode('szegbp_forms_adatkezeles', [$this, 'shortcode_privacy_notice']);
    }

    public function register_assets(): void
    {
        $dependencies = wp_style_is('szegbp-ui-core', 'registered') ? ['szegbp-ui-core'] : [];

        wp_register_style(
            'szegbp-forms-frontend',
            plugin_dir_url(__FILE__) . 'assets/frontend.css',
            $dependencies,
            self::VERSION
        );

        wp_register_script(
            'szegbp-forms-frontend',
            plugin_dir_url(__FILE__) . 'assets/frontend.js',
            [],
            self::VERSION,
            true
        );
    }

    public function enqueue_admin_assets(string $hook): void
    {
        if (strpos((string)$hook, 'szegbp-forms') === false) {
            return;
        }

        $dependencies = wp_style_is('szegbp-admin-ui', 'registered') ? ['szegbp-admin-ui'] : [];

        wp_enqueue_style(
            'szegbp-forms-admin',
            plugin_dir_url(__FILE__) . 'assets/admin.css',
            $dependencies,
            self::VERSION
        );

        wp_enqueue_script(
            'szegbp-forms-admin',
            plugin_dir_url(__FILE__) . 'assets/admin.js',
            [],
            self::VERSION,
            true
        );
    }

    public function register_admin_menu(): void
    {
        add_menu_page(
            'SZEGBP Űrlapok',
            'SZEGBP Űrlapok',
            $this->content_menu_capability(),
            'szegbp-forms',
            [$this, 'render_admin_page'],
            'dashicons-media-document',
            58
        );

        add_submenu_page(
            'szegbp-forms',
            'Űrlapok Platform Services',
            'Platform Services',
            'manage_options',
            'szegbp-forms-platform',
            [$this, 'render_platform_page']
        );
    }

    public function render_admin_page(): void
    {
        if (!$this->can_manage_content()) {
            wp_die(esc_html__('Nincs jogosultságod az oldal megtekintéséhez.', 'szegbp-forms'));
        }

        $saved = false;
        $reset = false;
        $notice = '';
        $notice_type = 'success';
        $upload_messages = [];
        $selected_slug = isset($_GET['form_edit']) ? sanitize_key((string)wp_unslash($_GET['form_edit'])) : '';
        $copy_source_slug = isset($_GET['form_copy']) ? sanitize_key((string)wp_unslash($_GET['form_copy'])) : '';
        $created_slug = '';

        if (isset($_POST['szegbp_forms_add'])) {
            check_admin_referer('szegbp_forms_admin_save');
            $new_raw = (array)($_POST['szegbp_forms_new'] ?? []);
            $settings = $this->add_custom_form_to_settings($new_raw, $created_slug);
            if ($created_slug !== '') {
                update_option(self::OPTION_NAME, $settings, false);
                $creation = $this->finish_new_form_template_creation($created_slug, $new_raw);
                if (!empty($creation['messages']) && is_array($creation['messages'])) {
                    $upload_messages = array_merge($upload_messages, $creation['messages']);
                }
                $this->platform_log('info', 'Űrlap létrehozva.', [
                    'slug' => $created_slug,
                    'creation_mode' => (string)($creation['mode'] ?? 'auto'),
                    'docx_ready' => !empty($creation['docx_ready']),
                    'pdf_ready' => !empty($creation['pdf_ready']),
                    'detected_fields' => (int)($creation['detected_fields'] ?? 0),
                ]);
                $selected_slug = $created_slug;
                $saved = true;
                if (!empty($creation['source_docx'])) {
                    $notice = 'Az új űrlap létrejött. A DOCX-et feldolgoztam, a mezőpárosítás lent ellenőrizhető. A kitöltött PDF-hez a HTML sablont külön importáld vagy generáld.';
                } else {
                    $notice = 'Az új űrlap létrejött, és a kitöltési DOCX sablon elkészült. A kitöltött PDF-hez a HTML sablont külön importáld vagy generáld.';
                }
                if (empty($creation['docx_ready'])) {
                    $notice_type = 'warning';
                }
            } else {
                $notice = 'Új űrlap létrehozásához add meg legalább a címet.';
                $notice_type = 'warning';
            }
        }

        if (isset($_POST['szegbp_forms_copy'])) {
            check_admin_referer('szegbp_forms_admin_copy');
            $source_slug = sanitize_key((string)($_POST['szegbp_forms_copy_source'] ?? ''));
            $copy_report = [];
            $settings = $this->duplicate_form_to_settings($source_slug, (array)($_POST['szegbp_forms_copy_data'] ?? []), $created_slug, $copy_report);
            if ($created_slug !== '') {
                update_option(self::OPTION_NAME, $settings, false);
                $this->platform_log('info', 'Űrlap másolata létrehozva.', [
                    'source_slug' => $source_slug,
                    'slug' => $created_slug,
                    'templates_copied' => !empty($copy_report['templates_copied']),
                ]);
                $selected_slug = $created_slug;
                $copy_source_slug = '';
                $saved = true;
                $notice = !empty($copy_report['templates_copied'])
                    ? 'Az űrlap másolata a külön példányként létrehozott sablonfájlokkal együtt elkészült.'
                    : 'Az űrlap másolata létrejött. A sablonok automatikus generálással vagy új feltöltéssel készíthetők hozzá.';
            } else {
                $copy_source_slug = $source_slug;
                $notice = 'A másolat létrehozásához add meg az új űrlap címét.';
                $notice_type = 'warning';
            }
        }

        if (isset($_POST['szegbp_forms_delete'])) {
            check_admin_referer('szegbp_forms_admin_delete');
            $delete_slug = sanitize_key((string)($_POST['szegbp_forms_delete_slug'] ?? ''));
            $forms_before_delete = $this->get_forms();
            if ($delete_slug !== '' && isset($forms_before_delete[$delete_slug])) {
                $form_to_delete = $forms_before_delete[$delete_slug];
                $settings = get_option(self::OPTION_NAME, []);
                $settings = is_array($settings) ? $settings : [];
                $delete_templates = !empty($_POST['szegbp_forms_delete_templates']);

                if ($delete_templates) {
                    foreach (['docx_template', 'blank_docx', 'pdf_template', 'pdf_html_file', 'pdf_map_preview'] as $template_key) {
                        $this->delete_stored_template_file((string)($form_to_delete[$template_key] ?? ''));
                    }
                    $upload_messages[] = 'A törölt űrlap hozzárendelt sablonfájljai is törölve lettek.';
                }

                if (!empty($form_to_delete['custom'])) {
                    if (isset($settings['_custom_forms'][$delete_slug])) {
                        unset($settings['_custom_forms'][$delete_slug]);
                        if (empty($settings['_custom_forms'])) {
                            unset($settings['_custom_forms']);
                        }
                    }
                    $delete_kind = 'custom';
                } else {
                    $deleted_defaults = is_array($settings['_deleted_forms'] ?? null) ? $settings['_deleted_forms'] : [];
                    $deleted_defaults[] = $delete_slug;
                    $deleted_defaults = array_values(array_unique(array_filter(array_map('sanitize_key', $deleted_defaults))));
                    $settings['_deleted_forms'] = $deleted_defaults;
                    unset($settings[$delete_slug]);
                    $delete_kind = 'default';
                }

                update_option(self::OPTION_NAME, $settings, false);
                $this->platform_log('warning', 'Űrlap törölve.', [
                    'slug' => $delete_slug,
                    'kind' => $delete_kind,
                    'templates_deleted' => $delete_templates,
                ]);
                $selected_slug = '';
                $saved = true;
                $notice = !empty($form_to_delete['custom'])
                    ? 'Az űrlap törölve lett.'
                    : 'A beépített űrlap törölve lett. Az Alapbeállítások visszaállítása funkcióval később visszaállítható.';
            } else {
                $notice = 'A törlendő űrlap nem található.';
                $notice_type = 'error';
            }
        }


        if (isset($_POST['szegbp_forms_generate_html_from_docx'])) {
            check_admin_referer('szegbp_forms_admin_save');
            $edit_slug = sanitize_key((string)($_POST['szegbp_forms_edit_slug'] ?? ''));
            $forms_before_generate = $this->get_forms();
            if ($edit_slug !== '' && isset($forms_before_generate[$edit_slug])) {
                $row = is_array($_POST['szegbp_forms'][$edit_slug] ?? null) ? $_POST['szegbp_forms'][$edit_slug] : [];
                $settings = $this->save_single_form_settings($edit_slug, $row, $forms_before_generate[$edit_slug]);
                $upload_messages = array_merge($upload_messages, $this->handle_admin_template_uploads($settings));
                update_option(self::OPTION_NAME, $settings, false);
                $forms_after_save = $this->get_forms();
                $form_for_generation = $forms_after_save[$edit_slug] ?? $forms_before_generate[$edit_slug];
                $docx_file = $this->get_form_template_file($form_for_generation, 'docx');
                if ($docx_file !== null) {
                    $generated_html = $this->generate_pdf_html_from_docx_template($docx_file['path'], $form_for_generation);
                    if ($generated_html !== '') {
                        $settings = get_option(self::OPTION_NAME, []);
                        $settings = is_array($settings) ? $settings : [];
                        $this->set_form_setting_value($settings, $edit_slug, $form_for_generation, 'pdf_html_template', $generated_html);
                        update_option(self::OPTION_NAME, $settings, false);
                        $saved = true;
                        $selected_slug = $edit_slug;
                        $notice = 'A dokumentum HTML sablon elkészült a jelenlegi DOCX-ből. Az előnézet most ezt használja.';
                        $this->platform_log('info', 'Dokumentum HTML sablon DOCX-ből létrehozva.', ['slug' => $edit_slug]);
                    } else {
                        $notice = 'A DOCX-ből nem sikerült HTML dokumentumsablont készíteni. Ellenőrizd a DOCX fájlt és a ZipArchive/DOM PHP bővítményeket.';
                        $notice_type = 'warning';
                    }
                } else {
                    $notice = 'Nincs használható DOCX sablon, amiből HTML dokumentumsablon készülhetne.';
                    $notice_type = 'warning';
                }
            } else {
                $notice = 'A DOCX→HTML sablongeneráláshoz tartozó űrlap nem található.';
                $notice_type = 'error';
            }
        }

        if (isset($_POST['szegbp_forms_generate_pdf_html'])) {
            check_admin_referer('szegbp_forms_admin_save');
            $edit_slug = sanitize_key((string)($_POST['szegbp_forms_edit_slug'] ?? ''));
            $forms_before_generate = $this->get_forms();
            if ($edit_slug !== '' && isset($forms_before_generate[$edit_slug])) {
                $row = is_array($_POST['szegbp_forms'][$edit_slug] ?? null) ? $_POST['szegbp_forms'][$edit_slug] : [];
                $settings = $this->save_single_form_settings($edit_slug, $row, $forms_before_generate[$edit_slug]);
                update_option(self::OPTION_NAME, $settings, false);
                $forms_after_save = $this->get_forms();
                $form_for_generation = $forms_after_save[$edit_slug] ?? $forms_before_generate[$edit_slug];
                $generated_html = $edit_slug === 'testneveles-felmentes'
                    ? $this->get_default_testneveles_pdf_html_template()
                    : $this->get_default_generic_pdf_html_template($form_for_generation);
                $settings = get_option(self::OPTION_NAME, []);
                $settings = is_array($settings) ? $settings : [];
                $this->set_form_setting_value($settings, $edit_slug, $form_for_generation, 'pdf_html_template', $generated_html);
                update_option(self::OPTION_NAME, $settings, false);
                $selected_slug = $edit_slug;
                $saved = true;
                $notice = 'A PDF HTML alapsablon az aktuális mezőkből újragenerálva. A DOCX sablon nem változott.';
                $this->platform_log('info', 'PDF HTML alapsablon újragenerálva.', ['slug' => $edit_slug]);
            } else {
                $notice = 'A PDF HTML sablongeneráláshoz tartozó űrlap nem található.';
                $notice_type = 'error';
            }
        }

        if (isset($_POST['szegbp_forms_generate_templates'])) {
            check_admin_referer('szegbp_forms_admin_save');
            $edit_slug = sanitize_key((string)($_POST['szegbp_forms_edit_slug'] ?? ''));
            $forms_before_generate = $this->get_forms();
            if ($edit_slug !== '' && isset($forms_before_generate[$edit_slug])) {
                $row = is_array($_POST['szegbp_forms'][$edit_slug] ?? null) ? $_POST['szegbp_forms'][$edit_slug] : [];
                $settings = $this->save_single_form_settings($edit_slug, $row, $forms_before_generate[$edit_slug]);
                update_option(self::OPTION_NAME, $settings, false);
                $forms_after_save = $this->get_forms();
                $form_for_generation = $forms_after_save[$edit_slug] ?? $forms_before_generate[$edit_slug];
                $generated_docx = $this->generate_docx_template_for_form($edit_slug, $form_for_generation);
                $settings = get_option(self::OPTION_NAME, []);
                $settings = is_array($settings) ? $settings : [];
                if ($generated_docx !== '') {
                    $old_generated_target = (string)($form_for_generation['docx_template'] ?? '');
                    if ($old_generated_target !== '' && $old_generated_target !== $generated_docx) {
                        $this->delete_stored_template_file($old_generated_target);
                    }
                    $this->set_form_setting_value($settings, $edit_slug, $form_for_generation, 'docx_template', $generated_docx);
                }
                // v0.4.2: ez a művelet kizárólag a DOCX sablont kezeli.
                // A mentett HTML sablont soha nem írja felül; HTML csak külön gombbal generálható/importálható.
                $this->set_form_setting_value($settings, $edit_slug, $form_for_generation, 'template_origin', 'auto');
                $this->set_form_setting_array_value($settings, $edit_slug, $form_for_generation, 'docx_pairing_report', []);
                update_option(self::OPTION_NAME, $settings, false);
                $selected_slug = $edit_slug;
                $saved = true;
                if ($generated_docx !== '') {
                    $notice = 'Az automatikus DOCX sablon elkészült. A meglévő HTML dokumentumsablon változatlan maradt.';
                } else {
                    $notice = 'A DOCX sablon nem hozható létre. Ellenőrizd, hogy a ZipArchive PHP bővítmény elérhető-e. A HTML dokumentumsablon nem változott.';
                    $notice_type = 'warning';
                }
                $this->platform_log('info', 'Automatikus DOCX sablon létrehozva.', ['slug' => $edit_slug, 'docx' => $generated_docx !== '']);
            } else {
                $notice = 'A sablongeneráláshoz tartozó űrlap nem található.';
                $notice_type = 'error';
            }
        }


        if (isset($_POST['szegbp_forms_generate_pdf_from_docx'])) {
            check_admin_referer('szegbp_forms_admin_save');
            $edit_slug = sanitize_key((string)($_POST['szegbp_forms_edit_slug'] ?? ''));
            $forms_before_generate = $this->get_forms();
            if ($edit_slug !== '' && isset($forms_before_generate[$edit_slug])) {
                $row = is_array($_POST['szegbp_forms'][$edit_slug] ?? null) ? $_POST['szegbp_forms'][$edit_slug] : [];
                $settings = $this->save_single_form_settings($edit_slug, $row, $forms_before_generate[$edit_slug]);

                // Ha a felhasználó ugyanebben a műveletben új DOCX-et választott ki,
                // előbb mentsük el, hogy már abból készülhessen a PDF sablon.
                $upload_messages = array_merge($upload_messages, $this->handle_admin_template_uploads($settings));
                update_option(self::OPTION_NAME, $settings, false);

                $forms_after_save = $this->get_forms();
                $form_for_generation = $forms_after_save[$edit_slug] ?? $forms_before_generate[$edit_slug];
                $conversion = $this->generate_pdf_template_from_docx($edit_slug, $form_for_generation);

                if (!empty($conversion['ok']) && !empty($conversion['pdf'])) {
                    $settings = get_option(self::OPTION_NAME, []);
                    $settings = is_array($settings) ? $settings : [];

                    $old_pdf = (string)($form_for_generation['pdf_template'] ?? '');
                    $old_preview = (string)($form_for_generation['pdf_map_preview'] ?? '');
                    $new_pdf = (string)$conversion['pdf'];
                    $new_preview = (string)($conversion['preview'] ?? '');

                    if ($old_pdf !== '' && $old_pdf !== $new_pdf) {
                        $this->delete_stored_template_file($old_pdf);
                    }
                    if ($old_preview !== '' && $old_preview !== $new_preview) {
                        $this->delete_stored_template_file($old_preview);
                    }

                    $this->set_form_setting_value($settings, $edit_slug, $form_for_generation, 'pdf_template', $new_pdf);
                    $this->set_form_setting_value($settings, $edit_slug, $form_for_generation, 'pdf_map_preview', $new_preview);
                    $this->set_form_setting_array_value($settings, $edit_slug, $form_for_generation, 'pdf_field_map', []);
                    update_option(self::OPTION_NAME, $settings, false);

                    $saved = true;
                    $selected_slug = $edit_slug;
                    if ($new_preview !== '') {
                        $notice = 'A PDF sablon elkészült a DOCX-ből, és az első oldal előnézete is elkészült. A korábbi mezőtérkép törölve lett; helyezd rá újra a mezőket, majd mentsd az űrlapot.';
                    } else {
                        $notice = 'A PDF sablon elkészült a DOCX-ből. Az automatikus előnézeti kép nem készíthető el ezen a szerveren, ezért a mezőtérképhez tölts fel teljes oldalas PNG/JPG előnézetet.';
                        $notice_type = 'warning';
                    }
                    $this->platform_log('info', 'PDF sablon DOCX-ből létrehozva.', [
                        'slug' => $edit_slug,
                        'preview' => $new_preview !== '',
                        'engine' => (string)($conversion['engine'] ?? ''),
                    ]);
                } else {
                    $notice = (string)($conversion['message'] ?? 'A PDF sablon DOCX-ből történő előállítása nem sikerült.');
                    $notice_type = 'warning';
                    $selected_slug = $edit_slug;
                }
            } else {
                $notice = 'A DOCX→PDF sablongeneráláshoz tartozó űrlap nem található.';
                $notice_type = 'error';
            }
        }


        if (isset($_POST['szegbp_forms_generate_pdf_map_preview'])) {
            check_admin_referer('szegbp_forms_admin_save');
            $edit_slug = sanitize_key((string)($_POST['szegbp_forms_edit_slug'] ?? ''));
            $forms_before_preview = $this->get_forms();
            if ($edit_slug !== '' && isset($forms_before_preview[$edit_slug])) {
                $row = is_array($_POST['szegbp_forms'][$edit_slug] ?? null) ? $_POST['szegbp_forms'][$edit_slug] : [];
                $settings = $this->save_single_form_settings($edit_slug, $row, $forms_before_preview[$edit_slug]);
                update_option(self::OPTION_NAME, $settings, false);
                $forms_after_save = $this->get_forms();
                $form_for_preview = $forms_after_save[$edit_slug] ?? $forms_before_preview[$edit_slug];
                $preview = $this->generate_pdf_map_preview_from_relative((string)($form_for_preview['pdf_template'] ?? ''), $edit_slug);
                if ($preview !== '') {
                    $settings = get_option(self::OPTION_NAME, []);
                    $settings = is_array($settings) ? $settings : [];
                    $this->delete_stored_template_file((string)($form_for_preview['pdf_map_preview'] ?? ''));
                    $this->set_form_setting_value($settings, $edit_slug, $form_for_preview, 'pdf_map_preview', $preview);
                    update_option(self::OPTION_NAME, $settings, false);
                    $notice = 'A PDF első oldalából elkészült a mezőtérkép előnézeti képe. Helyezd rá a mezőket, majd mentsd az űrlapot.';
                    $saved = true;
                    $this->platform_log('info', 'PDF mezőtérkép előnézet létrehozva.', ['slug' => $edit_slug]);
                } else {
                    $notice = class_exists('Imagick')
                        ? 'A PDF előnézeti képét a szerver nem tudta elkészíteni. Tölts fel kézzel egy teljes oldalas PNG/JPG előnézetet.'
                        : 'A szerveren nincs Imagick PDF-renderelés. Tölts fel kézzel egy teljes oldalas PNG/JPG előnézetet.';
                    $notice_type = 'warning';
                }
                $selected_slug = $edit_slug;
            } else {
                $notice = 'A PDF mezőtérképhez tartozó űrlap nem található.';
                $notice_type = 'error';
            }
        }

        if (isset($_POST['szegbp_forms_save_single'])) {
            check_admin_referer('szegbp_forms_admin_save');
            $edit_slug = sanitize_key((string)($_POST['szegbp_forms_edit_slug'] ?? ''));
            $forms_before_save = $this->get_forms();
            if ($edit_slug !== '' && isset($forms_before_save[$edit_slug])) {
                $row = is_array($_POST['szegbp_forms'][$edit_slug] ?? null) ? $_POST['szegbp_forms'][$edit_slug] : [];
                $settings = $this->save_single_form_settings($edit_slug, $row, $forms_before_save[$edit_slug]);
                $this->handle_selected_blank_docx_upload($settings, $edit_slug, $forms_before_save[$edit_slug], $upload_messages);
                $upload_messages = array_merge($upload_messages, $this->handle_admin_template_uploads($settings));
                update_option(self::OPTION_NAME, $settings, false);
                $this->platform_log('info', 'Űrlap beállításai mentve.', ['slug' => $edit_slug, 'upload_messages' => count($upload_messages)]);
                $selected_slug = $edit_slug;
                $saved = true;
                $notice = 'A kiválasztott űrlap beállításai mentve.';
            } else {
                $notice = 'A szerkesztett űrlap nem található.';
                $notice_type = 'error';
            }
        }

        if (isset($_POST['szegbp_forms_reset'])) {
            check_admin_referer('szegbp_forms_admin_reset');
            if (!empty($_POST['szegbp_forms_reset_delete_templates'])) {
                $this->delete_referenced_template_files($this->get_forms());
                $upload_messages[] = 'A jelenleg hozzárendelt feltöltött sablonfájlok törölve lettek.';
            }
            delete_option(self::OPTION_NAME);
            $this->platform_log('warning', 'Űrlapok alapbeállításai visszaállítva.', ['templates_deleted' => !empty($_POST['szegbp_forms_reset_delete_templates'])]);
            $selected_slug = '';
            $copy_source_slug = '';
            $reset = true;
        }

        $forms = $this->get_forms();
        if ($selected_slug !== '' && !isset($forms[$selected_slug])) {
            $selected_slug = '';
        }
        if ($copy_source_slug !== '' && !isset($forms[$copy_source_slug])) {
            $copy_source_slug = '';
        }

        $selected_form = $selected_slug !== '' ? $forms[$selected_slug] : null;
        $copy_source = $copy_source_slug !== '' ? $forms[$copy_source_slug] : null;
        $show_new_form = isset($_GET['new_form']) || isset($_POST['szegbp_forms_add']);
        $focus_mode = $selected_form !== null || $copy_source !== null || $show_new_form;
        $base_url = admin_url('admin.php?page=szegbp-forms');
        ?>
        <div class="wrap szegbp-admin-page szegbp-forms-admin">
            <div class="szegbp-admin-hero">
                <div>
                    <p class="szegbp-admin-kicker">SZEGBP</p>
                    <h1>Űrlapok és nyomtatványok</h1>
                    <p>
                        Böngészőben kitölthető és letölthető iskolai nyomtatványok kezelése.
                        A látogatói adatok <strong>nem kerülnek adatbázisba</strong>.
                    </p>
                </div>
                <span class="szegbp-admin-version">v<?php echo esc_html(self::VERSION); ?></span>
            </div>

            <?php if ($saved): ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice !== '' ? $notice : 'Beállítások mentve.'); ?></p></div>
            <?php elseif ($notice !== ''): ?>
                <div class="notice notice-<?php echo esc_attr($notice_type); ?> is-dismissible"><p><?php echo esc_html($notice); ?></p></div>
            <?php endif; ?>
            <?php if ($reset): ?>
                <div class="notice notice-success is-dismissible"><p>Alapbeállítások visszaállítva.</p></div>
            <?php endif; ?>
            <?php foreach ($upload_messages as $upload_message): ?>
                <div class="notice notice-info is-dismissible"><p><?php echo esc_html($upload_message); ?></p></div>
            <?php endforeach; ?>

            <?php $this->render_platform_status_card(); ?>

            <div class="szegbp-forms-admin-grid<?php echo $focus_mode ? ' is-focus-mode' : ''; ?>">
                <main class="szegbp-forms-admin-main">
                    <?php if (!$selected_form && !$copy_source): ?>
                    <section class="szegbp-admin-card szegbp-forms-admin-card szegbp-forms-overview">
                        <div class="szegbp-forms-card-header">
                            <div>
                                <h2><?php echo $show_new_form ? 'Új űrlap létrehozása' : 'Űrlapok áttekintése'; ?></h2>
                                <p class="description"><?php echo $show_new_form ? 'Az új űrlap és a hozzá tartozó sablonok egy külön, zavartalan nézetben készíthetők el.' : 'Válassz egy űrlapot szerkesztéshez. Szerkesztéskor a lista eltűnik, és csak az aktuális űrlap marad a képernyőn.'; ?></p>
                            </div>
                            <?php if ($show_new_form): ?>
                                <a class="button" href="<?php echo esc_url($base_url); ?>">← Vissza az űrlapokhoz</a>
                            <?php else: ?>
                                <a class="button button-primary" href="<?php echo esc_url(add_query_arg('new_form', '1', $base_url)); ?>">Új űrlap</a>
                            <?php endif; ?>
                        </div>

                        <?php if ($show_new_form): ?>
                            <form method="post" enctype="multipart/form-data">
                                <?php wp_nonce_field('szegbp_forms_admin_save'); ?>
                                <section class="szegbp-forms-admin-formbox szegbp-forms-admin-new-form">
                                    <div class="szegbp-forms-card-header">
                                        <h3>Új űrlap hozzáadása</h3>
                                        <a class="button" href="<?php echo esc_url($base_url); ?>">← Vissza az űrlapokhoz</a>
                                    </div>
                                    <p class="description">Az űrlap létrehozásakor a rendszer DOCX sablont készít. A kitöltött PDF-hez használt HTML sablont ezután külön importálhatod vagy külön gombbal generálhatod, így a DOCX műveletek nem írják felül a HTML-t.</p>
                                    <table class="form-table" role="presentation">
                                        <tr>
                                            <th scope="row"><label for="szegbp_forms_new_title">Cím</label></th>
                                            <td><input class="regular-text" id="szegbp_forms_new_title" type="text" name="szegbp_forms_new[title]" placeholder="pl. Tanulói kikérő" required></td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><label for="szegbp_forms_new_slug">Technikai azonosító</label></th>
                                            <td>
                                                <input class="regular-text" id="szegbp_forms_new_slug" type="text" name="szegbp_forms_new[slug]" placeholder="pl. tanuloi-kikero">
                                                <p class="description">Ha üresen marad, a rendszer a cím alapján készíti el.</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><label for="szegbp_forms_new_description">Rövid leírás</label></th>
                                            <td><textarea class="large-text" rows="2" id="szegbp_forms_new_description" name="szegbp_forms_new[description]" placeholder="Rövid magyarázat a látogatónak."></textarea></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Létrehozás módja</th>
                                            <td>
                                                <label style="display:block;margin-bottom:6px;"><input type="radio" name="szegbp_forms_new[creation_mode]" value="auto" checked> <strong>Automatikus DOCX sablon az alábbi mezőkből</strong></label>
                                                <span class="description">A plugin DOCX sablont készít. A HTML dokumentumsablon külön művelettel készül.</span>
                                                <label style="display:block;margin:12px 0 6px;"><input type="radio" name="szegbp_forms_new[creation_mode]" value="docx"> <strong>Kész DOCX nyomtatványból – automatikus párosítással</strong></label>
                                                <span class="description">A plugin megkeresi a kitöltési helyeket, mezőket javasol és helyőrzőket illeszt a Word-dokumentumba. HTML sablont csak külön kérésre készít.</span>

                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Kitöltési DOCX sablon</th>
                                            <td>
                                                <input type="file" name="szegbp_forms_new_source_docx" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
                                                <p class="description">A „Kész DOCX nyomtatványból” mód használja. Automatikus párosításnál a „Tanuló neve: ............” jellegű sorok és a címke + üres kitöltési cellát tartalmazó táblázatok adják a legjobb eredményt.</p>
                                                <label><input type="checkbox" name="szegbp_forms_new[extract_docx_fields]" value="1" checked> A DOCX-ben felismert mezőket használja / egészítse ki az űrlap mezőiként</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Üres DOCX nyomtatvány</th>
                                            <td>
                                                <input type="file" name="szegbp_forms_new_blank_docx" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
                                                <p class="description">Opcionális. Ez a fájl kizárólag az üres Word nyomtatvány letöltéséhez tartozik, és a plugin soha nem módosítja.</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Mezők</th>
                                            <td>
                                                <?php echo $this->render_admin_field_builder('szegbp_forms_new[fields_definition]', 'szegbp_forms_new_fields', $this->get_default_custom_fields(), true); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Megjelenés</th>
                                            <td><label><input type="checkbox" name="szegbp_forms_new[enabled]" value="1"> Aktívként hozza létre – azonnal jelenjen meg a nyilvános listában</label><p class="description">Kikapcsolva az új űrlap <strong>Piszkozat</strong> állapotban jön létre, így biztonságosan tesztelhető.</p></td>
                                        </tr>
                                    </table>
                                    <p><button type="submit" name="szegbp_forms_add" class="button button-primary">Űrlap és DOCX sablon létrehozása</button></p>
                                </section>
                            </form>
                        <?php endif; ?>

                        <?php if (!$show_new_form): ?>
                        <table class="widefat striped szegbp-forms-overview-table">
                            <thead>
                                <tr>
                                    <th>Űrlap</th>
                                    <th>Állapot</th>
                                    <th>Mezők</th>
                                    <th>Sablonok</th>
                                    <th>Művelet</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($forms as $slug => $form):
                                    $docx_custom = $this->get_form_template_file($form, 'docx') !== null;
                                    $blank_docx_custom = $this->get_form_template_file($form, 'blank_docx') !== null;
                                    $pdf_custom = $this->get_form_template_file($form, 'pdf') !== null;
                                    $html_custom = trim((string)($form['pdf_html_template'] ?? '')) !== '';
                                    $has_builtin_pdf = !empty($form['pdf_file']);
                                ?>
                                    <tr class="<?php echo $slug === $selected_slug ? 'is-selected' : ''; ?>">
                                        <td>
                                            <strong><?php echo esc_html((string)$form['title']); ?></strong>
                                            <?php if (!empty($form['custom'])): ?><span class="szegbp-forms-tag is-custom">Saját</span><?php else: ?><span class="szegbp-forms-tag is-default">Beépített</span><?php endif; ?>
                                            <div class="description"><code><?php echo esc_html($slug); ?></code></div>
                                        </td>
                                        <td>
                                            <span class="szegbp-forms-status <?php echo !empty($form['enabled']) ? 'is-active' : 'is-draft'; ?>">
                                                <?php echo !empty($form['enabled']) ? 'Aktív' : 'Piszkozat'; ?>
                                            </span>
                                        </td>
                                        <td><strong><?php echo esc_html((string)count((array)($form['fields'] ?? []))); ?></strong> mező</td>
                                        <td class="szegbp-forms-template-tags">
                                            <span class="szegbp-forms-tag <?php echo $docx_custom ? 'is-file' : 'is-default'; ?>">Sablon DOCX: <?php echo $docx_custom ? 'egyedi' : 'generált'; ?></span>
                                            <span class="szegbp-forms-tag <?php echo $blank_docx_custom ? 'is-file' : 'is-missing'; ?>">Üres DOCX: <?php echo $blank_docx_custom ? 'feltöltve' : 'nincs külön'; ?></span>
                                            <span class="szegbp-forms-tag <?php echo ($pdf_custom || $has_builtin_pdf) ? 'is-file' : 'is-missing'; ?>">PDF: <?php echo $pdf_custom ? 'egyedi' : ($has_builtin_pdf ? 'beépített' : 'nincs'); ?></span>
                                            <span class="szegbp-forms-tag <?php echo $html_custom ? 'is-file' : 'is-default'; ?>">HTML: <?php echo $html_custom ? 'egyedi' : 'alap'; ?></span>
                                        </td>
                                        <td class="szegbp-forms-row-actions">
                                            <a class="button button-small" href="<?php echo esc_url(add_query_arg('form_edit', $slug, $base_url)); ?>">Szerkesztés</a>
                                            <a class="button button-small" href="<?php echo esc_url(add_query_arg('form_copy', $slug, $base_url)); ?>">Másolás</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </section>
                    <?php endif; ?>

                    <?php if ($copy_source): ?>
                        <section class="szegbp-admin-card szegbp-forms-admin-card szegbp-forms-copy-panel">
                            <div class="szegbp-forms-card-header">
                                <div>
                                    <h2>Űrlap másolása</h2>
                                    <p class="description">Forrás: <strong><?php echo esc_html((string)$copy_source['title']); ?></strong>. A mezők és a leírás átmásolódnak. Kérésre a DOCX/PDF/HTML sablonokból is külön másolat készül.</p>
                                </div>
                                <a class="button" href="<?php echo esc_url($base_url); ?>">← Vissza az űrlapokhoz</a>
                            </div>
                            <form method="post">
                                <?php wp_nonce_field('szegbp_forms_admin_copy'); ?>
                                <input type="hidden" name="szegbp_forms_copy_source" value="<?php echo esc_attr($copy_source_slug); ?>">
                                <table class="form-table" role="presentation">
                                    <tr>
                                        <th scope="row"><label for="szegbp_copy_title">Új cím</label></th>
                                        <td><input class="regular-text" id="szegbp_copy_title" type="text" name="szegbp_forms_copy_data[title]" value="<?php echo esc_attr((string)$copy_source['title'] . ' – másolat'); ?>" required></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label for="szegbp_copy_slug">Új technikai azonosító</label></th>
                                        <td><input class="regular-text" id="szegbp_copy_slug" type="text" name="szegbp_forms_copy_data[slug]" value="<?php echo esc_attr($copy_source_slug . '-masolat'); ?>"></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Megjelenés</th>
                                        <td>
                                            <label><input type="checkbox" name="szegbp_forms_copy_data[enabled]" value="1"> Aktív másolat – azonnal jelenjen meg a nyilvános listában</label>
                                            <p class="description">Kikapcsolva a másolat Piszkozat állapotú lesz.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Sablonok</th>
                                        <td>
                                            <label><input type="checkbox" name="szegbp_forms_copy_data[copy_templates]" value="1" checked> DOCX/PDF/HTML sablonok másolása is</label>
                                            <p class="description">A fájlokról külön példány készül, ezért a másolat későbbi módosítása nem írja felül az eredeti űrlap sablonjait.</p>
                                        </td>
                                    </tr>
                                </table>
                                <p><button type="submit" name="szegbp_forms_copy" class="button button-primary">Másolat létrehozása</button></p>
                            </form>
                        </section>
                    <?php endif; ?>

                    <?php if ($selected_form): ?>
                        <section class="szegbp-admin-card szegbp-forms-admin-card szegbp-forms-editor">
                            <div class="szegbp-forms-card-header">
                                <div>
                                    <h2><?php echo esc_html((string)$selected_form['title']); ?> szerkesztése</h2>
                                    <p class="description">Azonosító: <code><?php echo esc_html($selected_slug); ?></code> &nbsp; Shortcode: <code>[szegbp_form id=&quot;<?php echo esc_html($selected_slug); ?>&quot;]</code></p>
                                </div>
                                <a class="button" href="<?php echo esc_url($base_url); ?>">← Vissza az űrlapokhoz</a>
                            </div>
                            <form method="post" enctype="multipart/form-data">
                                <?php wp_nonce_field('szegbp_forms_admin_save'); ?>
                                <?php wp_nonce_field('szegbp_forms_admin_preview', 'szegbp_forms_preview_nonce', false); ?>
                                <input type="hidden" name="szegbp_forms_edit_slug" value="<?php echo esc_attr($selected_slug); ?>">
                                <input type="hidden" name="szegbp_preview_html" value="" data-szegbp-preview-html>
                                <?php if (!empty($selected_form['custom'])): ?>
                                    <input type="hidden" name="szegbp_forms[<?php echo esc_attr($selected_slug); ?>][is_custom]" value="1">
                                <?php endif; ?>
                                <div class="szegbp-forms-sticky-save">
                                    <div>
                                        <strong><?php echo esc_html((string)$selected_form['title']); ?></strong>
                                        <span class="description">A mentés görgetés közben is elérhető.</span>
                                    </div>
                                    <button type="submit" name="szegbp_forms_save_single" class="button button-primary">Mentés</button>
                                </div>
                                <section class="szegbp-forms-admin-formbox">
                                    <p>
                                        <label>
                                            <input type="checkbox" name="szegbp_forms[<?php echo esc_attr($selected_slug); ?>][enabled]" value="1" <?php checked(!empty($selected_form['enabled'])); ?>>
                                            Aktív – jelenjen meg a nyilvános űrlaplistában
                                        </label>
                                        <span class="description"> Kikapcsolva az űrlap Piszkozat állapotú: adminból előnézhető és tesztelhető, de a látogatók nem érik el.</span>
                                    </p>
                                    <table class="form-table" role="presentation">
                                        <tr>
                                            <th scope="row"><label for="szegbp_forms_<?php echo esc_attr($selected_slug); ?>_title">Cím</label></th>
                                            <td><input class="regular-text" id="szegbp_forms_<?php echo esc_attr($selected_slug); ?>_title" type="text" name="szegbp_forms[<?php echo esc_attr($selected_slug); ?>][title]" value="<?php echo esc_attr((string)$selected_form['title']); ?>"></td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><label for="szegbp_forms_<?php echo esc_attr($selected_slug); ?>_description">Rövid leírás</label></th>
                                            <td><textarea class="large-text" rows="3" id="szegbp_forms_<?php echo esc_attr($selected_slug); ?>_description" name="szegbp_forms[<?php echo esc_attr($selected_slug); ?>][description]"><?php echo esc_textarea((string)$selected_form['description']); ?></textarea></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Mezők</th>
                                            <td>
                                                <?php echo $this->render_admin_field_builder('szegbp_forms[' . $selected_slug . '][fields_definition]', 'szegbp_forms_' . $selected_slug . '_fields', (array)($selected_form['fields'] ?? []), !empty($selected_form['custom'])); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                            </td>
                                        </tr>
                                        <?php echo $this->render_admin_template_rows($selected_slug, $selected_form); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                    </table>
                                </section>
                                <?php echo $this->render_template_diagnostics_panel($selected_slug, $selected_form); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                <p class="submit szegbp-forms-editor-actions">
                                    <button type="submit" name="szegbp_forms_save_single" class="button button-primary">Űrlap mentése</button>
                                    <button type="submit" name="szegbp_forms_generate_templates" class="button" onclick="return confirm('Létrehozzam az aktuális mezőkből az automatikus DOCX sablont? A jelenlegi kitöltési DOCX sablon lecserélődik. A HTML dokumentumsablon nem változik.');">Automatikus DOCX sablon létrehozása</button>
                                    <button type="submit" class="button" data-szegbp-preview-submit formaction="<?php echo esc_url(admin_url('admin-post.php?action=szegbp_forms_preview')); ?>" formmethod="post" formtarget="_blank" formnovalidate>Előnézet / tesztkitöltés</button>
                                </p>
                            </form>

                            <section class="szegbp-forms-danger-zone">
                                <h3>Űrlap törlése</h3>
                                <p>
                                    A törlés az adminból és a nyilvános megjelenésből is eltávolítja ezt az űrlapot.
                                    <?php if (empty($selected_form['custom'])): ?>
                                        A beépített alapűrlap később az <strong>Alapbeállítások visszaállítása</strong> funkcióval visszahozható.
                                    <?php else: ?>
                                        Az egyedi űrlap törlése nem vonható vissza.
                                    <?php endif; ?>
                                </p>
                                <form method="post" onsubmit="return confirm('<?php echo esc_js(!empty($selected_form['custom']) ? 'Biztosan törlöd ezt az űrlapot? Az egyedi űrlap törlése nem vonható vissza.' : 'Biztosan törlöd ezt a beépített űrlapot? Később az Alapbeállítások visszaállítása funkcióval visszahozható.'); ?>');">
                                    <?php wp_nonce_field('szegbp_forms_admin_delete'); ?>
                                    <input type="hidden" name="szegbp_forms_delete_slug" value="<?php echo esc_attr($selected_slug); ?>">
                                    <p><label><input type="checkbox" name="szegbp_forms_delete_templates" value="1" checked> A hozzárendelt sablonfájlok törlése is</label></p>
                                    <button type="submit" name="szegbp_forms_delete" class="button button-link-delete">Űrlap törlése</button>
                                </form>
                            </section>
                        </section>
                    <?php endif; ?>
                </main>

                <aside class="szegbp-admin-card szegbp-forms-admin-card szegbp-forms-admin-help">
                    <h2>Használat</h2>
                    <p>Űrlaplista megjelenítése:</p>
                    <code>[szegbp_forms]</code>

                    <p>Egy konkrét űrlap megjelenítése:</p>
                    <code>[szegbp_form id="igazolasi-kerelem"]</code>

                    <h3>Javasolt munkamenet</h3>
                    <ol>
                        <li>Hozd létre az űrlapot mezőkből, vagy tölts fel kiinduló DOCX-et.</li>
                        <li>Ellenőrizd az automatikus mezőpárosítást és a DOCX sablont, majd külön importáld vagy generáld a HTML dokumentumsablont.</li>
                        <li>Ellenőrizd az üres és kitöltött letöltéseket.</li>
                        <li>Csak ezután kapcsold be a nyilvános listában.</li>
                    </ol>

                    <h3>Stabilitási védelem</h3>
                    <ul>
                        <li>DOCX-nél szerveroldali mezőellenőrzés fut.</li>
                        <li>A túl hosszú egyoldalas PDF nem készül el adatvesztéssel.</li>
                        <li>A feltöltött DOCX sablon helyőrzőit az admin ellenőrzi.</li>
                    </ul>

                    <section class="szegbp-forms-admin-privacy">
                        <h3>Adatkezelési kiegészítés</h3>
                        <p>Az adatkezelési tájékoztató oldalra ezt a shortcode-ot érdemes beilleszteni:</p>
                        <code>[szegbp_forms_adatkezeles]</code>
                        <p class="description">A kiegészítés leírja, hogy a PDF és a nyomtatási nézet böngészőben készül, a kitöltött DOCX pedig átmeneti szerveroldali feldolgozást használ adatbázis-mentés nélkül.</p>
                        <?php $privacy_url = $this->forms_privacy_policy_url(); ?>
                        <?php if ($privacy_url !== ''): ?>
                            <p><a class="button button-small" href="<?php echo esc_url($privacy_url); ?>" target="_blank" rel="noopener">Adatkezelési oldal megnyitása</a></p>
                        <?php endif; ?>
                    </section>

                    <form method="post" class="szegbp-forms-reset-form" onsubmit="return confirm('Biztosan visszaállítod az alapbeállításokat? A kijelölt sablonfájlok törlése nem vonható vissza.');">
                        <?php wp_nonce_field('szegbp_forms_admin_reset'); ?>
                        <h3>Visszaállítás</h3>
                        <p><label><input type="checkbox" name="szegbp_forms_reset_delete_templates" value="1"> A jelenleg hozzárendelt sablonfájlok törlése is</label></p>
                        <p><button type="submit" name="szegbp_forms_reset" class="button">Alapbeállítások visszaállítása</button></p>
                    </form>
                </aside>
            </div>
        </div>
        <?php
    }

    private function save_single_form_settings(string $slug, array $row, array $current_form): array
    {
        $settings = get_option(self::OPTION_NAME, []);
        $settings = is_array($settings) ? $settings : [];
        $is_custom = !empty($current_form['custom']);
        $sanitized = $this->sanitize_single_form_settings($slug, $row, $current_form, $is_custom);

        if ($is_custom) {
            if (!isset($settings['_custom_forms']) || !is_array($settings['_custom_forms'])) {
                $settings['_custom_forms'] = [];
            }
            $settings['_custom_forms'][$slug] = $sanitized;
        } else {
            $settings[$slug] = $sanitized;
        }

        return $settings;
    }

    private function duplicate_form_to_settings(string $source_slug, array $copy_raw, ?string &$created_slug = null, ?array &$copy_report = null): array
    {
        $created_slug = '';
        $copy_report = ['templates_copied' => false, 'files' => []];
        $settings = get_option(self::OPTION_NAME, []);
        $settings = is_array($settings) ? $settings : [];
        $forms = $this->get_forms();

        if (!isset($forms[$source_slug])) {
            return $settings;
        }

        $title = sanitize_text_field((string)($copy_raw['title'] ?? ''));
        if ($title === '') {
            return $settings;
        }

        $custom_forms = is_array($settings['_custom_forms'] ?? null) ? $settings['_custom_forms'] : [];
        $requested_slug = (string)($copy_raw['slug'] ?? '');
        $new_slug = $this->sanitize_form_slug($requested_slug !== '' ? $requested_slug : $title);
        $new_slug = $this->make_unique_form_slug($new_slug, array_keys($forms));
        $source_form = $forms[$source_slug];
        $copy_templates = !empty($copy_raw['copy_templates']);

        $docx_template = '';
        $blank_docx = '';
        $pdf_template = '';
        $pdf_html_file = '';
        $pdf_html_template = '';
        $pdf_map_preview = '';
        $pdf_field_map = [];
        $template_origin = '';
        $pairing_report = [];

        if ($copy_templates) {
            $docx_template = $this->copy_stored_template_file((string)($source_form['docx_template'] ?? ''), $new_slug, 'docx');
            $blank_docx = $this->copy_stored_template_file((string)($source_form['blank_docx'] ?? ''), $new_slug . '-blank', 'docx');
            $pdf_template = $this->copy_stored_template_file((string)($source_form['pdf_template'] ?? ''), $new_slug, 'pdf');
            $pdf_html_file = $this->copy_stored_template_file((string)($source_form['pdf_html_file'] ?? ''), $new_slug, 'html');
            $pdf_html_template = $this->sanitize_pdf_html_template((string)($source_form['pdf_html_template'] ?? ''));
            $pdf_map_preview = $this->copy_stored_template_file((string)($source_form['pdf_map_preview'] ?? ''), $new_slug, 'image');
            $pdf_field_map = $this->sanitize_pdf_field_map($source_form['pdf_field_map'] ?? [], (array)($source_form['fields'] ?? []));
            $template_origin = sanitize_key((string)($source_form['template_origin'] ?? ''));
            $pairing_report = $this->sanitize_docx_pairing_report((array)($source_form['docx_pairing_report'] ?? []));
            $copy_report = [
                'templates_copied' => $docx_template !== '' || $blank_docx !== '' || $pdf_template !== '' || $pdf_html_file !== '' || $pdf_html_template !== '' || $pdf_map_preview !== '',
                'files' => array_values(array_filter([$docx_template, $blank_docx, $pdf_template, $pdf_html_file, $pdf_map_preview])),
            ];
        }

        $custom_forms[$new_slug] = [
            'custom' => true,
            'enabled' => !empty($copy_raw['enabled']) ? 1 : 0,
            'title' => $title,
            'description' => sanitize_textarea_field((string)($source_form['description'] ?? '')),
            'fields' => $this->normalize_saved_fields((array)($source_form['fields'] ?? [])),
            'docx_template' => $docx_template,
            'blank_docx' => $blank_docx,
            'pdf_template' => $pdf_template,
            'pdf_html_file' => $pdf_html_file,
            'pdf_html_template' => $pdf_html_template,
            'pdf_map_preview' => $pdf_map_preview,
            'pdf_field_map' => $pdf_field_map,
            'template_origin' => $template_origin,
            'docx_pairing_report' => $pairing_report,
        ];

        $settings['_custom_forms'] = $custom_forms;
        $created_slug = $new_slug;
        return $settings;
    }

    private function sanitize_admin_settings(array $raw, array $new_raw = []): array
    {
        $defaults = $this->get_default_forms();
        $current = get_option(self::OPTION_NAME, []);
        $existing_custom = is_array($current) && is_array($current['_custom_forms'] ?? null) ? $current['_custom_forms'] : [];
        $settings = [];

        foreach ($defaults as $slug => $default) {
            $row = is_array($raw[$slug] ?? null) ? $raw[$slug] : [];
            $settings[$slug] = $this->sanitize_single_form_settings($slug, $row, $default, false);
        }

        $custom_forms = [];
        foreach ($existing_custom as $slug => $default) {
            $slug = sanitize_key((string)$slug);
            if ($slug === '') {
                continue;
            }

            $row = is_array($raw[$slug] ?? null) ? $raw[$slug] : [];
            if (!empty($row['delete_form'])) {
                $this->delete_stored_template_file((string)($default['docx_template'] ?? ''));
                $this->delete_stored_template_file((string)($default['blank_docx'] ?? ''));
                $this->delete_stored_template_file((string)($default['pdf_template'] ?? ''));
                $this->delete_stored_template_file((string)($default['pdf_html_file'] ?? ''));
                $this->delete_stored_template_file((string)($default['pdf_map_preview'] ?? ''));
                continue;
            }

            $custom_forms[$slug] = $this->sanitize_single_form_settings($slug, $row, is_array($default) ? $default : [], true);
        }

        $new_title = sanitize_text_field((string)($new_raw['title'] ?? ''));
        if ($new_title !== '') {
            $new_slug_raw = (string)($new_raw['slug'] ?? '');
            $new_slug = $this->sanitize_form_slug($new_slug_raw !== '' ? $new_slug_raw : $new_title);
            $new_slug = $this->make_unique_form_slug($new_slug, array_merge(array_keys($defaults), array_keys($custom_forms)));
            $fields = $this->parse_fields_definition((string)($new_raw['fields_definition'] ?? ''), []);
            if (empty($fields)) {
                $fields = $this->get_default_custom_fields();
            }

            $custom_forms[$new_slug] = [
                'custom' => true,
                'enabled' => !empty($new_raw['enabled']) ? 1 : 0,
                'title' => $new_title,
                'description' => sanitize_textarea_field((string)($new_raw['description'] ?? '')),
                'fields' => $fields,
                'docx_template' => '',
                'blank_docx' => '',
                'pdf_template' => '',
                'pdf_html_file' => '',
                'pdf_html_template' => '',
                'pdf_map_preview' => '',
                'pdf_field_map' => [],
                'template_origin' => '',
                'docx_pairing_report' => [],
            ];
        }

        if (!empty($custom_forms)) {
            $settings['_custom_forms'] = $custom_forms;
        }
        if (is_array($current['_deleted_forms'] ?? null) && !empty($current['_deleted_forms'])) {
            $settings['_deleted_forms'] = array_values(array_unique(array_filter(array_map('sanitize_key', $current['_deleted_forms']))));
        }

        return $settings;
    }

    private function add_custom_form_to_settings(array $new_raw, ?string &$created_slug = null): array
    {
        $created_slug = '';
        $settings = get_option(self::OPTION_NAME, []);
        if (!is_array($settings)) {
            $settings = [];
        }

        $defaults = $this->get_default_forms();
        $custom_forms = is_array($settings['_custom_forms'] ?? null) ? $settings['_custom_forms'] : [];
        $new_title = sanitize_text_field((string)($new_raw['title'] ?? ''));
        if ($new_title === '') {
            return $settings;
        }

        $new_slug_raw = (string)($new_raw['slug'] ?? '');
        $new_slug = $this->sanitize_form_slug($new_slug_raw !== '' ? $new_slug_raw : $new_title);
        $new_slug = $this->make_unique_form_slug($new_slug, array_merge(array_keys($defaults), array_keys($custom_forms)));
        $fields = $this->parse_fields_definition((string)($new_raw['fields_definition'] ?? ''), []);
        if (empty($fields)) {
            $fields = $this->get_default_custom_fields();
        }

        $custom_forms[$new_slug] = [
            'custom' => true,
            'enabled' => !empty($new_raw['enabled']) ? 1 : 0,
            'title' => $new_title,
            'description' => sanitize_textarea_field((string)($new_raw['description'] ?? '')),
            'fields' => $fields,
            'docx_template' => '',
            'blank_docx' => '',
            'pdf_template' => '',
            'pdf_html_file' => '',
            'pdf_html_template' => '',
            'pdf_map_preview' => '',
            'pdf_field_map' => [],
            'template_origin' => '',
            'docx_pairing_report' => [],
        ];
        $settings['_custom_forms'] = $custom_forms;
        $created_slug = $new_slug;

        return $settings;
    }

    private function get_default_custom_fields(): array
    {
        return [
            ['name' => 'tanulo_neve', 'label' => 'Tanuló neve', 'type' => 'text', 'required' => true, 'placeholder' => ''],
            ['name' => 'osztaly', 'label' => 'Osztály', 'type' => 'text', 'required' => true, 'placeholder' => 'pl. 9.A'],
            ['name' => 'keltezes_datuma', 'label' => 'Keltezés dátuma', 'type' => 'date', 'required' => false, 'placeholder' => ''],
        ];
    }

    private function sanitize_single_form_settings(string $slug, array $row, array $default, bool $custom): array
    {
        $title = sanitize_text_field((string)($row['title'] ?? $default['title'] ?? ''));
        $description = sanitize_textarea_field((string)($row['description'] ?? $default['description'] ?? ''));

        $docx_template = sanitize_text_field((string)($row['docx_template'] ?? $default['docx_template'] ?? ''));
        $blank_docx = sanitize_text_field((string)($row['blank_docx'] ?? $default['blank_docx'] ?? ''));
        $pdf_template = sanitize_text_field((string)($row['pdf_template'] ?? $default['pdf_template'] ?? ''));
        $pdf_html_file = sanitize_text_field((string)($row['pdf_html_file'] ?? $default['pdf_html_file'] ?? ''));
        $pdf_html_template = $this->sanitize_pdf_html_template((string)($row['pdf_html_template'] ?? $default['pdf_html_template'] ?? ''));
        $pdf_map_preview = $this->sanitize_template_relative_path(sanitize_text_field((string)($row['pdf_map_preview'] ?? $default['pdf_map_preview'] ?? '')));

        if (!empty($row['clear_docx_template'])) {
            $this->delete_stored_template_file($docx_template);
            $docx_template = '';
        }
        if (!empty($row['clear_blank_docx'])) {
            $this->delete_stored_template_file($blank_docx);
            $blank_docx = '';
        }
        if (!empty($row['clear_pdf_template'])) {
            $this->delete_stored_template_file($pdf_template);
            $pdf_template = '';
        }
        if (!empty($row['clear_pdf_html_template'])) {
            $this->delete_stored_template_file($pdf_html_file);
            $pdf_html_file = '';
            $pdf_html_template = '';
        }
        if (!empty($row['clear_pdf_map_preview'])) {
            $this->delete_stored_template_file($pdf_map_preview);
            $pdf_map_preview = '';
        }

        $fallback_fields = is_array($default['fields'] ?? null) ? $default['fields'] : [];
        $fields = $this->parse_fields_definition((string)($row['fields_definition'] ?? ''), $fallback_fields);
        $pdf_field_map = $this->sanitize_pdf_field_map($row['pdf_field_map'] ?? ($default['pdf_field_map'] ?? []), $fields);

        return [
            'custom' => $custom,
            'enabled' => !empty($row['enabled']) ? 1 : 0,
            'title' => $title !== '' ? $title : (string)($default['title'] ?? $slug),
            'description' => $description,
            'fields' => $fields,
            'docx_template' => $docx_template,
            'blank_docx' => $blank_docx,
            'pdf_template' => $pdf_template,
            'pdf_html_file' => $pdf_html_file,
            'pdf_html_template' => $pdf_html_template,
            'pdf_map_preview' => $pdf_map_preview,
            'pdf_field_map' => $pdf_field_map,
            'template_origin' => sanitize_key((string)($default['template_origin'] ?? '')),
            'docx_pairing_report' => $this->sanitize_docx_pairing_report((array)($default['docx_pairing_report'] ?? [])),
        ];
    }

    private function sanitize_form_slug(string $slug): string
    {
        $slug = remove_accents($slug);
        $slug = strtolower($slug);
        $slug = preg_replace('/[^a-z0-9_-]+/', '-', $slug) ?? '';
        $slug = trim($slug, '-_');
        return $slug !== '' ? sanitize_key($slug) : 'urlap';
    }

    private function make_unique_form_slug(string $slug, array $existing): string
    {
        $slug = $this->sanitize_form_slug($slug);
        $existing = array_map('sanitize_key', $existing);
        if (!in_array($slug, $existing, true)) {
            return $slug;
        }

        $base = $slug;
        $counter = 2;
        while (in_array($base . '-' . $counter, $existing, true)) {
            $counter++;
        }
        return $base . '-' . $counter;
    }

    private function parse_fields_definition(string $definition, array $fallback = []): array
    {
        $definition = wp_unslash($definition);
        $lines = preg_split('/\R/u', $definition) ?: [];
        $fields = [];
        $seen = [];
        $allowed_types = ['text', 'email', 'number', 'date', 'textarea', 'select', 'radio', 'checkbox', 'checkbox_group', 'checkbox_matrix', 'underline_choice', 'section'];

        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            $parts = array_map('trim', explode('|', $line));
            $name = $this->sanitize_field_name((string)($parts[0] ?? ''));
            $label = sanitize_text_field((string)($parts[1] ?? ''));
            if ($name === '' && $label !== '') {
                $name = $this->sanitize_field_name($label);
            }
            if ($name === '') {
                continue;
            }
            if (isset($seen[$name])) {
                continue;
            }
            $seen[$name] = true;

            $type = strtolower(sanitize_key((string)($parts[2] ?? 'text')));
            if (!in_array($type, $allowed_types, true)) {
                $type = 'text';
            }

            $required_raw = strtolower(trim((string)($parts[3] ?? '0')));
            $required = in_array($required_raw, ['1', 'true', 'yes', 'igen', 'kötelező', 'kotelezo', 'required'], true);
            $placeholder = sanitize_text_field((string)($parts[4] ?? ''));

            $field = [
                'name' => $name,
                'label' => $label !== '' ? $label : $name,
                'type' => $type,
                'required' => $required,
                'placeholder' => $placeholder,
            ];

            if (in_array($type, ['select', 'radio', 'checkbox_group', 'underline_choice'], true)) {
                $field['options'] = $this->parse_select_options((string)($parts[5] ?? ''));
                if (empty($field['options'])) {
                    $field['options'] = ['igen' => 'Igen', 'nem' => 'Nem'];
                }
            } elseif ($type === 'checkbox_matrix') {
                [$field['matrix_rows'], $field['matrix_columns']] = $this->parse_matrix_options((string)($parts[5] ?? ''));
            }

            $fields[] = $field;
            if (count($fields) >= 60) {
                break;
            }
        }

        return !empty($fields) ? $fields : $fallback;
    }

    private function sanitize_field_name(string $name): string
    {
        $name = remove_accents($name);
        $name = strtolower($name);
        $name = preg_replace('/[^a-z0-9_]+/', '_', $name) ?? '';
        $name = trim($name, '_');
        return $name !== '' ? substr($name, 0, 60) : '';
    }

    private function parse_select_options(string $raw): array
    {
        $options = [];
        $items = preg_split('/\s*[;\r\n]+\s*/u', trim($raw)) ?: [];
        foreach ($items as $item) {
            $item = trim((string)$item);
            if ($item === '') {
                continue;
            }
            if (str_contains($item, '=')) {
                [$value, $label] = array_map('trim', explode('=', $item, 2));
            } else {
                $label = $item;
                $value = $this->sanitize_field_name($item);
            }
            $value = sanitize_key(remove_accents((string)$value));
            $label = sanitize_text_field((string)$label);
            if ($value !== '' && $label !== '') {
                $options[$value] = $label;
            }
        }
        return $options;
    }

    private function parse_matrix_options(string $raw): array
    {
        $rows = [];
        $columns = [];
        $items = preg_split('/\s*[;\r\n]+\s*/u', trim($raw)) ?: [];
        foreach ($items as $item) {
            $item = trim((string)$item);
            if ($item === '' || !str_contains($item, '=')) {
                continue;
            }
            [$left, $label] = array_map('trim', explode('=', $item, 2));
            $label = sanitize_text_field((string)$label);
            if ($label === '') {
                continue;
            }
            if (preg_match('/^(?:row|sor):(.+)$/i', $left, $m)) {
                $key = sanitize_key(remove_accents(trim((string)$m[1])));
                if ($key !== '') { $rows[$key] = $label; }
            } elseif (preg_match('/^(?:col|column|oszlop):(.+)$/i', $left, $m)) {
                $key = sanitize_key(remove_accents(trim((string)$m[1])));
                if ($key !== '') { $columns[$key] = $label; }
            }
        }
        if (empty($rows)) {
            $rows = ['sor1' => '1. sor'];
        }
        if (empty($columns)) {
            $columns = ['igen' => 'Igen', 'nem' => 'Nem'];
        }
        return [$rows, $columns];
    }

    private function matrix_options_to_text(array $field): string
    {
        $lines = [];
        foreach ((array)($field['matrix_rows'] ?? []) as $key => $label) {
            $lines[] = 'row:' . $key . '=' . $label;
        }
        foreach ((array)($field['matrix_columns'] ?? []) as $key => $label) {
            $lines[] = 'col:' . $key . '=' . $label;
        }
        return implode("\n", $lines);
    }

    private function field_type_options(): array
    {
        return [
            'text' => 'Szöveg',
            'textarea' => 'Hosszú szöveg',
            'date' => 'Dátum',
            'email' => 'E-mail',
            'number' => 'Szám',
            'select' => 'Lenyíló lista',
            'radio' => 'Egyszeres választás (radio)',
            'checkbox' => 'Egyszerű jelölőnégyzet',
            'checkbox_group' => 'Többválasztós jelölőnégyzetek',
            'checkbox_matrix' => 'Jelölőnégyzet-mátrix',
            'underline_choice' => 'Választás – kijelölt szöveg aláhúzása',
            'section' => 'Szekciócím',
        ];
    }

    private function common_field_presets(): array
    {
        return [
            'tanulo_neve' => [
                'name' => 'tanulo_neve',
                'label' => 'Tanuló neve',
                'type' => 'text',
                'required' => true,
                'placeholder' => 'pl. Kiss Anna',
            ],
            'osztaly' => [
                'name' => 'osztaly',
                'label' => 'Osztály',
                'type' => 'text',
                'required' => true,
                'placeholder' => 'pl. 9.A',
            ],
            'szuletesi_datum' => [
                'name' => 'szuletesi_datum',
                'label' => 'Születési dátum',
                'type' => 'date',
                'required' => false,
                'placeholder' => '',
            ],
            'szulo_neve' => [
                'name' => 'szulo_neve',
                'label' => 'Szülő / gondviselő neve',
                'type' => 'text',
                'required' => false,
                'placeholder' => 'pl. Kiss Péter',
            ],
            'email' => [
                'name' => 'email',
                'label' => 'E-mail cím',
                'type' => 'email',
                'required' => false,
                'placeholder' => 'pl. szulo@example.hu',
            ],
            'telefon' => [
                'name' => 'telefon',
                'label' => 'Telefonszám',
                'type' => 'text',
                'required' => false,
                'placeholder' => 'pl. +36...',
            ],
            'keltezes_datuma' => [
                'name' => 'keltezes_datuma',
                'label' => 'Keltezés dátuma',
                'type' => 'date',
                'required' => false,
                'placeholder' => '',
            ],
            'indoklas' => [
                'name' => 'indoklas',
                'label' => 'Indoklás',
                'type' => 'textarea',
                'required' => false,
                'placeholder' => 'Rövid indoklás',
            ],
            'kerelem_tipusa' => [
                'name' => 'kerelem_tipusa',
                'label' => 'Kérelem típusa',
                'type' => 'select',
                'required' => true,
                'placeholder' => '',
                'options' => [
                    'tavollet' => 'Távollét',
                    'felmentes' => 'Felmentés',
                    'egyeb' => 'Egyéb',
                ],
            ],
            'alairas_helye' => [
                'name' => 'alairas_helye',
                'label' => 'Aláírás helye',
                'type' => 'text',
                'required' => false,
                'placeholder' => 'pl. Budapest',
            ],
        ];
    }

    private function render_admin_field_builder(string $textarea_name, string $textarea_id, array $fields, bool $open = false): string
    {
        if (empty($fields)) {
            $fields = $this->get_default_custom_fields();
        }

        $types = $this->field_type_options();
        $presets = $this->common_field_presets();
        $definition = $this->fields_to_definition($fields);

        ob_start();
        ?>
        <div class="szegbp-field-builder" data-szegbp-field-builder data-presets="<?php echo esc_attr((string)wp_json_encode($presets)); ?>">
            <div class="szegbp-field-builder__table-wrap">
                <table class="widefat striped szegbp-field-builder__table">
                    <thead>
                        <tr>
                            <th style="width:54px;">Sorrend</th>
                            <th>Mezőnév</th>
                            <th>Felirat</th>
                            <th style="width:150px;">Típus</th>
                            <th style="width:86px;">Kötelező</th>
                            <th>Placeholder</th>
                            <th>Opciók</th>
                            <th style="width:84px;">Művelet</th>
                        </tr>
                    </thead>
                    <tbody data-szegbp-field-rows>
                        <?php foreach (array_values($fields) as $index => $field): ?>
                            <?php echo $this->render_admin_field_row($field, $index, $types); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="szegbp-field-builder__toolbar szegbp-field-builder__toolbar--bottom">
                <button type="button" class="button button-primary" data-szegbp-add-field>+ Új mező hozzáadása</button>
                <button type="button" class="button" data-szegbp-add-section>+ Szekciócím</button>
                <button type="button" class="button" data-szegbp-collapse-all>Összes összecsukása</button>
                <button type="button" class="button" data-szegbp-expand-all>Összes kinyitása</button>
                <label class="szegbp-field-builder__preset">
                    Gyakori mező:
                    <select data-szegbp-preset-select>
                        <option value="">Válassz...</option>
                        <?php foreach ($presets as $preset_key => $preset): ?>
                            <option value="<?php echo esc_attr($preset_key); ?>"><?php echo esc_html((string)$preset['label']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button type="button" class="button" data-szegbp-insert-preset>Beszúrás</button>
                <span class="description">Az új mező mindig a lista végére kerül. A mezőnév a feliratból automatikusan javasolható.</span>
            </div>

            <template data-szegbp-field-template>
                <?php echo $this->render_admin_field_row([], 0, $types); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </template>

            <input type="hidden" id="<?php echo esc_attr($textarea_id); ?>" name="<?php echo esc_attr($textarea_name); ?>" value="<?php echo esc_attr($definition); ?>" data-szegbp-field-definition>
            <details class="szegbp-field-builder__advanced" <?php echo $open ? 'open' : ''; ?>>
                <summary>Haladó meződefiníció szerkesztése</summary>
                <textarea class="large-text code" rows="9" data-szegbp-advanced-definition><?php echo esc_textarea($definition); ?></textarea>
                <p class="description">Kompatibilis formátum: <code>mezőnév|Felirat|típus|kötelező|placeholder|opciók</code>. Mentéskor ez az érték kerül feldolgozásra.</p>
            </details>
        </div>
        <?php
        return ob_get_clean();
    }

    private function render_admin_field_row(array $field, int $index, array $types): string
    {
        $name = (string)($field['name'] ?? '');
        $label = (string)($field['label'] ?? '');
        $type = (string)($field['type'] ?? 'text');
        $required = !empty($field['required']);
        $placeholder = (string)($field['placeholder'] ?? '');
        $options = '';

        if ($type === 'checkbox_matrix') {
            $options = $this->matrix_options_to_text($field);
        } elseif (!empty($field['options']) && is_array($field['options'])) {
            $option_lines = [];
            foreach ($field['options'] as $value => $option_label) {
                $option_lines[] = (string)$value . '=' . (string)$option_label;
            }
            $options = implode("\n", $option_lines);
        }

        ob_start();
        ?>
        <tr class="szegbp-field-builder__row" data-szegbp-field-row>
            <td class="szegbp-field-builder__cell szegbp-field-builder__cell--order">
                <div class="szegbp-field-builder__row-top">
                    <div class="szegbp-field-builder__row-meta">
                        <span class="szegbp-field-builder__row-badge" data-szegbp-row-badge><?php echo $type === 'section' ? 'Szekció' : 'Mező'; ?></span>
                        <span class="szegbp-field-builder__order" data-szegbp-field-order><?php echo esc_html((string)($index + 1)); ?></span>
                        <strong class="szegbp-field-builder__row-summary" data-szegbp-row-summary><?php echo esc_html($label !== '' ? $label : ($name !== '' ? $name : 'Új mező')); ?></strong>
                        <span class="szegbp-field-builder__row-type" data-szegbp-row-type><?php echo esc_html($types[$type] ?? $type); ?></span>
                    </div>
                    <div class="szegbp-field-builder__move">
                        <button type="button" class="button button-small szegbp-field-builder__collapse" title="Összecsukás" aria-label="Mező összecsukása vagy kinyitása" aria-expanded="true" data-szegbp-toggle-row>▾</button>
                        <button type="button" class="button button-small" title="Fel" aria-label="Mező mozgatása felfelé" data-szegbp-move-up>↑</button>
                        <button type="button" class="button button-small" title="Le" aria-label="Mező mozgatása lefelé" data-szegbp-move-down>↓</button>
                    </div>
                </div>
            </td>
            <td class="szegbp-field-builder__cell szegbp-field-builder__cell--name">
                <input type="text" class="regular-text code" value="<?php echo esc_attr($name); ?>" placeholder="tanulo_neve" data-szegbp-field-name>
            </td>
            <td class="szegbp-field-builder__cell szegbp-field-builder__cell--label">
                <input type="text" class="regular-text" value="<?php echo esc_attr($label); ?>" placeholder="Tanuló neve" data-szegbp-field-label>
            </td>
            <td class="szegbp-field-builder__cell szegbp-field-builder__cell--type">
                <select data-szegbp-field-type>
                    <?php foreach ($types as $type_key => $type_label): ?>
                        <option value="<?php echo esc_attr($type_key); ?>" <?php selected($type, $type_key); ?>><?php echo esc_html($type_label); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td class="szegbp-field-builder__cell szegbp-field-builder__cell--required">
                <label class="szegbp-field-builder__checkbox-toggle"><input type="checkbox" <?php checked($required); ?> data-szegbp-field-required> <span>Kötelező</span></label>
            </td>
            <td class="szegbp-field-builder__cell szegbp-field-builder__cell--placeholder">
                <input type="text" class="regular-text" value="<?php echo esc_attr($placeholder); ?>" placeholder="pl. Kiss Anna" data-szegbp-field-placeholder>
            </td>
            <td class="szegbp-field-builder__cell szegbp-field-builder__cell--options">
                <textarea rows="3" placeholder="ertek=Felirat&#10;masik=Másik opció" data-szegbp-field-options><?php echo esc_textarea($options); ?></textarea>
                <p class="description">Lista/radio/jelölőnégyzet esetén: <code>ertek=Felirat</code>. Mátrixnál: <code>row:kulcs=Sor felirata</code> és <code>col:kulcs=Oszlop felirata</code>.</p>
            </td>
            <td class="szegbp-field-builder__cell szegbp-field-builder__cell--actions">
                <button type="button" class="button button-link-delete" data-szegbp-delete-field>Mező törlése</button>
            </td>
        </tr>
        <?php
        return ob_get_clean();
    }

    private function fields_to_definition(array $fields): string
    {
        $lines = [];
        foreach ($fields as $field) {
            $name = (string)($field['name'] ?? '');
            if ($name === '') {
                continue;
            }
            $type = (string)($field['type'] ?? 'text');
            $required = !empty($field['required']) ? '1' : '0';
            $placeholder = (string)($field['placeholder'] ?? '');
            $options = '';
            if (in_array($type, ['select', 'radio', 'checkbox_group', 'underline_choice'], true)) {
                $pairs = [];
                foreach (($field['options'] ?? []) as $value => $label) {
                    $pairs[] = (string)$value . '=' . (string)$label;
                }
                $options = implode(';', $pairs);
            } elseif ($type === 'checkbox_matrix') {
                $options = str_replace("\n", ';', $this->matrix_options_to_text($field));
            }
            $lines[] = implode('|', [
                $name,
                (string)($field['label'] ?? $name),
                $type,
                $required,
                $placeholder,
                $options,
            ]);
        }
        return implode("\n", $lines);
    }


    private function sanitize_pdf_html_template(string $html): string
    {
        $html = wp_unslash($html);
        $html = $this->normalize_word_html_template($html);
        $html = preg_replace('~<\s*(script|iframe|object|embed|form|input|button|textarea|select|option)[^>]*>.*?<\s*/\s*\1\s*>~is', '', $html) ?? '';
        $html = preg_replace('~<\s*(script|iframe|object|embed|form|input|button|textarea|select|option)[^>]*/?\s*>~is', '', $html) ?? '';
        $html = preg_replace('/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html) ?? '';
        $html = preg_replace('/javascript\s*:/i', '', $html) ?? '';
        $html = preg_replace('/<\?php.*?\?>/is', '', $html) ?? '';
        $html = trim($html);
        if (strlen($html) > 1024 * 1024) {
            wp_die('A HTML sablon legfeljebb 1 MB lehet. A korábbi beállítások nem módosultak.', 400);
        }
        return $html;
    }

    private function normalize_word_html_template(string $html): string
    {
        if ($html === '') {
            return '';
        }
        $html = preg_replace('~<meta\s+http-equiv=["\']?Content-Type["\']?\s+content=["\']text/html;\s*charset=[^"\']+["\']\s*/?>~i', '<meta charset="utf-8">', $html) ?? $html;
        $html = preg_replace('~<meta\s+charset=[^>]+>~i', '<meta charset="utf-8">', $html) ?? $html;
        $html = preg_replace('~<link\s+[^>]*(?:File-List|themeData|colorSchemeMapping)[^>]*>~is', '', $html) ?? $html;
        $html = preg_replace('~<!--\[if\s+gte\s+mso\s+9\]>\s*<xml>.*?</xml>\s*<!\[endif\]-->~is', '', $html) ?? $html;
        $html = preg_replace_callback('/\{\{([\s\S]*?)\}\}/u', static function (array $m): string {
            $inner = wp_strip_all_tags((string)$m[1]);
            $inner = html_entity_decode($inner, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $inner = remove_accents($inner);
            $inner = strtolower($inner);
            $inner = preg_replace('/[^a-z0-9_-]+/', '', $inner) ?? '';
            return $inner !== '' ? '{{' . $inner . '}}' : '';
        }, $html) ?? $html;
        if ((stripos($html, 'class=WordSection1') !== false || stripos($html, 'class="WordSection1"') !== false) && stripos($html, 'szegbp-word-html-normalize') === false) {
            $css = '<style id="szegbp-word-html-normalize">html{background:#eef0ec}body{margin:0!important;background:#eef0ec!important}div.WordSection1{width:210mm;min-height:297mm;box-sizing:border-box;margin:18px auto!important;padding:23.6mm 25mm 8mm 22.5mm;background:#fff;box-shadow:0 8px 28px rgba(0,0,0,.16)}@media(max-width:900px){div.WordSection1{width:100%;min-height:0;margin:0!important;padding:20px;box-shadow:none}}</style>';
            $html = preg_replace('~</head>~i', $css . '</head>', $html, 1) ?? $html;
        }
        return $html;
    }


    private function sanitize_pdf_field_map($raw, array $fields): array
    {
        if (is_string($raw)) {
            $raw = wp_unslash($raw);
            $decoded = json_decode($raw, true);
            $raw = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($raw)) {
            return [];
        }

        $allowed_fields = [];
        foreach ($fields as $field) {
            $name = sanitize_key((string)($field['name'] ?? ''));
            if ($name !== '') {
                $allowed_fields[$name] = true;
            }
        }

        $out = [];
        $seen = [];
        foreach ($raw as $item) {
            if (!is_array($item)) {
                continue;
            }
            $name = sanitize_key((string)($item['field'] ?? $item['name'] ?? ''));
            if ($name === '' || !isset($allowed_fields[$name]) || isset($seen[$name])) {
                continue;
            }
            $seen[$name] = true;
            $x = max(0.0, min(100.0, (float)($item['x'] ?? 8)));
            $y = max(0.0, min(100.0, (float)($item['y'] ?? 8)));
            $width = max(3.0, min(100.0 - $x, (float)($item['width'] ?? 35)));
            $font_size = max(7.0, min(36.0, (float)($item['font_size'] ?? 12)));
            $align = sanitize_key((string)($item['align'] ?? 'left'));
            if (!in_array($align, ['left', 'center', 'right'], true)) {
                $align = 'left';
            }
            $out[] = [
                'field' => $name,
                'x' => round($x, 3),
                'y' => round($y, 3),
                'width' => round($width, 3),
                'font_size' => round($font_size, 2),
                'align' => $align,
            ];
        }
        return array_values($out);
    }

    private function get_allowed_pdf_template_html(): array
    {
        $allowed = wp_kses_allowed_html('post');
        $extra_tags = ['html', 'head', 'body', 'style', 'section', 'article'];
        foreach ($extra_tags as $tag) {
            $allowed[$tag] = [
                'class' => true,
                'id' => true,
                'style' => true,
            ];
        }

        foreach ($allowed as &$attrs) {
            $attrs['class'] = true;
            $attrs['id'] = true;
            $attrs['style'] = true;
            $attrs['data-*'] = true;
        }
        unset($attrs);

        return $allowed;
    }

    private function render_admin_template_rows(string $slug, array $form): string
    {
        $docx_template = (string)($form['docx_template'] ?? '');
        $blank_docx_value = (string)($form['blank_docx'] ?? '');
        $pdf_template = (string)($form['pdf_template'] ?? '');
        $pdf_html_file_value = (string)($form['pdf_html_file'] ?? '');
        $pdf_html_template = $this->get_pdf_html_template($slug, $form, true);
        $pdf_map_preview_value = (string)($form['pdf_map_preview'] ?? '');
        $pdf_field_map = $this->sanitize_pdf_field_map($form['pdf_field_map'] ?? [], (array)($form['fields'] ?? []));
        $pdf_map_preview_file = $this->get_form_template_file($form, 'image');
        $docx_file = $this->get_form_template_file($form, 'docx');
        $blank_docx_file = $this->get_form_template_file($form, 'blank_docx');
        $docx_template_report = $docx_file !== null ? $this->inspect_docx_template_placeholders($docx_file['path'], (array)($form['fields'] ?? [])) : null;
        $pdf_file = $this->get_form_template_file($form, 'pdf');
        $pdf_html_file = $this->get_form_template_file($form, 'html');

        ob_start();
        ?>
                                <tr>
                                    <th scope="row">Sablonkészítő</th>
                                    <td>
                                        <div class="szegbp-forms-template-assistant">
                                            <p><strong>Két külön DOCX szerep:</strong> a <em>Kitöltési DOCX sablon</em> tartalmazza a <code>{{mezőnév}}</code> helyőrzőket és ebből készül a kitöltött Word; az <em>Üres DOCX nyomtatvány</em> külön fájl, amelyet a plugin soha nem módosít.</p><p><strong>Radio:</strong> egyetlen választható érték. A <code>{{mezőnév}}</code> a kiválasztott feliratot, a <code>{{mezőnév_opció}}</code> pedig ☒/☐ jelet ad.</p><p><strong>Jelölőnégyzet-mátrix:</strong> az opcióknál <code>row:kulcs=Sor</code> és <code>col:kulcs=Oszlop</code> formátum használható. A sabloncellák helyőrzője: <code>{{mező_sor_oszlop}}</code>, értéke ☒ vagy ☐.</p><p><strong>Aláhúzandó választás:</strong> a „Választás – kijelölt szöveg aláhúzása” mezőtípushoz használd a <code>{{underline_choice:mezőnév}}</code> helyőrzőt. A kész DOCX-ben és HTML/PDF-ben mindkét választási szöveg megjelenik, és csak a kiválasztott lesz aláhúzva. Egyedi sablonszöveghez: <code>{{underline_choice:mezőnév|Első szöveg|Második szöveg}}</code>.</p><p><strong>Automatikus létrehozás:</strong> az oldal alján lévő <em>Automatikus DOCX sablon létrehozása</em> gomb kizárólag a kitöltési DOCX sablont készíti újra. Az üres DOCX-et és a mentett HTML dokumentumsablont nem írja felül.</p>
                                            <p><strong>Kész DOCX-ből:</strong> tölts fel egy már meglévő Word nyomtatványt. A plugin megpróbálja a mezők címkéi alapján a pontozott vagy aláhúzott kitöltési helyeket <code>{{mezőnév}}</code> helyőrzőkre cserélni. Amit nem tud egyértelműen felismerni, azt mentés után jelzi.</p>
                                            <input type="file" name="szegbp_forms_source_docx_<?php echo esc_attr($slug); ?>" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
                                            <p class="description">A kész DOCX eredeti tördelése és formázása megmarad. A felismerés akkor a legjobb, ha a nyomtatványon szerepelnek ugyanazok a címkék, mint az űrlap mezőnevei mellett, például „Tanuló neve”, „Osztály”. Sikeres párosítás után a plugin a DOCX fő dokumentumrészének szövegéből és táblázataiból PDF/HTML sablont is készít.</p>
                                            <p class="description"><strong>PDF a DOCX-ből:</strong> a DOCX-ből készített PDF/HTML változat a szöveget, egyszerű karakterformázást, igazítást és táblázatokat viszi át. Word-specifikus elemek (pl. lebegő alakzatok, összetett fejléc/lábléc, beágyazott képek) első körben kézi HTML/PDF finomítást igényelhetnek.</p><p class="description"><strong>Kész PDF:</strong> az alábbi „Üres PDF nyomtatvány” mezőben külön eredeti PDF is feltölthető, és változatlan formában letölthető.</p>
                                            <?php $origin = sanitize_key((string)($form['template_origin'] ?? '')); ?>
                                            <?php $pairing = $this->sanitize_docx_pairing_report((array)($form['docx_pairing_report'] ?? [])); ?>
                                            <?php if ($origin !== ''): ?>
                                                <p class="description"><strong>Aktuális sablon forrása:</strong> <?php echo esc_html($origin === 'docx' ? 'kész DOCX feldolgozásából' : ($origin === 'auto' ? 'automatikus generálásból' : 'kézi sablonfeltöltésből')); ?>.</p>
                                            <?php endif; ?>
                                            <?php if (!empty($pairing['inserted']) || !empty($pairing['existing']) || !empty($pairing['missing']) || !empty($pairing['detected'])): ?>
                                                <details class="szegbp-forms-template-editor">
                                                    <summary>Legutóbbi DOCX mezőpárosítás</summary>
                                                    <?php if (!empty($pairing['detected'])): ?><p class="description"><strong>DOCX-ből felismert mezők:</strong> <code><?php echo esc_html(implode(', ', $pairing['detected'])); ?></code></p><?php endif; ?>
                                                    <?php if (!empty($pairing['inserted'])): ?><p class="description"><strong>Automatikusan beillesztett helyőrzők:</strong> <code><?php echo esc_html(implode(', ', $pairing['inserted'])); ?></code></p><?php endif; ?>
                                                    <?php if (!empty($pairing['existing'])): ?><p class="description"><strong>Már meglévő helyőrzők:</strong> <code><?php echo esc_html(implode(', ', $pairing['existing'])); ?></code></p><?php endif; ?>
                                                    <?php if (!empty($pairing['missing'])): ?><p class="description" style="color:#945421;"><strong>Kézzel ellenőrizendő mezők:</strong> <code><?php echo esc_html(implode(', ', $pairing['missing'])); ?></code></p><?php endif; ?>

                                                    <?php if ($docx_file !== null): ?>
                                                        <p style="margin:12px 0 8px;">
                                                            <a class="button button-primary" href="<?php echo esc_url($docx_file['url']); ?>" download>⬇ Párosított DOCX sablon letöltése</a>
                                                        </p>
                                                        <p class="description">A letöltött Word-sablonban már benne vannak az automatikusan felismert <code>{{mezőnév}}</code> helyőrzők. Javítsd kézzel a hiányzó vagy rosszul elhelyezett párosításokat, majd töltsd vissza a <strong>DOCX sablon</strong> mezőnél.</p>
                                                    <?php endif; ?>

                                                    <?php
                                                    $inserted_map = array_fill_keys((array)$pairing['inserted'], true);
                                                    $existing_map = array_fill_keys((array)$pairing['existing'], true);
                                                    $missing_map = array_fill_keys((array)$pairing['missing'], true);
                                                    ?>
                                                    <div style="overflow-x:auto;margin-top:12px;">
                                                        <table class="widefat striped" style="max-width:820px;">
                                                            <thead>
                                                                <tr>
                                                                    <th>Űrlapmező</th>
                                                                    <th>Word helyőrző</th>
                                                                    <th>Állapot</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php foreach ((array)($form['fields'] ?? []) as $pair_field): ?>
                                                                <?php
                                                                $pair_name = sanitize_key((string)($pair_field['name'] ?? ''));
                                                                if ($pair_name === '') { continue; }
                                                                $pair_label = (string)($pair_field['label'] ?? $pair_name);
                                                                if (isset($inserted_map[$pair_name])) {
                                                                    $pair_status = 'Automatikusan párosítva';
                                                                    $pair_style = 'color:#2f6f3e;font-weight:600;';
                                                                } elseif (isset($existing_map[$pair_name])) {
                                                                    $pair_status = 'Már benne volt';
                                                                    $pair_style = 'color:#2f6f3e;font-weight:600;';
                                                                } elseif (isset($missing_map[$pair_name])) {
                                                                    $pair_status = 'Kézzel javítandó';
                                                                    $pair_style = 'color:#945421;font-weight:700;';
                                                                } else {
                                                                    $pair_status = 'Nincs adat';
                                                                    $pair_style = 'color:#646970;';
                                                                }
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo esc_html($pair_label); ?></td>
                                                                    <td><code>{{<?php echo esc_html($pair_name); ?>}}</code></td>
                                                                    <td style="<?php echo esc_attr($pair_style); ?>"><?php echo esc_html($pair_status); ?></td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </details>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Kitöltési DOCX sablon</th>
                                    <td>
                                        <input type="hidden" name="szegbp_forms[<?php echo esc_attr($slug); ?>][docx_template]" value="<?php echo esc_attr($docx_template); ?>">
                                        <input type="file" name="szegbp_forms_template_docx_<?php echo esc_attr($slug); ?>" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
                                        <p class="description">Ez a <strong>kitöltött DOCX</strong> alapja. A Wordben <code>{{mezőnév}}</code> helyőrzőket használj, például <code>{{tanulo_neve}}</code>, <code>{{osztaly}}</code>. Az űrlap kitöltésekor a plugin ezek helyére írja az adatokat.</p>
                                        <?php if ($docx_file !== null): ?>
                                            <p class="description"><strong>Aktív kitöltési sablon:</strong> <a href="<?php echo esc_url($docx_file['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($docx_file['name']); ?></a></p>
                                            <?php if (is_array($docx_template_report)): ?>
                                                <?php if (!empty($docx_template_report['found'])): ?><p class="description"><strong>Felismert helyőrzők:</strong> <code><?php echo esc_html(implode(', ', $docx_template_report['found'])); ?></code></p><?php endif; ?>
                                                <?php if (!empty($docx_template_report['missing'])): ?><p class="description" style="color:#945421;"><strong>Hiányzó mezőhelyőrzők:</strong> <code><?php echo esc_html(implode(', ', $docx_template_report['missing'])); ?></code>.</p><?php endif; ?>
                                                <?php if (!empty($docx_template_report['unknown'])): ?><p class="description" style="color:#945421;"><strong>Ismeretlen helyőrzők:</strong> <code><?php echo esc_html(implode(', ', $docx_template_report['unknown'])); ?></code>.</p><?php endif; ?>
                                            <?php endif; ?>
                                            <label><input type="checkbox" name="szegbp_forms[<?php echo esc_attr($slug); ?>][clear_docx_template]" value="1"> Kitöltési DOCX sablon törlése</label>
                                        <?php else: ?>
                                            <p class="description">Nincs külön kitöltési DOCX sablon. Ilyenkor a plugin a beépített DOCX-generátort használja.</p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Üres DOCX nyomtatvány</th>
                                    <td>
                                        <input type="hidden" name="szegbp_forms[<?php echo esc_attr($slug); ?>][blank_docx]" value="<?php echo esc_attr($blank_docx_value); ?>">
                                        <input type="file" name="szegbp_forms_blank_docx_<?php echo esc_attr($slug); ?>" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
                                        <p class="description">Ez a fájl kizárólag az <strong>Üres DOCX letöltése</strong> gombhoz tartozik. A plugin nem párosít benne mezőket, nem ír bele helyőrzőket és letöltéskor sem módosítja.</p>
                                        <?php if ($blank_docx_file !== null): ?>
                                            <p class="description"><strong>Aktív üres nyomtatvány:</strong> <a href="<?php echo esc_url($blank_docx_file['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($blank_docx_file['name']); ?></a></p>
                                            <label><input type="checkbox" name="szegbp_forms[<?php echo esc_attr($slug); ?>][clear_blank_docx]" value="1"> Üres DOCX törlése</label>
                                        <?php else: ?>
                                            <p class="description">Nincs külön üres DOCX feltöltve. Az üres letöltés ilyenkor kompatibilitási módban a kitöltési sablonból vagy a beépített generátorból készül.</p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">PDF HTML sablon</th>
                                    <td>
                                        <input type="hidden" name="szegbp_forms[<?php echo esc_attr($slug); ?>][pdf_html_file]" value="<?php echo esc_attr($pdf_html_file_value); ?>">
                                        <div class="szegbp-template-status <?php echo trim($pdf_html_template) !== '' ? 'is-inline' : 'is-empty'; ?>" data-szegbp-html-status>
                                            <?php if (trim($pdf_html_template) !== ''): ?>
                                                <strong>Aktív HTML sablon:</strong>
                                                <span>mentett HTML tartalom</span>
                                                <span class="szegbp-template-status__hint">Ez a HTML kerül az előnézetbe és a PDF-generálás alapjául. A fájlból beolvasott sablon mentés után itt jelenik meg.</span>
                                            <?php else: ?>
                                                <strong>Nincs egyedi HTML sablon.</strong>
                                                <span class="szegbp-template-status__hint">Tölts be egy HTML fájlt vagy generálj sablont DOCX-ből.</span>
                                            <?php endif; ?>
                                        </div>
                                        <label class="szegbp-template-upload-label" for="szegbp_forms_template_html_import_<?php echo esc_attr($slug); ?>">HTML sablon beolvasása fájlból</label>
                                        <input id="szegbp_forms_template_html_import_<?php echo esc_attr($slug); ?>" type="file" accept=".html,.htm,text/html" data-szegbp-html-import>
                                        <p class="description">A fájl nem a szerverre kerül feltöltésre: a böngésző beolvassa a teljes HTML-t a lenti szerkesztőbe. Ezután nyomd meg a <strong>Mentés</strong> gombot.</p>
                                        <div class="szegbp-html-import-feedback" data-szegbp-html-import-feedback hidden></div>
                                        <details class="szegbp-forms-template-editor" data-szegbp-html-editor>
                                            <summary>PDF HTML sablon szerkesztése</summary>
                                            <p class="description">A kitöltött PDF, a dokumentum-előnézet és a Nyomtatás ebből az egyetlen mentett HTML sablonból készül. Használható helyőrzők: <code>{{tanulo_neve}}</code>, <code>{{osztaly}}</code>, <code>{{szulo_neve}}</code>. CSS-t írj közvetlenül <code>&lt;style&gt;</code> blokkba. PHP és JavaScript nem futtatható.</p>
                                            <p class="szegbp-forms-template-actions">
                                                <?php if ($docx_file !== null): ?>
                                                    <button type="submit" name="szegbp_forms_generate_html_from_docx" class="button button-primary" onclick="return confirm('Elkészítsem a dokumentum HTML sablont a jelenlegi DOCX-ből? A mostani HTML sablon lecserélődik, a DOCX nem változik.');">HTML sablon generálása DOCX-ből</button>
                                                <?php endif; ?>
                                                <button type="submit" name="szegbp_forms_generate_pdf_html" class="button" onclick="return confirm('Újrageneráljam az általános A4-es PDF HTML alapsablont az aktuális mezőkből? A jelenlegi HTML sablon tartalma lecserélődik, a DOCX sablon nem változik.');">Általános HTML alapsablon</button>
                                            </p>
                                            <p class="description">Ha van DOCX sablon, elsőként abból érdemes HTML dokumentumsablont készíteni: így a Word szövege, egyszerű formázásai és táblázatai kerülnek az előnézetbe. Az általános HTML csak tartalék, mezőlistából épített sablon.</p>
                                            <textarea class="large-text code" rows="18" name="szegbp_forms[<?php echo esc_attr($slug); ?>][pdf_html_template]" data-szegbp-html-template><?php echo esc_textarea($pdf_html_template); ?></textarea>
                                        </details>
                                        <p><label><input type="checkbox" name="szegbp_forms[<?php echo esc_attr($slug); ?>][clear_pdf_html_template]" value="1"> PDF HTML sablon törlése / alapértelmezett visszaállítása ennél az űrlapnál</label></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Kész / üres PDF nyomtatvány</th>
                                    <td>
                                        <input type="hidden" name="szegbp_forms[<?php echo esc_attr($slug); ?>][pdf_template]" value="<?php echo esc_attr($pdf_template); ?>">
                                        <?php if ($docx_file !== null): ?>
                                            <?php $libreoffice_path = $this->find_libreoffice_binary(); ?>
                                            <div class="szegbp-forms-docx-pdf-generator">
                                                <p><button type="submit" name="szegbp_forms_generate_pdf_from_docx" class="button button-primary" onclick="return confirm('Elkészítsem a PDF sablont a jelenlegi DOCX-ből? A korábbi PDF sablon, előnézet és PDF mezőtérkép lecserélődik.');">PDF sablon generálása DOCX-ből</button></p>
                                                <p class="description">A plugin egy ideiglenes Word-másolatból eltávolítja a <code>{{mezőnév}}</code> helyőrzőket, majd a Word tördelését LibreOffice segítségével PDF-fé alakítja. Ez a PDF lesz a mezőtérkép háttérsablonja.</p>
                                                <?php if ($libreoffice_path !== ''): ?>
                                                    <p class="description" style="color:#2f6f3e;"><strong>DOCX→PDF motor:</strong> LibreOffice elérhető.</p>
                                                <?php else: ?>
                                                    <p class="description" style="color:#945421;"><strong>DOCX→PDF motor:</strong> LibreOffice/soffice jelenleg nem található. A funkcióhoz a szerveren LibreOffice szükséges, és a PHP-nak engedélyeznie kell külső parancs futtatását.</p>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                        <input type="file" name="szegbp_forms_template_pdf_<?php echo esc_attr($slug); ?>" accept=".pdf,application/pdf">
                                        <?php if ($pdf_file !== null): ?>
                                            <p class="description">Jelenlegi PDF nyomtatvány: <a href="<?php echo esc_url($pdf_file['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($pdf_file['name']); ?></a></p>
                                            <label><input type="checkbox" name="szegbp_forms[<?php echo esc_attr($slug); ?>][clear_pdf_template]" value="1"> PDF nyomtatvány törlése ennél az űrlapnál</label>
                                        <?php elseif (!empty($form['pdf_file'])): ?>
                                            <p class="description">Nincs feltöltött egyedi PDF. A plugin beépített PDF mintáját használja.</p>
                                        <?php else: ?>
                                            <p class="description">Nincs feltöltött üres PDF nyomtatvány. Az Üres PDF letöltése csak külön feltöltött PDF esetén érhető el.</p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Használható helyőrzők</th>
                                    <td>
                                        <details>
                                            <summary>Mezők megnyitása</summary>
                                            <div class="szegbp-forms-placeholder-list">
                                                <?php foreach (($form['fields'] ?? []) as $field): ?>
                                                    <code>{{<?php echo esc_html((string)$field['name']); ?>}}</code>
                                                    <span><?php echo esc_html((string)$field['label']); ?></span><br>
                                                <?php endforeach; ?>
                                            </div>
                                        </details>
                                    </td>
                                </tr>
        <?php
        return ob_get_clean();
    }

    private function inspect_html_template_placeholders(string $html, array $fields): array
    {
        preg_match_all('/\{\{\s*([A-Za-z0-9_\-]+)\s*\}\}/', $html, $matches);
        $tokens = array_values(array_unique(array_map('sanitize_key', (array)($matches[1] ?? []))));
        $expected = [];
        foreach ($fields as $field) {
            $name = sanitize_key((string)($field['name'] ?? ''));
            if ($name !== '') {
                $expected[] = $name;
            }
        }
        $expected = array_values(array_unique($expected));
        $special = ['_form_title', '_form_description', '_generated_date'];
        return [
            'found' => array_values(array_intersect($expected, $tokens)),
            'missing' => array_values(array_diff($expected, $tokens)),
            'unknown' => array_values(array_diff($tokens, $expected, $special)),
        ];
    }

    private function get_template_field_diagnostics(string $slug, array $form): array
    {
        $fields = (array)($form['fields'] ?? []);
        $docx_file = $this->get_form_template_file($form, 'docx');
        if ($docx_file !== null) {
            $docx = $this->inspect_docx_template_placeholders($docx_file['path'], $fields);
            $docx['mode'] = 'template';
        } else {
            $names = array_values(array_filter(array_map(static fn($f) => sanitize_key((string)($f['name'] ?? '')), $fields)));
            $docx = ['found' => [], 'missing' => $names, 'unknown' => [], 'mode' => 'missing'];
        }

        $html = $this->get_pdf_html_template($slug, $form, true);
        $pdf = $this->inspect_html_template_placeholders($html, $fields);
        $pdf['mode'] = trim($html) !== '' ? 'template' : 'missing';

        $issues = [];
        if (!empty($docx['missing'])) {
            $issues[] = 'A DOCX sablonból hiányzik ' . count($docx['missing']) . ' űrlapmező.';
        }
        if (!empty($docx['unknown'])) {
            $issues[] = 'A DOCX sablon ' . count($docx['unknown']) . ' ismeretlen helyőrzőt tartalmaz.';
        }
        if (!empty($pdf['missing'])) {
            $issues[] = (($pdf['mode'] ?? '') === 'mapped' ? 'A PDF mezőtérképből' : 'A PDF/HTML sablonból') . ' hiányzik ' . count($pdf['missing']) . ' űrlapmező.';
        }
        if (!empty($pdf['unknown'])) {
            $issues[] = 'A PDF/HTML sablon ' . count($pdf['unknown']) . ' ismeretlen helyőrzőt tartalmaz.';
        }

        return ['ok' => empty($issues), 'docx' => $docx, 'pdf' => $pdf, 'issues' => $issues];
    }

    private function render_template_diagnostics_panel(string $slug, array $form): string
    {
        $diag = $this->get_template_field_diagnostics($slug, $form);
        ob_start();
        ?>
        <section class="szegbp-forms-template-diagnostics <?php echo !empty($diag['ok']) ? 'is-ok' : 'has-warning'; ?>">
            <div class="szegbp-forms-card-header">
                <div>
                    <h3>Sablon–mező ellenőrzés</h3>
                    <p class="description">A mentett űrlapmezőket összeveti a DOCX-sablonnal és a kitöltött PDF-et készítő HTML sablonnal.</p>
                </div>
                <span class="szegbp-forms-status <?php echo !empty($diag['ok']) ? 'is-active' : 'is-warning'; ?>"><?php echo !empty($diag['ok']) ? 'Rendben' : 'Ellenőrizendő'; ?></span>
            </div>
            <div class="szegbp-forms-diagnostic-grid">
                <div>
                    <strong>DOCX</strong>
                    <p><?php echo ($diag['docx']['mode'] ?? '') === 'generated' ? 'Automatikus generátor: minden mező bekerül.' : 'Egyedi sablon ellenőrizve.'; ?></p>
                    <p class="description">Felismert: <?php echo esc_html((string)count((array)$diag['docx']['found'])); ?> · Hiányzó: <?php echo esc_html((string)count((array)$diag['docx']['missing'])); ?> · Ismeretlen: <?php echo esc_html((string)count((array)$diag['docx']['unknown'])); ?></p>
                    <?php if (!empty($diag['docx']['missing'])): ?><p class="description"><strong>Hiányzik:</strong> <code><?php echo esc_html(implode(', ', (array)$diag['docx']['missing'])); ?></code></p><?php endif; ?>
                    <?php if (!empty($diag['docx']['unknown'])): ?><p class="description"><strong>Ismeretlen:</strong> <code><?php echo esc_html(implode(', ', (array)$diag['docx']['unknown'])); ?></code></p><?php endif; ?>
                </div>
                <div>
                    <strong>Kitöltött PDF</strong>
                    <p><?php
                        $pdf_mode = (string)($diag['pdf']['mode'] ?? '');
                        echo $pdf_mode === 'mapped'
                            ? 'Vizuális PDF mezőtérkép ellenőrizve.'
                            : ($pdf_mode === 'generated' ? 'Automatikus PDF-sablon ellenőrizve.' : 'Egyedi HTML sablon ellenőrizve.');
                    ?></p>
                    <p class="description">Felismert: <?php echo esc_html((string)count((array)$diag['pdf']['found'])); ?> · Hiányzó: <?php echo esc_html((string)count((array)$diag['pdf']['missing'])); ?> · Ismeretlen: <?php echo esc_html((string)count((array)$diag['pdf']['unknown'])); ?></p>
                    <?php if (!empty($diag['pdf']['missing'])): ?><p class="description"><strong>Hiányzik:</strong> <code><?php echo esc_html(implode(', ', (array)$diag['pdf']['missing'])); ?></code></p><?php endif; ?>
                    <?php if (!empty($diag['pdf']['unknown'])): ?><p class="description"><strong>Ismeretlen:</strong> <code><?php echo esc_html(implode(', ', (array)$diag['pdf']['unknown'])); ?></code></p><?php endif; ?>
                </div>
            </div>
            <?php if (!empty($form['pdf_template']) || !empty($form['pdf_file'])): ?>
                <p class="description"><strong>Megjegyzés:</strong> a feltöltött/kész PDF az üres nyomtatvány letöltéséhez használható. A kitöltött PDF kizárólag a mentett HTML sablonból készül. Az üres PDF ettől független letöltés.</p>
            <?php endif; ?>
            <?php if (empty($diag['ok'])): ?><p><strong>Javaslat:</strong> mentsd az űrlapot, majd javítsd a felsorolt helyőrzőket vagy generáld újra a sablonokat.</p><?php endif; ?>
        </section>
        <?php
        return ob_get_clean();
    }

    private function set_form_setting_value(array &$settings, string $slug, array $form, string $key, string $value): void
    {
        if (!empty($form['custom'])) {
            if (!isset($settings['_custom_forms']) || !is_array($settings['_custom_forms'])) {
                $settings['_custom_forms'] = [];
            }
            if (!isset($settings['_custom_forms'][$slug]) || !is_array($settings['_custom_forms'][$slug])) {
                $settings['_custom_forms'][$slug] = [];
            }
            $settings['_custom_forms'][$slug][$key] = $value;
            return;
        }
        if (!isset($settings[$slug]) || !is_array($settings[$slug])) {
            $settings[$slug] = [];
        }
        $settings[$slug][$key] = $value;
    }

    private function finish_new_form_template_creation(string $slug, array $new_raw): array
    {
        $messages = [];
        $result = [
            'mode' => 'auto',
            'source_docx' => false,
            'docx_ready' => false,
            'pdf_ready' => false,
            'detected_fields' => 0,
            'messages' => &$messages,
        ];

        $settings = get_option(self::OPTION_NAME, []);
        if (!is_array($settings) || empty($settings['_custom_forms'][$slug]) || !is_array($settings['_custom_forms'][$slug])) {
            $messages[] = 'Az új űrlap sablonjait nem lehetett létrehozni, mert a mentett űrlap nem található.';
            return $result;
        }

        $form = $settings['_custom_forms'][$slug];
        $title = (string)($form['title'] ?? $slug);
        $mode = sanitize_key((string)($new_raw['creation_mode'] ?? 'auto'));
        if (!in_array($mode, ['auto', 'docx'], true)) {
            $mode = 'auto';
        }
        $result['mode'] = $mode;

        $blank_stored = $this->store_uploaded_template_file('szegbp_forms_new_blank_docx', $slug . '-blank', 'docx', $messages, $title);
        if ($blank_stored !== '') {
            $form['blank_docx'] = $blank_stored;
            $messages[] = $title . ': külön üres DOCX nyomtatvány elmentve; ezt a plugin változatlanul adja vissza.';
        }


        if ($mode === 'docx') {
            $stored = $this->store_uploaded_template_file('szegbp_forms_new_source_docx', $slug . '-source', 'docx', $messages, $title);
            if ($stored !== '') {
                $result['source_docx'] = true;
                $source_file = $this->get_template_file_from_relative($stored, 'docx');
                if ($source_file !== null) {
                    $detected = $this->extract_docx_field_candidates($source_file['path']);
                    $result['detected_fields'] = count($detected);
                    if (!empty($new_raw['extract_docx_fields']) && !empty($detected)) {
                        $posted_definition = trim(wp_unslash((string)($new_raw['fields_definition'] ?? '')));
                        $default_definition = trim($this->fields_to_definition($this->get_default_custom_fields()));
                        if ($posted_definition === '' || $posted_definition === $default_definition) {
                            $form['fields'] = $detected;
                            $messages[] = $title . ': a DOCX alapján ' . count($detected) . ' űrlapmezőt ismertem fel és használtam.';
                        } else {
                            $form['fields'] = $this->merge_detected_docx_fields((array)($form['fields'] ?? []), $detected);
                            $messages[] = $title . ': a DOCX-ben felismert mezőket összevetettem a kézzel megadott mezőlistával.';
                        }
                    }

                    $conversion = $this->prepare_docx_source_as_template($source_file['path'], (array)($form['fields'] ?? []));
                    if (!empty($conversion['ok'])) {
                        $form['docx_template'] = $stored;
                        $form['template_origin'] = 'docx';
                        $form['docx_pairing_report'] = $this->sanitize_docx_pairing_report($conversion + [
                            'detected' => array_map(static fn(array $field): string => (string)($field['name'] ?? ''), $detected),
                        ]);
                        $result['docx_ready'] = true;

                        $inserted = count((array)($conversion['inserted'] ?? []));
                        $existing = count((array)($conversion['existing'] ?? []));
                        $missing = (array)($conversion['missing'] ?? []);
                        $messages[] = $title . ': DOCX mezőpárosítás elkészült. Beillesztett: ' . $inserted . ', meglévő helyőrző: ' . $existing . ', ellenőrizendő: ' . count($missing) . '.';
                        if (!empty($missing)) {
                            $messages[] = $title . ': a DOCX-ben kézzel ellenőrizendő mezők: ' . implode(', ', $missing) . '.';
                        }

                        $messages[] = $title . ': a DOCX létrehozása nem készített automatikusan HTML sablont; azt külön művelettel generálhatod.';
                    } else {
                        $messages[] = $title . ': a DOCX mezőpárosítása nem sikerült' . (!empty($conversion['error']) ? ' (' . $conversion['error'] . ')' : '') . '. Automatikus sablonra álltam vissza.';
                        $this->delete_stored_template_file($stored);
                    }
                }
            } else {
                $messages[] = $title . ': DOCX-alapú létrehozást választottál, de nem érkezett használható DOCX. Automatikus sablont készítek.';
            }
        }

        if (empty($result['docx_ready'])) {
            $generated_docx = $this->generate_docx_template_for_form($slug, $form);
            if ($generated_docx !== '') {
                $form['docx_template'] = $generated_docx;
                $form['template_origin'] = 'auto';
                $form['docx_pairing_report'] = [];
                $result['docx_ready'] = true;
                $messages[] = $title . ': automatikus DOCX sablon elkészült.';
            } else {
                $messages[] = $title . ': az automatikus DOCX sablon nem készíthető el. Ellenőrizd a ZipArchive PHP bővítményt.';
            }
        }

        // v0.4.2: HTML sablon csak külön, explicit generálási vagy importálási művelettel készül.
        $result['pdf_ready'] = trim((string)($form['pdf_html_template'] ?? '')) !== '';

        $settings['_custom_forms'][$slug] = $form;
        update_option(self::OPTION_NAME, $settings, false);
        return $result;
    }

    private function sanitize_docx_pairing_report(array $report): array
    {
        $clean = [];
        foreach (['inserted', 'existing', 'missing', 'detected'] as $key) {
            $values = [];
            foreach ((array)($report[$key] ?? []) as $value) {
                $name = sanitize_key((string)$value);
                if ($name !== '') {
                    $values[$name] = true;
                }
            }
            $clean[$key] = array_keys($values);
        }
        return $clean;
    }

    private function merge_detected_docx_fields(array $existing, array $detected): array
    {
        $out = [];
        $seen_names = [];
        $seen_labels = [];
        foreach (array_merge($existing, $detected) as $field) {
            if (!is_array($field)) {
                continue;
            }
            $name = $this->sanitize_field_name((string)($field['name'] ?? ''));
            $label = sanitize_text_field((string)($field['label'] ?? $name));
            if ($name === '' || $label === '') {
                continue;
            }
            $label_key = $this->normalize_docx_label($label);
            if (isset($seen_names[$name]) || ($label_key !== '' && isset($seen_labels[$label_key]))) {
                continue;
            }
            $seen_names[$name] = true;
            if ($label_key !== '') {
                $seen_labels[$label_key] = true;
            }
            $out[] = [
                'name' => $name,
                'label' => $label,
                'type' => in_array((string)($field['type'] ?? 'text'), ['text', 'email', 'number', 'date', 'textarea', 'select', 'radio', 'checkbox', 'checkbox_group', 'checkbox_matrix', 'underline_choice'], true) ? (string)$field['type'] : 'text',
                'required' => !empty($field['required']),
                'placeholder' => sanitize_text_field((string)($field['placeholder'] ?? '')),
                'options' => is_array($field['options'] ?? null) ? $field['options'] : [],
                'matrix_rows' => is_array($field['matrix_rows'] ?? null) ? $field['matrix_rows'] : [],
                'matrix_columns' => is_array($field['matrix_columns'] ?? null) ? $field['matrix_columns'] : [],
            ];
        }
        return $out;
    }

    private function extract_docx_field_candidates(string $path): array
    {
        if (!class_exists('ZipArchive') || !class_exists('DOMDocument')) {
            return [];
        }
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            return [];
        }
        $xml = $zip->getFromName('word/document.xml');
        $zip->close();
        if (!is_string($xml) || $xml === '') {
            return [];
        }

        $document = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $loaded = $document->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        if (!$loaded) {
            return [];
        }
        $xpath = new DOMXPath($document);
        $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
        $labels = [];

        foreach ($xpath->query('//w:p') as $paragraph) {
            $text = trim($this->docx_node_text($paragraph, $xpath));
            if ($text === '') {
                continue;
            }
            if (preg_match('/^(.{2,100}?)(?:\s*[:;\-–—]?\s*)(?:\.{3,}|_{3,}|…{2,}|·{3,}|-{4,})/u', $text, $m)) {
                $label = $this->clean_docx_candidate_label((string)$m[1]);
                if ($label !== '') {
                    $labels[$this->normalize_docx_label($label)] = $label;
                }
            }
        }

        foreach ($xpath->query('//w:tr') as $row) {
            $cells = [];
            foreach ($xpath->query('./w:tc', $row) as $cell) {
                $cells[] = trim($this->docx_node_text($cell, $xpath));
            }
            if (count($cells) < 2) {
                continue;
            }
            for ($i = 0; $i < count($cells) - 1; $i++) {
                $label = $this->clean_docx_candidate_label((string)$cells[$i]);
                $value_cell = trim((string)$cells[$i + 1]);
                if ($label === '' || !$this->looks_like_empty_docx_fill($value_cell)) {
                    continue;
                }
                $labels[$this->normalize_docx_label($label)] = $label;
            }
        }

        $fields = [];
        $seen_names = [];
        foreach ($labels as $label) {
            $name = $this->sanitize_field_name($label);
            if ($name === '' || isset($seen_names[$name])) {
                continue;
            }
            $seen_names[$name] = true;
            $fields[] = [
                'name' => $name,
                'label' => $label,
                'type' => $this->guess_docx_field_type($label),
                'required' => false,
                'placeholder' => '',
                'options' => [],
            ];
        }
        return array_slice($fields, 0, 80);
    }

    private function docx_node_text(DOMNode $node, DOMXPath $xpath): string
    {
        $text = '';
        foreach ($xpath->query('.//w:t|.//w:tab|.//w:br', $node) as $part) {
            if ($part->localName === 'tab') {
                $text .= "\t";
            } elseif ($part->localName === 'br') {
                $text .= "\n";
            } else {
                $text .= (string)$part->nodeValue;
            }
        }
        return preg_replace('/[ \t]+/u', ' ', $text) ?? $text;
    }

    private function clean_docx_candidate_label(string $label): string
    {
        $label = preg_replace('/\s+/u', ' ', trim($label)) ?? trim($label);
        $label = trim($label, " \t\n\r\0\x0B:;-–—._");
        $length = function_exists('mb_strlen') ? mb_strlen($label, 'UTF-8') : strlen($label);
        if ($label === '' || $length < 2 || $length > 100) {
            return '';
        }
        if (preg_match('/^(dátum|keltezés|név|osztály)$/iu', $label)) {
            return $label;
        }
        if (preg_match('/^[0-9\W_]+$/u', $label)) {
            return '';
        }
        return sanitize_text_field($label);
    }

    private function looks_like_empty_docx_fill(string $value): bool
    {
        $value = trim($value);
        if ($value === '') {
            return true;
        }
        return (bool)preg_match('/^(?:\.{2,}|_{2,}|…+|·+|-{3,}|\s)+$/u', $value);
    }

    private function normalize_docx_label(string $label): string
    {
        $label = strtolower(remove_accents($label));
        $label = preg_replace('/[^a-z0-9]+/u', ' ', $label) ?? $label;
        return trim(preg_replace('/\s+/u', ' ', $label) ?? $label);
    }

    private function guess_docx_field_type(string $label): string
    {
        $normalized = $this->normalize_docx_label($label);
        if (str_contains($normalized, 'email') || str_contains($normalized, 'e mail')) {
            return 'email';
        }
        if (str_contains($normalized, 'datum') || str_contains($normalized, 'szuletesi ido') || str_contains($normalized, 'ervenyes')) {
            return 'date';
        }
        if (str_contains($normalized, 'indoklas') || str_contains($normalized, 'megjegyzes') || str_contains($normalized, 'leiras')) {
            return 'textarea';
        }
        return 'text';
    }

    private function generate_pdf_html_from_docx_template(string $path, array $form): string
    {
        if (!class_exists('ZipArchive') || !class_exists('DOMDocument')) {
            return '';
        }
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            return '';
        }
        $xml = $zip->getFromName('word/document.xml');
        $zip->close();
        if (!is_string($xml) || trim($xml) === '') {
            return '';
        }
        $document = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $loaded = $document->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        if (!$loaded) {
            return '';
        }
        $xpath = new DOMXPath($document);
        $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
        $body = $xpath->query('/w:document/w:body')->item(0);
        if (!$body instanceof DOMNode) {
            return '';
        }

        $content = '';
        foreach ($body->childNodes as $child) {
            if (!$child instanceof DOMElement) {
                continue;
            }
            if ($child->localName === 'p') {
                $content .= $this->docx_paragraph_to_pdf_html($child, $xpath);
            } elseif ($child->localName === 'tbl') {
                $content .= $this->docx_table_to_pdf_html($child, $xpath);
            }
        }
        $content = trim($content);
        if ($content === '') {
            return '';
        }

        $css = '<style>\n'
            . '.szegbp-pdf-page.szegbp-pdf-docx{box-sizing:border-box;width:794px;height:1123px;padding:48px 54px;background:#fff;color:#111;font-family:Arial,Helvetica,sans-serif;font-size:13.5px;line-height:1.34;overflow:hidden}\n'
            . '.szegbp-pdf-docx p{margin:0 0 7px}.szegbp-pdf-docx .is-center{text-align:center}.szegbp-pdf-docx .is-right{text-align:right}.szegbp-pdf-docx .is-justify{text-align:justify}\n'
            . '.szegbp-pdf-docx table{width:100%;border-collapse:collapse;margin:7px 0 10px;table-layout:fixed}.szegbp-pdf-docx td{border:1px solid #888;padding:5px 7px;vertical-align:top;word-wrap:break-word}.szegbp-pdf-docx td p:last-child{margin-bottom:0}\n'
            . '.szegbp-pdf-docx .szegbp-pdf-fill{display:inline-block;min-width:78px;min-height:1em;border-bottom:1px dotted #555;padding:0 3px;font-weight:600}\n'
            . '.szegbp-pdf-docx h1,.szegbp-pdf-docx h2,.szegbp-pdf-docx h3{margin:8px 0;text-align:center}.szegbp-pdf-docx h1{font-size:22px}.szegbp-pdf-docx h2{font-size:18px}.szegbp-pdf-docx h3{font-size:15px}\n'
            . '</style>';
        return $this->sanitize_pdf_html_template($css . '<div class="szegbp-pdf-page szegbp-pdf-docx">' . $content . '</div>');
    }

    private function docx_paragraph_to_pdf_html(DOMElement $paragraph, DOMXPath $xpath): string
    {
        $runs_html = '';
        foreach ($xpath->query('.//w:r', $paragraph) as $run) {
            if (!$run instanceof DOMElement) {
                continue;
            }
            $run_text = '';
            foreach ($run->childNodes as $part) {
                if (!$part instanceof DOMElement) {
                    continue;
                }
                if ($part->localName === 't') {
                    $run_text .= esc_html((string)$part->nodeValue);
                } elseif ($part->localName === 'tab') {
                    $run_text .= '&nbsp;&nbsp;&nbsp;&nbsp;';
                } elseif ($part->localName === 'br') {
                    $run_text .= '<br>';
                }
            }
            if ($run_text === '') {
                continue;
            }
            $is_bold = $xpath->query('./w:rPr/w:b|./w:rPr/w:bCs', $run)->length > 0;
            $is_italic = $xpath->query('./w:rPr/w:i|./w:rPr/w:iCs', $run)->length > 0;
            $is_underline = $xpath->query('./w:rPr/w:u', $run)->length > 0;
            if ($is_underline) {
                $run_text = '<u>' . $run_text . '</u>';
            }
            if ($is_italic) {
                $run_text = '<em>' . $run_text . '</em>';
            }
            if ($is_bold) {
                $run_text = '<strong>' . $run_text . '</strong>';
            }
            $runs_html .= $run_text;
        }
        if ($runs_html === '') {
            $runs_html = '&nbsp;';
        }
        $runs_html = $this->replace_docx_tokens_with_pdf_spans($runs_html);

        $class = '';
        $jc = $xpath->query('./w:pPr/w:jc', $paragraph)->item(0);
        if ($jc instanceof DOMElement) {
            $val = $jc->getAttributeNS('http://schemas.openxmlformats.org/wordprocessingml/2006/main', 'val');
            if ($val === 'center') {
                $class = ' class="is-center"';
            } elseif (in_array($val, ['right', 'end'], true)) {
                $class = ' class="is-right"';
            } elseif ($val === 'both') {
                $class = ' class="is-justify"';
            }
        }
        $style_node = $xpath->query('./w:pPr/w:pStyle', $paragraph)->item(0);
        $style = $style_node instanceof DOMElement ? strtolower((string)$style_node->getAttributeNS('http://schemas.openxmlformats.org/wordprocessingml/2006/main', 'val')) : '';
        if (str_contains($style, 'title') || str_contains($style, 'cim')) {
            return '<h1' . $class . '>' . $runs_html . '</h1>';
        }
        if (str_contains($style, 'heading1') || str_contains($style, 'fejlec1')) {
            return '<h2' . $class . '>' . $runs_html . '</h2>';
        }
        if (str_contains($style, 'heading2') || str_contains($style, 'fejlec2')) {
            return '<h3' . $class . '>' . $runs_html . '</h3>';
        }
        return '<p' . $class . '>' . $runs_html . '</p>';
    }

    private function docx_table_to_pdf_html(DOMElement $table, DOMXPath $xpath): string
    {
        $html = '<table><tbody>';
        foreach ($xpath->query('./w:tr', $table) as $row) {
            if (!$row instanceof DOMElement) {
                continue;
            }
            $html .= '<tr>';
            foreach ($xpath->query('./w:tc', $row) as $cell) {
                if (!$cell instanceof DOMElement) {
                    continue;
                }
                $cell_html = '';
                foreach ($xpath->query('./w:p', $cell) as $paragraph) {
                    if ($paragraph instanceof DOMElement) {
                        $cell_html .= $this->docx_paragraph_to_pdf_html($paragraph, $xpath);
                    }
                }
                $html .= '<td>' . ($cell_html !== '' ? $cell_html : '&nbsp;') . '</td>';
            }
            $html .= '</tr>';
        }
        return $html . '</tbody></table>';
    }

    private function replace_docx_tokens_with_pdf_spans(string $html): string
    {
        $html = preg_replace('/\{\{\s*([a-zA-Z0-9_-]+)\s*\}\}/', '<span class="szegbp-pdf-fill">{{$1}}</span>', $html) ?? $html;
        return preg_replace('/\[\[\s*([a-zA-Z0-9_-]+)\s*\]\]/', '<span class="szegbp-pdf-fill">{{$1}}</span>', $html) ?? $html;
    }

    private function set_form_setting_array_value(array &$settings, string $slug, array $form, string $key, array $value): void
    {
        if (!empty($form['custom'])) {
            if (!isset($settings['_custom_forms']) || !is_array($settings['_custom_forms'])) {
                $settings['_custom_forms'] = [];
            }
            if (!isset($settings['_custom_forms'][$slug]) || !is_array($settings['_custom_forms'][$slug])) {
                $settings['_custom_forms'][$slug] = [];
            }
            $settings['_custom_forms'][$slug][$key] = $value;
            return;
        }
        if (!isset($settings[$slug]) || !is_array($settings[$slug])) {
            $settings[$slug] = [];
        }
        $settings[$slug][$key] = $value;
    }

    private function generate_docx_template_for_form(string $slug, array $form): string
    {
        if (!class_exists('ZipArchive')) {
            return '';
        }
        $rows = [];
        foreach ((array)($form['fields'] ?? []) as $field) {
            if ((string)($field['type'] ?? '') === 'section') {
                continue;
            }
            $name = sanitize_key((string)($field['name'] ?? ''));
            if ($name === '') {
                continue;
            }
            if ((string)($field['type'] ?? '') === 'checkbox_group') {
                $lines = [];
                foreach ($this->checkbox_group_tokens((array)$field) as $token => $option_label) {
                    $lines[] = '{{' . $token . '}} ' . $option_label;
                }
                $rows[] = [
                    'name' => $name,
                    'label' => (string)($field['label'] ?? $name),
                    'value' => implode("\n", $lines),
                ];
            } elseif ((string)($field['type'] ?? '') === 'radio') {
                $lines = ['{{' . $name . '}}'];
                foreach ($this->radio_option_tokens((array)$field) as $token => $option_label) { $lines[] = '{{' . $token . '}} ' . $option_label; }
                $rows[] = ['name' => $name, 'label' => (string)($field['label'] ?? $name), 'value' => implode("\n", $lines)];
            } elseif ((string)($field['type'] ?? '') === 'checkbox_matrix') {
                $lines = [];
                foreach ($this->checkbox_matrix_tokens((array)$field) as $token => $cell_label) { $lines[] = '{{' . $token . '}} ' . $cell_label; }
                $rows[] = ['name' => $name, 'label' => (string)($field['label'] ?? $name), 'value' => implode("\n", $lines)];
            } elseif ((string)($field['type'] ?? '') === 'underline_choice') {
                $rows[] = [
                    'name' => $name,
                    'label' => (string)($field['label'] ?? $name),
                    'value' => '{{underline_choice:' . $name . '}}',
                ];
            } else {
                $rows[] = [
                    'name' => $name,
                    'label' => (string)($field['label'] ?? $name),
                    'value' => '{{' . $name . '}}',
                ];
            }
        }
        $tmp = $this->create_docx_file((string)($form['title'] ?? $slug), (string)($form['description'] ?? ''), $rows, false);
        if (!is_string($tmp) || $tmp === '' || !is_file($tmp)) {
            return '';
        }
        $storage = $this->get_template_storage();
        if (!wp_mkdir_p($storage['dir'])) {
            @unlink($tmp);
            return '';
        }
        $base = sanitize_file_name($slug . '-generated-template-' . gmdate('Ymd-His') . '.docx');
        $target = trailingslashit($storage['dir']) . $base;
        if (!copy($tmp, $target)) {
            @unlink($tmp);
            return '';
        }
        @unlink($tmp);
        @chmod($target, 0644);
        return 'templates/' . $base;
    }

    private function prepare_docx_source_as_template(string $template_path, array $fields): array
    {
        if (!class_exists('ZipArchive')) {
            return ['ok' => false, 'error' => 'ZipArchive nem érhető el', 'inserted' => [], 'existing' => [], 'missing' => []];
        }
        if (!class_exists('DOMDocument')) {
            return ['ok' => false, 'error' => 'DOM XML nem érhető el', 'inserted' => [], 'existing' => [], 'missing' => []];
        }

        $field_map = [];
        foreach ($fields as $field) {
            if ((string)($field['type'] ?? '') === 'section') {
                continue;
            }
            $name = sanitize_key((string)($field['name'] ?? ''));
            $label = trim((string)($field['label'] ?? ''));
            if ($name !== '' && $label !== '') {
                $field_map[$name] = $label;
            }
        }
        if (empty($field_map)) {
            return ['ok' => false, 'error' => 'nincs feldolgozható űrlapmező', 'inserted' => [], 'existing' => [], 'missing' => []];
        }

        $zip = new ZipArchive();
        if ($zip->open($template_path) !== true) {
            return ['ok' => false, 'error' => 'a DOCX nem nyitható meg', 'inserted' => [], 'existing' => [], 'missing' => array_keys($field_map)];
        }

        $inserted = [];
        $existing = [];
        $entries = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry = $zip->getNameIndex($i);
            if (is_string($entry) && preg_match('~^word/(document|header[0-9]+|footer[0-9]+)\.xml$~', $entry)) {
                $entries[] = $entry;
            }
        }

        foreach ($entries as $entry) {
            $xml = $zip->getFromName($entry);
            if (!is_string($xml)) {
                continue;
            }
            $document = new DOMDocument();
            $previous = libxml_use_internal_errors(true);
            $loaded = $document->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
            if (!$loaded) {
                continue;
            }
            $xpath = new DOMXPath($document);
            $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');

            foreach ($xpath->query('//w:p') as $paragraph) {
                $nodes = [];
                $combined = '';
                foreach ($xpath->query('.//w:t', $paragraph) as $text_node) {
                    $nodes[] = $text_node;
                    $combined .= $text_node->nodeValue;
                }
                if ($combined === '' || empty($nodes)) {
                    continue;
                }

                foreach ($field_map as $name => $label) {
                    $token = '{{' . $name . '}}';
                    if (strpos($combined, $token) !== false || strpos($combined, '[[' . $name . ']]') !== false) {
                        $existing[$name] = true;
                        continue;
                    }
                    if (isset($inserted[$name]) || isset($existing[$name])) {
                        continue;
                    }
                    $label_pos = function_exists('mb_stripos') ? mb_stripos($combined, $label, 0, 'UTF-8') : stripos($combined, $label);
                    if ($label_pos === false) {
                        continue;
                    }
                    // mb_stripos karakterpozíciót adhat; a DOCX csere byte offsettal dolgozik.
                    if (function_exists('mb_substr') && function_exists('mb_strlen')) {
                        $before_label = mb_substr($combined, 0, (int)$label_pos, 'UTF-8');
                        $label_start = strlen($before_label);
                        $label_length = strlen($label);
                    } else {
                        $label_start = (int)$label_pos;
                        $label_length = strlen($label);
                    }
                    $after_start = $label_start + $label_length;
                    $after = substr($combined, $after_start);
                    $replace_start = null;
                    $replace_length = 0;
                    if (preg_match('/(?:\.{3,}|_{3,}|…{2,}|·{3,}|-{3,})/u', $after, $match, PREG_OFFSET_CAPTURE)) {
                        $replace_start = $after_start + (int)$match[0][1];
                        $replace_length = strlen((string)$match[0][0]);
                    }

                    if ($replace_start !== null) {
                        if ($this->replace_docx_paragraph_text_range($nodes, $replace_start, $replace_length, $token)) {
                            $inserted[$name] = true;
                            $combined = $this->docx_paragraph_text_from_nodes($nodes);
                        }
                        continue;
                    }

                    $tail = trim($after);
                    if ($tail === '' || preg_match('/^[:;\-–—\s]*$/u', $after)) {
                        $last = end($nodes);
                        if ($last instanceof DOMNode) {
                            $last->nodeValue .= ' ' . $token;
                            $inserted[$name] = true;
                            $combined = $this->docx_paragraph_text_from_nodes($nodes);
                        }
                    }
                }
            }
            $zip->addFromString($entry, (string)$document->saveXML());
        }
        $zip->close();

        $report = $this->inspect_docx_template_placeholders($template_path, $fields);
        $found = array_fill_keys((array)($report['found'] ?? []), true);
        foreach ($found as $name => $_) {
            if (!isset($inserted[$name])) {
                $existing[$name] = true;
            }
        }
        return [
            'ok' => true,
            'inserted' => array_values(array_keys($inserted)),
            'existing' => array_values(array_keys($existing)),
            'missing' => array_values((array)($report['missing'] ?? [])),
        ];
    }

    private function docx_paragraph_text_from_nodes(array $nodes): string
    {
        $text = '';
        foreach ($nodes as $node) {
            if ($node instanceof DOMNode) {
                $text .= (string)$node->nodeValue;
            }
        }
        return $text;
    }

    private function replace_docx_paragraph_text_range(array $nodes, int $start, int $length, string $replacement): bool
    {
        if ($length <= 0) {
            return false;
        }
        $end = $start + $length;
        $cursor = 0;
        $start_index = null;
        $end_index = null;
        $start_offset = 0;
        $end_offset = 0;
        foreach ($nodes as $index => $node) {
            if (!$node instanceof DOMNode) {
                continue;
            }
            $node_text = (string)$node->nodeValue;
            $node_length = strlen($node_text);
            if ($start_index === null && $start >= $cursor && $start < $cursor + $node_length) {
                $start_index = $index;
                $start_offset = $start - $cursor;
            }
            if ($end_index === null && $end > $cursor && $end <= $cursor + $node_length) {
                $end_index = $index;
                $end_offset = $end - $cursor;
                break;
            }
            $cursor += $node_length;
        }
        if ($start_index === null || $end_index === null) {
            return false;
        }
        $prefix = substr((string)$nodes[$start_index]->nodeValue, 0, $start_offset);
        $suffix = substr((string)$nodes[$end_index]->nodeValue, $end_offset);
        $nodes[$start_index]->nodeValue = $prefix . $replacement . ($start_index === $end_index ? $suffix : '');
        for ($i = $start_index + 1; $i <= $end_index; $i++) {
            $nodes[$i]->nodeValue = $i === $end_index ? $suffix : '';
        }
        return true;
    }

    private function handle_selected_blank_docx_upload(array &$settings, string $slug, array $current_form, array &$messages): void
    {
        $input = 'szegbp_forms_blank_docx_' . $slug;
        if (empty($_FILES[$input]) || !is_array($_FILES[$input])) {
            return;
        }

        $file = $_FILES[$input];
        $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) {
            return;
        }

        $title = (string)($current_form['title'] ?? $slug);
        $old_relative = (string)($current_form['blank_docx'] ?? '');
        $stored = $this->store_uploaded_template_file($input, $slug . '-blank', 'docx', $messages, $title);

        // A fájlt az általános sablonfeltöltő már ne próbálja meg még egyszer feldolgozni.
        unset($_FILES[$input]);

        if ($stored === '') {
            $messages[] = $title . ': az üres DOCX nem került elmentésre. A fenti feltöltési hiba alapján ellenőrizd a fájlt vagy a szerver korlátait.';
            return;
        }

        $verified = $this->get_template_file_from_relative($stored, 'docx');
        if ($verified === null || empty($verified['path']) || !is_file((string)$verified['path'])) {
            $this->delete_stored_template_file($stored);
            $messages[] = $title . ': az üres DOCX átmásolása után a fájl nem volt visszaolvasható, ezért a beállítás nem lett módosítva.';
            return;
        }

        if ($old_relative !== '' && $old_relative !== $stored) {
            $this->delete_stored_template_file($old_relative);
        }

        $this->set_form_setting_value($settings, $slug, $current_form, 'blank_docx', $stored);
        $messages[] = $title . ': üres DOCX sikeresen elmentve: ' . (string)($verified['name'] ?? basename($stored)) . '. A plugin ezt a fájlt változatlanul adja vissza.';
    }

    private function handle_admin_template_uploads(array &$settings): array
    {
        $messages = [];
        $defaults = $this->get_default_forms();

        foreach ($defaults as $slug => $default) {
            if (!isset($settings[$slug]) || !is_array($settings[$slug])) {
                continue;
            }
            $this->handle_admin_template_uploads_for_form($settings[$slug], $slug, (string)($settings[$slug]['title'] ?? $default['title']), $messages);
        }

        if (isset($settings['_custom_forms']) && is_array($settings['_custom_forms'])) {
            foreach ($settings['_custom_forms'] as $slug => &$form_settings) {
                if (!is_array($form_settings)) {
                    continue;
                }
                $this->handle_admin_template_uploads_for_form($form_settings, sanitize_key((string)$slug), (string)($form_settings['title'] ?? $slug), $messages);
            }
            unset($form_settings);
        }

        return $messages;
    }

    private function handle_admin_template_uploads_for_form(array &$form_settings, string $slug, string $title, array &$messages): void
    {
        $docx_input = 'szegbp_forms_template_docx_' . $slug;
        $blank_docx_input = 'szegbp_forms_blank_docx_' . $slug;
        $pdf_input = 'szegbp_forms_template_pdf_' . $slug;
        $html_input = 'szegbp_forms_template_html_' . $slug;
        $pdf_map_preview_input = 'szegbp_forms_pdf_map_preview_' . $slug;

        $source_docx_input = 'szegbp_forms_source_docx_' . $slug;
        $source_docx = $this->store_uploaded_template_file($source_docx_input, $slug . '-source', 'docx', $messages, $title);
        if ($source_docx !== '') {
            $source_file = $this->get_template_file_from_relative($source_docx, 'docx');
            if ($source_file !== null) {
                $conversion = $this->prepare_docx_source_as_template($source_file['path'], (array)($form_settings['fields'] ?? []));
                if (!empty($conversion['ok'])) {
                    $this->delete_stored_template_file((string)($form_settings['docx_template'] ?? ''));
                    $form_settings['docx_template'] = $source_docx;
                    $form_settings['template_origin'] = 'docx';
                    $form_settings['docx_pairing_report'] = $this->sanitize_docx_pairing_report($conversion);
                    $inserted = (array)($conversion['inserted'] ?? []);
                    $existing = (array)($conversion['existing'] ?? []);
                    $missing = (array)($conversion['missing'] ?? []);
                    $messages[] = $title . ': a kész DOCX sablonosítása elkészült. Automatikusan beillesztett mezők: ' . count($inserted) . ', már meglévő helyőrzők: ' . count($existing) . '.';
                    if (!empty($missing)) {
                        $messages[] = $title . ': kézzel ellenőrizendő / nem felismert DOCX mezők: ' . implode(', ', $missing) . '.';
                    }
                    $messages[] = $title . ': a DOCX feltöltése nem módosította a HTML sablont. HTML csak a külön „HTML sablon generálása DOCX-ből” művelettel készül.';
                } else {
                    $messages[] = $title . ': a kész DOCX automatikus sablonosítása nem sikerült' . (!empty($conversion['error']) ? ' (' . $conversion['error'] . ')' : '') . '.';
                    $this->delete_stored_template_file($source_docx);
                }
            }
        }


        $blank_docx = $this->store_uploaded_template_file($blank_docx_input, $slug . '-blank', 'docx', $messages, $title);
        if ($blank_docx !== '') {
            $this->delete_stored_template_file((string)($form_settings['blank_docx'] ?? ''));
            $form_settings['blank_docx'] = $blank_docx;
            $messages[] = $title . ': üres DOCX nyomtatvány feltöltve. Ezt a plugin változatlanul adja vissza az üres letöltésnél.';
        }

        $docx = $this->store_uploaded_template_file($docx_input, $slug, 'docx', $messages, $title);
        if ($docx !== '') {
            $this->delete_stored_template_file((string)($form_settings['docx_template'] ?? ''));
            $form_settings['docx_template'] = $docx;
            $form_settings['template_origin'] = 'upload';
            $form_settings['docx_pairing_report'] = [];
            $messages[] = $title . ': DOCX sablon feltöltve és fájlszerkezete ellenőrizve.';
            $docx_file = $this->get_template_file_from_relative($docx, 'docx');
            if ($docx_file !== null) {
                $report = $this->inspect_docx_template_placeholders($docx_file['path'], (array)($form_settings['fields'] ?? []));
                $messages[] = $title . ': a DOCX feltöltése nem módosította a HTML sablont. HTML csak külön generálási kérésre készül.';
                if (!empty($report['missing'])) {
                    $messages[] = $title . ': a DOCX sablonból hiányzó mezőhelyőrzők: ' . implode(', ', $report['missing']) . '.';
                }
                if (!empty($report['unknown'])) {
                    $messages[] = $title . ': ismeretlen DOCX-helyőrzők: ' . implode(', ', $report['unknown']) . '.';
                }
            }
        }

        $pdf = $this->store_uploaded_template_file($pdf_input, $slug, 'pdf', $messages, $title);
        if ($pdf !== '') {
            $this->delete_stored_template_file((string)($form_settings['pdf_template'] ?? ''));
            $form_settings['pdf_template'] = $pdf;
            $form_settings['pdf_field_map'] = [];
            $messages[] = $title . ': PDF nyomtatvány feltöltve. A korábbi PDF mezőtérkép törölve lett, mert az új lap pozíciói eltérhetnek.';
            $generated_preview = $this->generate_pdf_map_preview_from_relative($pdf, $slug);
            if ($generated_preview !== '') {
                $this->delete_stored_template_file((string)($form_settings['pdf_map_preview'] ?? ''));
                $form_settings['pdf_map_preview'] = $generated_preview;
                $messages[] = $title . ': a PDF első oldalából automatikusan elkészült a mezőtérkép előnézeti képe.';
            } elseif (!class_exists('Imagick')) {
                $messages[] = $title . ': a szerveren nincs Imagick PDF-renderelés; a mezőtérképhez tölts fel külön PNG/JPG előnézeti képet.';
            }
        }

        $map_preview = $this->store_uploaded_template_file($pdf_map_preview_input, $slug . '-pdf-map', 'image', $messages, $title);
        if ($map_preview !== '') {
            $this->delete_stored_template_file((string)($form_settings['pdf_map_preview'] ?? ''));
            $form_settings['pdf_map_preview'] = $map_preview;
            $messages[] = $title . ': PDF mezőtérkép előnézeti kép feltöltve.';
        }

        $html = $this->store_uploaded_template_file($html_input, $slug, 'html', $messages, $title);
        if ($html !== '') {
            $html_file = $this->get_template_file_from_relative($html, 'html');
            if ($html_file !== null) {
                $contents = file_get_contents($html_file['path']); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
                if (is_string($contents)) {
                    $form_settings['pdf_html_template'] = $this->sanitize_pdf_html_template($contents);
                }
            }
            // v0.4.2: a HTML-fájl csak importforrás. Az aktív sablon mindig az adatbázisban mentett HTML.
            $this->delete_stored_template_file($html);
            $this->delete_stored_template_file((string)($form_settings['pdf_html_file'] ?? ''));
            $form_settings['pdf_html_file'] = '';
            $messages[] = $title . ': HTML sablon beolvasva a szerkesztőbe és adatbázisban mentve.';
        }
    }

    private function store_uploaded_template_file(string $input_name, string $slug, string $type, array &$messages, string $title): string
    {
        if (empty($_FILES[$input_name]) || !is_array($_FILES[$input_name])) {
            return '';
        }

        $file = $_FILES[$input_name];
        $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) {
            return '';
        }
        if ($error !== UPLOAD_ERR_OK) {
            $messages[] = $title . ': a ' . strtoupper($type) . ' sablon feltöltése sikertelen (feltöltési hibakód: ' . $error . ').';
            return '';
        }

        $original_name = sanitize_file_name((string)($file['name'] ?? ''));
        $tmp_name = (string)($file['tmp_name'] ?? '');
        if ($original_name === '' || $tmp_name === '' || !is_uploaded_file($tmp_name)) {
            $messages[] = $title . ': a ' . strtoupper($type) . ' sablon ideiglenes feltöltési fájlja nem érvényes.';
            return '';
        }

        $extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
        $valid_extension = ($type === 'docx' && $extension === 'docx')
            || ($type === 'pdf' && $extension === 'pdf')
            || ($type === 'html' && in_array($extension, ['html', 'htm'], true))
            || ($type === 'image' && in_array($extension, ['png', 'jpg', 'jpeg', 'webp'], true));
        if (!$valid_extension) {
            $messages[] = $title . ': nem megfelelő fájlkiterjesztés a ' . strtoupper($type) . ' sablonhoz.';
            return '';
        }

        $size = (int)($file['size'] ?? 0);
        $limit = $type === 'html' ? 1024 * 1024 : ($type === 'image' ? 6 * 1024 * 1024 : 8 * 1024 * 1024);
        if ($size <= 0 || $size > $limit) {
            $messages[] = $title . ': a ' . strtoupper($type) . ' sablon mérete nem megfelelő. Maximum: ' . size_format($limit) . '.';
            return '';
        }

        $validation_error = $this->validate_template_upload_file($tmp_name, $type);
        if ($validation_error !== '') {
            $messages[] = $title . ': ' . $validation_error;
            return '';
        }

        $storage = $this->get_template_storage();
        if (!wp_mkdir_p($storage['dir'])) {
            $messages[] = $title . ': a sablonok célmappája nem hozható létre.';
            return '';
        }

        $base = sanitize_file_name($slug . '-' . $type . '-' . gmdate('Ymd-His') . '-' . $original_name);
        $target = trailingslashit($storage['dir']) . $base;
        $counter = 1;
        while (file_exists($target)) {
            $base = sanitize_file_name($slug . '-' . $type . '-' . gmdate('Ymd-His') . '-' . $counter . '-' . $original_name);
            $target = trailingslashit($storage['dir']) . $base;
            $counter++;
        }

        if (!move_uploaded_file($tmp_name, $target)) {
            $messages[] = $title . ': a ' . strtoupper($type) . ' sablont nem sikerült a célmappába menteni.';
            return '';
        }

        @chmod($target, 0644);
        return 'templates/' . $base;
    }

    private function validate_template_upload_file(string $path, string $type): string
    {
        if ($type === 'pdf') {
            $handle = @fopen($path, 'rb');
            $prefix = $handle ? (string)fread($handle, 5) : '';
            if (is_resource($handle)) {
                fclose($handle);
            }
            return $prefix === '%PDF-' ? '' : 'a feltöltött fájl nem érvényes PDF-dokumentum.';
        }

        if ($type === 'docx') {
            if (!class_exists('ZipArchive')) {
                return 'a DOCX sablon ellenőrzéséhez szükséges ZipArchive PHP bővítmény nem érhető el.';
            }
            if (!class_exists('DOMDocument')) {
                return 'a feltöltött DOCX-sablon helyőrzőinek feldolgozásához szükséges DOM XML PHP bővítmény nem érhető el.';
            }
            $zip = new ZipArchive();
            if ($zip->open($path) !== true) {
                return 'a feltöltött fájl nem érvényes DOCX-csomag.';
            }
            $has_document = $zip->locateName('word/document.xml') !== false;
            $zip->close();
            return $has_document ? '' : 'a DOCX sablonból hiányzik a word/document.xml dokumentumtartalom.';
        }

        if ($type === 'html') {
            $contents = @file_get_contents($path);
            if (!is_string($contents) || str_contains($contents, "\0")) {
                return 'a feltöltött HTML sablon nem olvasható szöveges HTML-fájlként.';
            }
        }

        if ($type === 'image') {
            $info = @getimagesize($path);
            if (!is_array($info) || empty($info[0]) || empty($info[1])) {
                return 'a feltöltött PDF-előnézet nem érvényes kép.';
            }
        }

        return '';
    }


    private function disabled_php_functions(): array
    {
        $raw = (string)ini_get('disable_functions');
        if ($raw === '') {
            return [];
        }
        return array_values(array_filter(array_map('trim', explode(',', strtolower($raw)))));
    }

    private function php_function_available(string $name): bool
    {
        return function_exists($name) && !in_array(strtolower($name), $this->disabled_php_functions(), true);
    }

    private function find_libreoffice_binary(): string
    {
        $configured = '';
        if (defined('SZEGBP_FORMS_LIBREOFFICE_PATH')) {
            $configured = trim((string)constant('SZEGBP_FORMS_LIBREOFFICE_PATH'));
        }
        $configured = trim((string)apply_filters('szegbp_forms_libreoffice_path', $configured));
        if ($configured !== '' && is_file($configured)) {
            return $configured;
        }

        $candidates = [
            '/usr/bin/libreoffice',
            '/usr/bin/soffice',
            '/usr/local/bin/libreoffice',
            '/usr/local/bin/soffice',
            '/snap/bin/libreoffice',
            'C:\\Program Files\\LibreOffice\\program\\soffice.exe',
            'C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe',
        ];
        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        if ($this->php_function_available('shell_exec')) {
            foreach (['libreoffice', 'soffice'] as $command) {
                $found = trim((string)@shell_exec('command -v ' . escapeshellarg($command) . ' 2>/dev/null'));
                if ($found !== '' && is_file($found)) {
                    return $found;
                }
            }
        }
        return '';
    }

    private function run_external_command(array $args, string &$output = ''): bool
    {
        $output = '';
        if (empty($args)) {
            return false;
        }
        $command = implode(' ', array_map(static fn($arg): string => escapeshellarg((string)$arg), $args));

        if ($this->php_function_available('proc_open')) {
            $pipes = [];
            $process = @proc_open($command, [
                0 => ['pipe', 'r'],
                1 => ['pipe', 'w'],
                2 => ['pipe', 'w'],
            ], $pipes);
            if (is_resource($process)) {
                if (isset($pipes[0]) && is_resource($pipes[0])) {
                    fclose($pipes[0]);
                }
                $stdout = isset($pipes[1]) && is_resource($pipes[1]) ? stream_get_contents($pipes[1]) : '';
                $stderr = isset($pipes[2]) && is_resource($pipes[2]) ? stream_get_contents($pipes[2]) : '';
                if (isset($pipes[1]) && is_resource($pipes[1])) {
                    fclose($pipes[1]);
                }
                if (isset($pipes[2]) && is_resource($pipes[2])) {
                    fclose($pipes[2]);
                }
                $status = proc_close($process);
                $output = trim((string)$stdout . "\n" . (string)$stderr);
                return $status === 0;
            }
        }

        if ($this->php_function_available('exec')) {
            $lines = [];
            $status = 1;
            @exec($command . ' 2>&1', $lines, $status);
            $output = trim(implode("\n", $lines));
            return $status === 0;
        }
        return false;
    }

    private function delete_temp_directory(string $directory): void
    {
        if ($directory === '' || !is_dir($directory)) {
            return;
        }
        $items = @scandir($directory);
        if (!is_array($items)) {
            return;
        }
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = trailingslashit($directory) . $item;
            if (is_dir($path) && !is_link($path)) {
                $this->delete_temp_directory($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($directory);
    }

    private function empty_docx_template_values(array $form): array
    {
        $values = [];
        foreach ((array)($form['fields'] ?? []) as $field) {
            $name = sanitize_key((string)($field['name'] ?? ''));
            if ($name === '') {
                continue;
            }
            $values[$name] = '';
            if ((string)($field['type'] ?? '') === 'checkbox_group') {
                foreach ($this->checkbox_group_tokens((array)$field) as $token => $_label) { $values[(string)$token] = ''; }
            } elseif ((string)($field['type'] ?? '') === 'radio') {
                foreach ($this->radio_option_tokens((array)$field) as $token => $_label) { $values[(string)$token] = '☐'; }
            } elseif ((string)($field['type'] ?? '') === 'checkbox_matrix') {
                foreach ($this->checkbox_matrix_tokens((array)$field) as $token => $_label) { $values[(string)$token] = '☐'; }
            }
        }
        return $values;
    }

    private function create_docx_for_pdf_conversion(string $source_path, array $form, string $target_path): bool
    {
        if (!class_exists('ZipArchive') || !class_exists('DOMDocument') || !is_file($source_path)) {
            return false;
        }
        if (!@copy($source_path, $target_path)) {
            return false;
        }

        $zip = new ZipArchive();
        if ($zip->open($target_path) !== true) {
            @unlink($target_path);
            return false;
        }
        $values = $this->empty_docx_template_values($form);
        $fields = (array)($form['fields'] ?? []);
        $entries = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry = $zip->getNameIndex($i);
            if (is_string($entry) && preg_match('~^word/(document|header[0-9]+|footer[0-9]+)\\.xml$~', $entry)) {
                $entries[] = $entry;
            }
        }
        foreach ($entries as $entry) {
            $xml = $zip->getFromName($entry);
            if (!is_string($xml)) {
                continue;
            }
            $xml = $this->replace_docx_template_placeholders($xml, $values, false, $fields);
            $zip->addFromString($entry, $xml);
        }
        $zip->close();
        return is_file($target_path) && filesize($target_path) > 0;
    }

    private function generate_pdf_template_from_docx(string $slug, array $form): array
    {
        $docx = $this->get_form_template_file($form, 'docx');
        if ($docx === null) {
            return ['ok' => false, 'message' => 'Nincs használható DOCX sablon. Előbb tölts fel vagy készíts DOCX sablont.'];
        }
        $binary = $this->find_libreoffice_binary();
        if ($binary === '') {
            return ['ok' => false, 'message' => 'A szerveren nem található LibreOffice/soffice. A DOCX→PDF sablongeneráláshoz telepíts LibreOffice-ot, vagy add meg az elérési útját a SZEGBP_FORMS_LIBREOFFICE_PATH konstanssal.'];
        }
        if (!$this->php_function_available('proc_open') && !$this->php_function_available('exec')) {
            return ['ok' => false, 'message' => 'A LibreOffice elérhető, de a PHP-ban a proc_open és az exec is tiltva van, ezért a DOCX→PDF konverzió nem indítható el.'];
        }

        $storage = $this->get_template_storage();
        if (!wp_mkdir_p($storage['dir'])) {
            return ['ok' => false, 'message' => 'A sablonok célmappája nem hozható létre.'];
        }

        $tmp_root = trailingslashit(get_temp_dir()) . 'szegbp-forms-' . sanitize_key($slug) . '-' . wp_generate_password(10, false, false);
        if (!wp_mkdir_p($tmp_root)) {
            return ['ok' => false, 'message' => 'Az ideiglenes DOCX→PDF munkamappa nem hozható létre.'];
        }
        $input = trailingslashit($tmp_root) . 'template.docx';
        $profile = trailingslashit($tmp_root) . 'lo-profile';
        wp_mkdir_p($profile);

        try {
            if (!$this->create_docx_for_pdf_conversion((string)$docx['path'], $form, $input)) {
                return ['ok' => false, 'message' => 'A PDF-hez szükséges ideiglenes DOCX sablon nem készíthető el.'];
            }

            $profile_uri = 'file://' . str_replace('\\', '/', $profile);
            $output = '';
            $ok = $this->run_external_command([
                $binary,
                '--headless',
                '--nologo',
                '--nodefault',
                '--nolockcheck',
                '--nofirststartwizard',
                '-env:UserInstallation=' . $profile_uri,
                '--convert-to',
                'pdf',
                '--outdir',
                $tmp_root,
                $input,
            ], $output);

            $generated = trailingslashit($tmp_root) . 'template.pdf';
            if (!$ok || !is_file($generated) || filesize($generated) < 5) {
                $detail = trim($output);
                if (strlen($detail) > 350) {
                    $detail = substr($detail, 0, 350) . '…';
                }
                return [
                    'ok' => false,
                    'message' => 'A LibreOffice nem tudta PDF-fé alakítani a DOCX sablont.' . ($detail !== '' ? ' Részlet: ' . $detail : ''),
                ];
            }
            $handle = @fopen($generated, 'rb');
            $prefix = $handle ? (string)fread($handle, 5) : '';
            if (is_resource($handle)) {
                fclose($handle);
            }
            if ($prefix !== '%PDF-') {
                return ['ok' => false, 'message' => 'A DOCX konverzió eredménye nem érvényes PDF fájl.'];
            }

            $base = sanitize_file_name($slug . '-pdf-from-docx-' . gmdate('Ymd-His') . '.pdf');
            $target = trailingslashit($storage['dir']) . $base;
            $counter = 1;
            while (file_exists($target)) {
                $base = sanitize_file_name($slug . '-pdf-from-docx-' . gmdate('Ymd-His') . '-' . $counter . '.pdf');
                $target = trailingslashit($storage['dir']) . $base;
                $counter++;
            }
            if (!@copy($generated, $target)) {
                return ['ok' => false, 'message' => 'A létrehozott PDF sablont nem sikerült a sablonmappába menteni.'];
            }
            @chmod($target, 0644);
            $relative = 'templates/' . $base;
            $preview = $this->generate_pdf_map_preview_from_relative($relative, $slug);
            return [
                'ok' => true,
                'pdf' => $relative,
                'preview' => $preview,
                'engine' => basename($binary),
                'message' => '',
            ];
        } finally {
            $this->delete_temp_directory($tmp_root);
        }
    }

    private function generate_pdf_map_preview_from_relative(string $relative, string $slug): string
    {
        if (!class_exists('Imagick')) {
            return '';
        }
        $pdf = $this->get_template_file_from_relative($relative, 'pdf');
        if ($pdf === null) {
            return '';
        }

        $storage = $this->get_template_storage();
        if (!wp_mkdir_p($storage['dir'])) {
            return '';
        }

        $base = sanitize_file_name($slug . '-pdf-map-preview-' . gmdate('Ymd-His') . '.jpg');
        $target = trailingslashit($storage['dir']) . $base;
        $counter = 1;
        while (file_exists($target)) {
            $base = sanitize_file_name($slug . '-pdf-map-preview-' . gmdate('Ymd-His') . '-' . $counter . '.jpg');
            $target = trailingslashit($storage['dir']) . $base;
            $counter++;
        }

        try {
            $image = new Imagick();
            $image->setResolution(150, 150);
            $image->readImage((string)$pdf['path'] . '[0]');
            $image->setImageBackgroundColor('white');
            if (method_exists($image, 'setImageAlphaChannel') && defined('Imagick::ALPHACHANNEL_REMOVE')) {
                $image->setImageAlphaChannel(Imagick::ALPHACHANNEL_REMOVE);
            }
            $image->setImageFormat('jpeg');
            $image->setImageCompressionQuality(90);
            $image->stripImage();
            $ok = $image->writeImage($target);
            $image->clear();
            $image->destroy();
            if (!$ok || !is_file($target) || filesize($target) <= 0) {
                @unlink($target);
                return '';
            }
            @chmod($target, 0644);
            return 'templates/' . $base;
        } catch (Throwable $e) {
            if (is_file($target)) {
                @unlink($target);
            }
            return '';
        }
    }

    private function copy_stored_template_file(string $relative, string $new_slug, string $type): string
    {
        $source = $this->get_template_file_from_relative($relative, $type);
        if ($source === null) {
            return '';
        }

        $storage = $this->get_template_storage();
        if (!wp_mkdir_p($storage['dir'])) {
            return '';
        }

        $extension = strtolower(pathinfo((string)$source['path'], PATHINFO_EXTENSION));
        $base = sanitize_file_name($new_slug . '-' . $type . '-copy-' . gmdate('Ymd-His') . '.' . $extension);
        $target = trailingslashit($storage['dir']) . $base;
        $counter = 1;
        while (file_exists($target)) {
            $base = sanitize_file_name($new_slug . '-' . $type . '-copy-' . gmdate('Ymd-His') . '-' . $counter . '.' . $extension);
            $target = trailingslashit($storage['dir']) . $base;
            $counter++;
        }

        if (!copy((string)$source['path'], $target)) {
            return '';
        }
        @chmod($target, 0644);
        return 'templates/' . $base;
    }

    private function delete_stored_template_file(string $relative): void
    {
        $relative = $this->sanitize_template_relative_path($relative);
        if ($relative === '') {
            return;
        }

        $storage = $this->get_template_storage();
        $path = trailingslashit($storage['base_dir']) . $relative;
        $real_base = realpath($storage['base_dir']);
        $real_path = realpath($path);
        if ($real_base !== false && $real_path !== false && str_starts_with($real_path, $real_base) && is_file($real_path)) {
            @unlink($real_path);
        }
    }

    private function delete_referenced_template_files(array $forms): void
    {
        foreach ($forms as $form) {
            if (!is_array($form)) {
                continue;
            }
            foreach (['docx_template', 'blank_docx', 'pdf_template', 'pdf_html_file', 'pdf_map_preview'] as $key) {
                if (!empty($form[$key])) {
                    $this->delete_stored_template_file((string)$form[$key]);
                }
            }
        }
    }

    private function get_template_storage(): array
    {
        $uploads = wp_upload_dir(null, false);
        $base_dir = trailingslashit((string)$uploads['basedir']) . 'szegbp-forms';
        $base_url = trailingslashit((string)$uploads['baseurl']) . 'szegbp-forms';

        return [
            'base_dir' => $base_dir,
            'base_url' => $base_url,
            'dir' => trailingslashit($base_dir) . 'templates',
            'url' => trailingslashit($base_url) . 'templates',
        ];
    }

    private function sanitize_template_relative_path(string $relative): string
    {
        $relative = str_replace('\\\\', '/', $relative);
        $relative = ltrim($relative, '/');
        if ($relative === '' || str_contains($relative, '..')) {
            return '';
        }
        if (!preg_match('~^templates/[A-Za-z0-9._-]+\\.(docx|pdf|html|htm|png|jpg|jpeg|webp)$~i', $relative)) {
            return '';
        }
        return $relative;
    }

    private function get_form_template_file(array $form, string $type): ?array
    {
        $file_type = $type;
        if ($type === 'pdf') {
            $key = 'pdf_template';
        } elseif ($type === 'html') {
            $key = 'pdf_html_file';
        } elseif ($type === 'image') {
            $key = 'pdf_map_preview';
        } elseif ($type === 'blank_docx') {
            $key = 'blank_docx';
            $file_type = 'docx';
        } else {
            $key = 'docx_template';
            $file_type = 'docx';
        }

        return $this->get_template_file_from_relative((string)($form[$key] ?? ''), $file_type);
    }

    private function get_template_file_from_relative(string $relative, string $type): ?array
    {
        $relative = $this->sanitize_template_relative_path($relative);
        if ($relative === '') {
            return null;
        }

        $extension = strtolower(pathinfo($relative, PATHINFO_EXTENSION));
        if (($type === 'docx' && $extension !== 'docx')
            || ($type === 'pdf' && $extension !== 'pdf')
            || ($type === 'html' && !in_array($extension, ['html', 'htm'], true))
            || ($type === 'image' && !in_array($extension, ['png', 'jpg', 'jpeg', 'webp'], true))) {
            return null;
        }

        $storage = $this->get_template_storage();
        $path = trailingslashit($storage['base_dir']) . $relative;
        if (!is_file($path)) {
            return null;
        }

        return [
            'path' => $path,
            'url' => trailingslashit($storage['base_url']) . str_replace(' ', '%20', $relative),
            'name' => basename($relative),
        ];
    }

    private function get_pdf_html_template(string $slug, array $form, bool $for_admin = false): string
    {
        // v0.4.2: egyetlen aktív HTML-forrás van: az adatbázisban mentett szerkesztő-tartalom.
        // Régi HTML-fájl és automatikus fallback itt már nem írhatja felül.
        return trim((string)($form['pdf_html_template'] ?? ''));
    }

    private function get_default_generic_pdf_html_template(array $form): string
    {
        $fields = array_values(array_filter((array)($form['fields'] ?? []), static function ($field): bool {
            return is_array($field) && sanitize_key((string)($field['name'] ?? '')) !== '';
        }));
        $field_count = count(array_filter($fields, static function ($field): bool {
            return (string)($field['type'] ?? '') !== 'section';
        }));
        $density_class = $field_count > 14 ? ' is-dense' : ($field_count > 9 ? ' is-compact' : '');
        $field_html = '';

        foreach ($fields as $field) {
            $name = sanitize_key((string)($field['name'] ?? ''));
            $label = esc_html((string)($field['label'] ?? $name));
            $type = sanitize_key((string)($field['type'] ?? 'text'));
            if ($type === 'section') {
                if ($label !== '') {
                    $field_html .= '  <div class="szegbp-pdf-section">' . $label . '</div>' . "\n";
                }
                continue;
            }
            if ($name === '') {
                continue;
            }

            if ($type === 'textarea') {
                $field_html .= '  <div class="szegbp-pdf-field szegbp-pdf-field--long">' . "\n"
                    . '    <div class="szegbp-pdf-label">' . $label . '</div>' . "\n"
                    . '    <div class="szegbp-pdf-value">{{' . $name . '}}</div>' . "\n"
                    . '  </div>' . "\n";
            } elseif ($type === 'checkbox_group' || $type === 'radio') {
                $checks = [];
                $tokens = $type === 'radio' ? $this->radio_option_tokens((array)$field) : $this->checkbox_group_tokens((array)$field);
                foreach ($tokens as $token => $option_label) { $checks[] = '<div class="szegbp-pdf-check">{{' . $token . '}} ' . esc_html($option_label) . '</div>'; }
                $field_html .= '  <div class="szegbp-pdf-field szegbp-pdf-field--long szegbp-pdf-field--checks">' . "\n"
                    . '    <div class="szegbp-pdf-label">' . $label . '</div>' . "\n"
                    . '    <div class="szegbp-pdf-value">' . implode('', $checks) . '</div>' . "\n"
                    . '  </div>' . "\n";
            } elseif ($type === 'checkbox_matrix') {
                $matrix = '<table class="szegbp-pdf-matrix"><thead><tr><th></th>';
                foreach ((array)($field['matrix_columns'] ?? []) as $col_label) { $matrix .= '<th>' . esc_html((string)$col_label) . '</th>'; }
                $matrix .= '</tr></thead><tbody>';
                foreach ((array)($field['matrix_rows'] ?? []) as $row_key => $row_label) {
                    $matrix .= '<tr><th>' . esc_html((string)$row_label) . '</th>';
                    foreach ((array)($field['matrix_columns'] ?? []) as $col_key => $_col_label) { $matrix .= '<td>{{' . $this->matrix_cell_token($name, (string)$row_key, (string)$col_key) . '}}</td>'; }
                    $matrix .= '</tr>';
                }
                $matrix .= '</tbody></table>';
                $field_html .= '  <div class="szegbp-pdf-field szegbp-pdf-field--long"><div class="szegbp-pdf-label">' . $label . '</div><div class="szegbp-pdf-value">' . $matrix . '</div></div>' . "\n";
            } else {
                $field_html .= '  <div class="szegbp-pdf-field">' . "\n"
                    . '    <div class="szegbp-pdf-label">' . $label . '</div>' . "\n"
                    . '    <div class="szegbp-pdf-value">{{' . $name . '}}</div>' . "\n"
                    . '  </div>' . "\n";
            }
        }

        return '<style>
.szegbp-pdf-page{box-sizing:border-box;width:794px;height:1123px;overflow:hidden;padding:50px 58px 44px;background:#fff;color:#171717;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.38}
.szegbp-pdf-head{border-bottom:2px solid #667c4f;padding-bottom:11px;margin-bottom:22px}.szegbp-pdf-school{font-size:15px;font-weight:700;color:#667c4f;letter-spacing:.01em}.szegbp-pdf-title{margin:18px 0 8px;text-align:center;font-size:26px;line-height:1.16;color:#222}.szegbp-pdf-desc{max-width:620px;margin:0 auto 24px;text-align:center;color:#555;font-size:13.5px;line-height:1.42}
.szegbp-pdf-fields{border-top:1px solid #d9d9d9}.szegbp-pdf-section{margin:18px 0 8px;padding:8px 10px;border-left:4px solid #667c4f;background:#f1f5ec;color:#4f633d;font-size:16px;font-weight:700;page-break-after:avoid}.szegbp-pdf-field{display:table;table-layout:fixed;width:100%;border-bottom:1px solid #d9d9d9;page-break-inside:avoid}.szegbp-pdf-label,.szegbp-pdf-value{display:table-cell;box-sizing:border-box;padding:9px 10px;vertical-align:top}.szegbp-pdf-label{width:34%;background:#f6f7f3;color:#333;font-weight:700}.szegbp-pdf-value{width:66%;min-height:34px;white-space:pre-wrap;overflow-wrap:anywhere}.szegbp-pdf-field--long{display:block}.szegbp-pdf-field--long .szegbp-pdf-label,.szegbp-pdf-field--long .szegbp-pdf-value{display:block;width:100%}.szegbp-pdf-field--long .szegbp-pdf-value{min-height:66px;padding-top:10px}.szegbp-pdf-field--checks .szegbp-pdf-value{min-height:0}.szegbp-pdf-check{margin:0 0 5px;font-weight:600}.szegbp-pdf-matrix{width:100%;border-collapse:collapse}.szegbp-pdf-matrix th,.szegbp-pdf-matrix td{border:1px solid #ccc;padding:5px 7px;text-align:center}.szegbp-pdf-matrix th:first-child{text-align:left}
.szegbp-pdf-signatures{display:table;width:100%;table-layout:fixed;margin-top:58px}.szegbp-pdf-signature{display:table-cell;width:50%;padding:0 18px;text-align:center;vertical-align:bottom}.szegbp-pdf-signature-line{border-top:1px solid #333;padding-top:6px;font-size:12px;color:#444}.szegbp-pdf-date{text-align:left;padding-left:0}.szegbp-pdf-note{margin-top:20px;color:#666;font-size:11.5px;text-align:center}
.szegbp-pdf-page.is-compact{padding-top:42px;padding-bottom:36px;font-size:13.5px}.szegbp-pdf-page.is-compact .szegbp-pdf-title{font-size:23px;margin-top:13px}.szegbp-pdf-page.is-compact .szegbp-pdf-desc{margin-bottom:16px}.szegbp-pdf-page.is-compact .szegbp-pdf-label,.szegbp-pdf-page.is-compact .szegbp-pdf-value{padding:6px 8px}.szegbp-pdf-page.is-compact .szegbp-pdf-field--long .szegbp-pdf-value{min-height:48px}.szegbp-pdf-page.is-compact .szegbp-pdf-signatures{margin-top:38px}
.szegbp-pdf-page.is-dense{padding:34px 48px 30px;font-size:12px;line-height:1.28}.szegbp-pdf-page.is-dense .szegbp-pdf-head{margin-bottom:12px}.szegbp-pdf-page.is-dense .szegbp-pdf-title{font-size:20px;margin:10px 0 5px}.szegbp-pdf-page.is-dense .szegbp-pdf-desc{font-size:11px;margin-bottom:11px}.szegbp-pdf-page.is-dense .szegbp-pdf-label,.szegbp-pdf-page.is-dense .szegbp-pdf-value{padding:4px 7px}.szegbp-pdf-page.is-dense .szegbp-pdf-field--long .szegbp-pdf-value{min-height:34px}.szegbp-pdf-page.is-dense .szegbp-pdf-signatures{margin-top:25px}
</style>
<div class="szegbp-pdf-page' . $density_class . '">
  <div class="szegbp-pdf-head">
    <div class="szegbp-pdf-school">Szilágyi Erzsébet Gimnázium</div>
  </div>
  <h1 class="szegbp-pdf-title">{{_form_title}}</h1>
  <p class="szegbp-pdf-desc">{{_form_description}}</p>
  <div class="szegbp-pdf-fields">
' . $field_html . '  </div>
  <div class="szegbp-pdf-signatures">
    <div class="szegbp-pdf-signature szegbp-pdf-date">Dátum: ................................</div>
    <div class="szegbp-pdf-signature"><div class="szegbp-pdf-signature-line">aláírás</div></div>
  </div>
  <div class="szegbp-pdf-note">A dokumentum az online űrlap adataiból készült.</div>
</div>';
    }

    private function get_default_testneveles_pdf_html_template(): string
    {
        return <<<'HTML'
<style>
.szegbp-pdf-page{box-sizing:border-box;width:794px;height:1123px;padding:44px 56px 38px;background:#fff;color:#111;font-family:Arial,Helvetica,sans-serif;font-size:14.2px;line-height:1.35}
.szegbp-pdf-top{display:flex;justify-content:space-between;gap:28px;margin-bottom:12px}.szegbp-pdf-top p{margin:0 0 3px}.szegbp-pdf-title{text-align:center;margin:22px 0 20px}.szegbp-pdf-title h1{font-size:24px;margin:0 0 6px}.szegbp-pdf-title h2{font-size:15.5px;margin:0;font-weight:700}.szegbp-pdf-text{margin:0 0 12px;text-align:justify}.szegbp-pdf-fill{font-weight:700;border-bottom:1px dotted #444;min-width:70px;display:inline-block;padding:0 4px}.szegbp-pdf-section{font-size:16px;margin:14px 0 7px}.szegbp-pdf-note{font-weight:700;margin:10px 0}.szegbp-pdf-date-sign{display:flex;align-items:flex-end;justify-content:space-between;gap:30px;margin:18px 0 12px}.szegbp-pdf-sign{width:290px;text-align:center}.szegbp-pdf-sign span{display:block;border-top:1px solid #111;height:1px;margin-bottom:6px}.szegbp-pdf-sign p{margin:0;font-size:12px}.szegbp-pdf-hr{border:0;border-top:1px solid #222;margin:12px 0 13px}.szegbp-pdf-org-title{text-align:center;font-size:19px;margin:0 0 9px}.szegbp-pdf-info{width:100%;border-collapse:collapse;margin-top:7px}.szegbp-pdf-info th,.szegbp-pdf-info td{padding:4px 0;text-align:left;vertical-align:top}.szegbp-pdf-info th{width:260px;font-weight:700}.szegbp-pdf-footer{display:flex;justify-content:space-between;align-items:flex-end;gap:30px;margin-top:20px}.szegbp-pdf-footer .szegbp-pdf-sign{width:340px}
</style>
<div class="szegbp-pdf-page">
  <div class="szegbp-pdf-top">
    <div>
      <p><span class="szegbp-pdf-fill">{{igazgato_neve}}</span> igazgató részére</p>
      <p>Budapest I. Kerületi Szilágyi Erzsébet Gimnázium</p>
      <p>OM: 035219</p>
      <p>1016 Budapest, Mészáros utca 5-7.</p>
    </div>
    <div><p>Intézményi ikt.sz.: <span class="szegbp-pdf-fill">{{iktatoszam}}</span></p></div>
  </div>

  <div class="szegbp-pdf-title">
    <h1>Felmentési kérelem</h1>
    <h2>a mindennapos testnevelés keretében megszervezett tanórán való részvétel alól</h2>
  </div>

  <p class="szegbp-pdf-text">Alulírott <span class="szegbp-pdf-fill">{{szulo_neve}}</span> (szülő) a 2011. évi CXC. törvény 27. § (11) bekezdése alapján kérem hozzájárulását, hogy <span class="szegbp-pdf-fill">{{tanulo_neve}}</span> (gyermek, tanuló neve) <span class="szegbp-pdf-fill">{{osztaly}}</span> osztályos tanuló a mindennapos testnevelés keretében megszervezett heti öt testnevelés órából a <span class="szegbp-pdf-fill">{{kivaltott_nap}}</span> napon a <span class="szegbp-pdf-fill">{{ora_1}}</span>. órát és a <span class="szegbp-pdf-fill">{{ora_2}}</span>. órát a heti edzéslátogatással válthassa ki.</p>

  <h3 class="szegbp-pdf-section">Indoklás:</h3>
  <p class="szegbp-pdf-text">Gyermekem igazolt sportolói jogviszonyban álló versenyző, versenyengedéllyel rendelkezik, a <span class="szegbp-pdf-fill">{{sportszervezet_neve}}</span> sportszervezet keretei között szervezett heti <span class="szegbp-pdf-fill">{{edzes_alkalom}}</span> alkalommal, <span class="szegbp-pdf-fill">{{edzes_napok}}</span> napokon edzéslátogatáson vesz részt.</p>

  <div class="szegbp-pdf-date-sign">
    <p>Dátum: <span class="szegbp-pdf-fill">{{keltezes_datuma}}</span></p>
    <div class="szegbp-pdf-sign"><span></span><p>szülő / nagykorú tanuló aláírása</p></div>
  </div>

  <p class="szegbp-pdf-note">A versenyengedély bemutatása szükséges.</p>
  <hr class="szegbp-pdf-hr">
  <h2 class="szegbp-pdf-org-title">Sportszervezet igazolása</h2>
  <p class="szegbp-pdf-text">Igazolom, hogy a fent nevezett tanuló egyesületünkkel igazolt sportolói jogviszonyban álló, versenyengedéllyel rendelkező versenyzője, aki az alábbiak szerint vesz részt az edzéseken:</p>

  <table class="szegbp-pdf-info"><tbody>
    <tr><th>A sportszervezet/egyesület neve:</th><td><span class="szegbp-pdf-fill">{{sportszervezet_neve}}</span></td></tr>
    <tr><th>A tanuló sportága:</th><td><span class="szegbp-pdf-fill">{{sportag}}</span></td></tr>
    <tr><th>Versenyengedély száma:</th><td><span class="szegbp-pdf-fill">{{versenyengedely_szama}}</span></td></tr>
    <tr><th>Versenyengedély érvényessége:</th><td><span class="szegbp-pdf-fill">{{versenyengedely_ervenyes_tol}}</span>-tól <span class="szegbp-pdf-fill">{{versenyengedely_ervenyes_ig}}</span>-ig</td></tr>
    <tr><th>Az edző neve:</th><td><span class="szegbp-pdf-fill">{{edzo_neve}}</span></td></tr>
    <tr><th>A tanuló edzéseinek időpontjai:</th><td><span class="szegbp-pdf-fill">{{edzes_idopontok}}</span></td></tr>
  </tbody></table>

  <div class="szegbp-pdf-footer">
    <p>Dátum: <span class="szegbp-pdf-fill">{{sport_igazolas_datuma}}</span></p>
    <div class="szegbp-pdf-sign"><span></span><p>sportegyesület képviselőjének aláírása, bélyegzője</p></div>
  </div>
</div>
HTML;
    }

    public function shortcode_privacy_notice(array $atts = []): string
    {
        $atts = shortcode_atts([
            'title' => 'Űrlapok és nyomtatványok adatkezelési kiegészítése',
            'show_intro' => '1',
        ], $atts, 'szegbp_forms_adatkezeles');

        wp_enqueue_style('szegbp-forms-frontend');

        $privacy_url = $this->forms_privacy_policy_url();

        ob_start();
        ?>
        <div class="szegbp-forms-wrap szegbp-forms-wrap--privacy szegbp-container szegbp-ui">
            <section class="szegbp-forms-privacy-block szegbp-section">
                <p class="szegbp-forms-eyebrow szegbp-hero__badge">Adatkezelési kiegészítés</p>
                <h2><?php echo esc_html((string)$atts['title']); ?></h2>
                <?php if ((string)$atts['show_intro'] === '1'): ?>
                    <p class="szegbp-forms-privacy-lead">
                        Ez a szakasz a honlapon elérhető, kitölthető iskolai nyomtatványok működését írja le.
                        A teljes intézményi adatkezelési tájékoztató rendelkezéseit nem helyettesíti, hanem az űrlapmodul technikai működését pontosítja.
                    </p>
                <?php endif; ?>

                <div class="szegbp-forms-privacy-grid">
                    <article>
                        <h3>Milyen adatok érintettek?</h3>
                        <p>Az érintett adatok mindig az adott nyomtatvány mezőitől függenek, például tanuló neve, osztálya, dátum, kérelem indoka vagy kapcsolattartási adat.</p>
                    </article>
                    <article>
                        <h3>PDF és nyomtatási nézet</h3>
                        <p>A kitöltött PDF és a nyomtatási előnézet a látogató böngészőjében készül. Ezekhez a műveletekhez a plugin nem ment űrlapadatot a WordPress adatbázisába.</p>
                    </article>
                    <article>
                        <h3>Kitöltött DOCX letöltése</h3>
                        <p>Kitöltött DOCX készítésekor az űrlapadatok a dokumentum előállításához átmenetileg a szerverre kerülnek. A plugin a beküldött adatokat ellenőrzi, a DOCX-fájlt elkészíti, majd a kérést követően nem menti az adatokat saját adatbázisba.</p>
                    </article>
                    <article>
                        <h3>Üres nyomtatványok</h3>
                        <p>Az üres DOCX- és PDF-letöltések nem tartalmaznak látogatói űrlapadatot. Ezek nyilvános, kitöltés előtti nyomtatványfájlok.</p>
                    </article>
                    <article>
                        <h3>Feltöltött sablonok</h3>
                        <p>Az admin által feltöltött DOCX-, PDF- és HTML-sablonok a WordPress feltöltési könyvtárában tárolódnak, és a nyomtatványok előállításához használhatók.</p>
                    </article>
                    <article>
                        <h3>Naplózás és tárhely</h3>
                        <p>A plugin nem vezet külön űrlapadat-naplót. A webtárhely vagy biztonsági rendszer technikai hozzáférési naplói azonban a weboldal általános üzemeltetési szabályai szerint működhetnek.</p>
                    </article>
                </div>

                <div class="szegbp-forms-privacy-summary">
                    <h3>Rövid összefoglaló</h3>
                    <ul>
                        <li>A plugin nem menti a kitöltött űrlapadatokat saját WordPress adatbázistáblába.</li>
                        <li>A böngészős PDF és nyomtatás kliensoldali művelet.</li>
                        <li>A kitöltött DOCX átmeneti szerveroldali feldolgozással készül.</li>
                        <li>Az üres nyomtatványok nem tartalmaznak látogatói adatot.</li>
                    </ul>
                </div>

                <?php if ($privacy_url !== ''): ?>
                    <p class="szegbp-forms-privacy-more">
                        Teljes adatkezelési tájékoztató:
                        <a href="<?php echo esc_url($privacy_url); ?>"><?php echo esc_html(wp_parse_url($privacy_url, PHP_URL_HOST) ?: 'adatkezelési tájékoztató'); ?></a>
                    </p>
                <?php endif; ?>
            </section>
        </div>
        <?php
        return ob_get_clean();
    }

    private function forms_privacy_policy_url(): string
    {
        $url = function_exists('get_privacy_policy_url') ? (string)get_privacy_policy_url() : '';
        if ($url === '') {
            $page = get_page_by_path('privacy-policy');
            if ($page instanceof WP_Post) {
                $url = (string)get_permalink($page);
            }
        }
        return $url !== '' ? $url : home_url('/privacy-policy/');
    }

    private function privacy_policy_link_html(string $label = 'adatkezelési tájékoztató'): string
    {
        $url = $this->forms_privacy_policy_url();
        if ($url === '') {
            return esc_html($label);
        }

        return '<a href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }

    private function frontend_privacy_note_html(string $context = 'form'): string
    {
        $link = $this->privacy_policy_link_html('adatkezelési tájékoztatóban');

        if ($context === 'list') {
            return 'Az itt megadott adatok nem kerülnek mentésre a weboldal adatbázisába. Kitöltött DOCX letöltésekor az adatokat a szerver kizárólag a dokumentum előállításáig dolgozza fel. Részletek az ' . $link . '.';
        }

        return 'A kitöltött PDF és a nyomtatási nézet a böngésződben készül. Kitöltött DOCX letöltésekor az adatok kizárólag a dokumentum elkészítéséhez kerülnek átmenetileg feldolgozásra; a rendszer nem menti őket adatbázisba. Részletek az ' . $link . '.';
    }

    public function shortcode_forms(array $atts = []): string
    {
        $atts = shortcode_atts([
            'id' => '',
            'form' => '',
        ], $atts, 'szegbp_forms');

        $direct_slug = sanitize_key((string)($atts['id'] ?: $atts['form']));
        if ($direct_slug !== '') {
            return '<div class="szegbp-forms-wrap szegbp-forms-wrap--single szegbp-container szegbp-ui">' . $this->render_frontend_form($direct_slug) . '</div>';
        }

        wp_enqueue_style('szegbp-forms-frontend');
        wp_enqueue_script('szegbp-forms-frontend');

        $forms = $this->get_forms();
        $selected_slug = $this->get_selected_public_form_slug($forms);
        $selected_form = $selected_slug !== '' && isset($forms[$selected_slug]) ? $forms[$selected_slug] : null;

        ob_start();
        ?>
        <div class="szegbp-forms-wrap szegbp-container szegbp-ui">
            <section class="szegbp-forms-hero szegbp-hero">
                <p class="szegbp-forms-eyebrow szegbp-hero__badge">SZEGBP nyomtatványok</p>
                <h2 class="szegbp-hero__title">Iskolai űrlapok és letölthető nyomtatványok</h2>
                <p class="szegbp-forms-hero__lead szegbp-hero__lead">Válassz a lenyíló listából. Az oldal egyszerre csak a kiválasztott nyomtatványt tölti be, így áttekinthetőbb marad.</p>
                <p class="szegbp-forms-privacy-note"><?php echo wp_kses_post($this->frontend_privacy_note_html('list')); ?></p>
            </section>

            <section class="szegbp-forms-selector-card" aria-label="Nyomtatvány választása">
                <form method="get" class="szegbp-forms-selector-form">
                    <?php foreach ($this->get_safe_public_query_args(['szegbp_form']) as $key => $value): ?>
                        <input type="hidden" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>">
                    <?php endforeach; ?>

                    <label for="szegbp_forms_public_selector">Nyomtatvány kiválasztása</label>
                    <div class="szegbp-forms-selector-row">
                        <select id="szegbp_forms_public_selector" name="szegbp_form">
                            <option value="">Válassz nyomtatványt...</option>
                            <?php foreach ($forms as $slug => $form): ?>
                                <?php if (empty($form['enabled'])) { continue; } ?>
                                <option value="<?php echo esc_attr($slug); ?>" <?php selected($selected_slug, $slug); ?>><?php echo esc_html($form['title']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="szegbp-forms-button szegbp-forms-button-primary">Megnyitás</button>
                    </div>
                    <p class="szegbp-form-small-note">A „Megnyitás” után választhatsz: üres nyomtatvány letöltése vagy online kitöltés.</p>
                </form>
            </section>

            <?php if ($selected_form !== null): ?>
                <section class="szegbp-forms-selected-card">
                    <div>
                        <p class="szegbp-forms-eyebrow">Kiválasztott nyomtatvány</p>
                        <h3><?php echo esc_html($selected_form['title']); ?></h3>
                        <?php if (!empty($selected_form['description'])): ?>
                            <p><?php echo esc_html($selected_form['description']); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="szegbp-forms-selected-actions">
                        <?php echo $this->render_blank_download_links($selected_slug, $selected_form); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        <a class="szegbp-forms-button" href="#<?php echo esc_attr('szegbp-form-' . $selected_slug); ?>">Online kitöltés</a>
                    </div>
                </section>

                <div id="<?php echo esc_attr('szegbp-form-' . $selected_slug); ?>" class="szegbp-forms-anchor-block">
                    <?php echo $this->render_frontend_form($selected_slug, false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                </div>
            <?php else: ?>
                <section class="szegbp-forms-empty-state">
                    <h3>Először válassz nyomtatványt</h3>
                    <p>Így nem jelenik meg egyszerre az összes űrlap. Ez különösen mobilon és hosszabb kérelmeknél sokkal kezelhetőbb.</p>
                </section>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private function get_selected_public_form_slug(array $forms): string
    {
        $raw = isset($_GET['szegbp_form']) ? sanitize_key((string)wp_unslash($_GET['szegbp_form'])) : '';
        if ($raw !== '' && isset($forms[$raw]) && !empty($forms[$raw]['enabled'])) {
            return $raw;
        }
        return '';
    }

    private function get_safe_public_query_args(array $exclude = []): array
    {
        $args = [];
        foreach ($_GET as $key => $value) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $clean_key = sanitize_key((string)$key);
            if ($clean_key === '' || in_array($clean_key, $exclude, true) || is_array($value)) {
                continue;
            }
            $args[$clean_key] = sanitize_text_field((string)wp_unslash($value));
        }
        return $args;
    }

    private function render_blank_download_links(string $slug, array $form, string $preview_token = ''): string
    {
        $blank_docx = $this->get_form_template_file($form, 'blank_docx');
        $pdf_template = $this->get_form_template_file($form, 'pdf');

        $docx_args = [
            'action' => 'szegbp_forms_blank_docx',
            'form_slug' => $slug,
        ];
        if ($preview_token !== '') {
            $docx_args['preview_token'] = $preview_token;
        }
        $docx_url = add_query_arg($docx_args, admin_url('admin-post.php'));

        ob_start();
        ?>
        <?php if ($blank_docx !== null): ?>
            <a class="szegbp-forms-button szegbp-forms-button-primary" href="<?php echo esc_url($docx_url); ?>">Üres DOCX letöltése</a>
        <?php else: ?>
            <span class="szegbp-forms-button szegbp-forms-button-disabled" aria-disabled="true">Nincs üres DOCX feltöltve</span>
        <?php endif; ?>

        <?php if ($pdf_template !== null): ?>
            <a class="szegbp-forms-button" href="<?php echo esc_url($pdf_template['url']); ?>" download>Üres PDF letöltése</a>
        <?php elseif (!empty($form['pdf_file'])): ?>
            <a class="szegbp-forms-button" href="<?php echo esc_url(plugins_url('assets/forms/' . rawurlencode((string)$form['pdf_file']), __FILE__)); ?>" download>Üres PDF letöltése</a>
        <?php else: ?>
            <span class="szegbp-forms-button szegbp-forms-button-disabled" aria-disabled="true">Nincs üres PDF feltöltve</span>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    public function shortcode_single_form(array $atts = []): string
    {
        $atts = shortcode_atts([
            'id' => '',
            'form' => '',
        ], $atts, 'szegbp_form');

        $slug = sanitize_key((string)($atts['id'] ?: $atts['form']));
        return '<div class="szegbp-forms-wrap szegbp-forms-wrap--single szegbp-container szegbp-ui">' . $this->render_frontend_form($slug) . '</div>';
    }

    private function render_frontend_form(string $slug, bool $enqueue = true): string
    {
        $forms = $this->get_forms();
        if (!isset($forms[$slug]) || empty($forms[$slug]['enabled'])) {
            return '<div class="szegbp-forms-message">Ez az űrlap jelenleg nem érhető el.</div>';
        }

        return $this->render_frontend_form_data($slug, $forms[$slug], $enqueue, '');
    }

    private function render_frontend_form_data(string $slug, array $form, bool $enqueue = true, string $preview_token = ''): string
    {
        if ($enqueue) {
            wp_enqueue_style('szegbp-forms-frontend');
        }
        wp_enqueue_script('szegbp-forms-frontend');

        $fields_json = wp_json_encode($this->get_preview_labels($form), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $choice_options = [];
        foreach ((array)($form['fields'] ?? []) as $choice_field) {
            if (!in_array((string)($choice_field['type'] ?? ''), ['select', 'radio', 'underline_choice'], true)) { continue; }
            $choice_name = $this->sanitize_field_name((string)($choice_field['name'] ?? ''));
            if ($choice_name !== '') { $choice_options[$choice_name] = (array)($choice_field['options'] ?? []); }
        }
        $choice_options_json = wp_json_encode($choice_options, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $pdf_html_template = $this->get_pdf_html_template($slug, $form);

        ob_start();
        ?>
        <section class="szegbp-form-box szegbp-section" data-szegbp-form data-form-slug="<?php echo esc_attr($slug); ?>" data-preview-labels='<?php echo esc_attr((string)$fields_json); ?>' data-choice-options='<?php echo esc_attr((string)$choice_options_json); ?>'>
            <div class="szegbp-form-header szegbp-hero">
                <p class="szegbp-forms-eyebrow szegbp-hero__badge">Kitölthető nyomtatvány</p>
                <h2 class="szegbp-hero__title"><?php echo esc_html($form['title']); ?></h2>
                <?php if (!empty($form['description'])): ?>
                    <p><?php echo esc_html($form['description']); ?></p>
                <?php endif; ?>
                <p class="szegbp-forms-privacy-note"><?php echo wp_kses_post($this->frontend_privacy_note_html('form')); ?></p>
            </div>

            <form class="szegbp-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="szegbp_forms_docx">
                <input type="hidden" name="form_slug" value="<?php echo esc_attr($slug); ?>">
                <?php if ($preview_token !== ''): ?>
                    <input type="hidden" name="preview_token" value="<?php echo esc_attr($preview_token); ?>">
                <?php endif; ?>
                <?php wp_nonce_field(self::NONCE_ACTION, 'szegbp_forms_nonce'); ?>

                <div class="szegbp-form-layout">
                    <div class="szegbp-form-fields">
                        <?php foreach ((array)($form['fields'] ?? []) as $field): ?>
                            <?php echo $this->render_field($field); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        <?php endforeach; ?>
                    </div>

                    <aside class="szegbp-form-actions">
                        <h3>Kitöltött dokumentum</h3>
                        <button type="button" class="szegbp-forms-button szegbp-forms-button-primary" data-szegbp-pdf <?php disabled(trim($pdf_html_template) === ''); ?>>Kitöltött PDF letöltése</button>
                        <button type="button" class="szegbp-forms-button" data-szegbp-print <?php disabled(trim($pdf_html_template) === ''); ?>>Nyomtatás</button>
                        <button type="submit" class="szegbp-forms-button" <?php disabled($this->get_form_template_file($form, 'docx') === null); ?>>Kitöltött DOCX letöltése</button>
                        <button type="button" class="szegbp-forms-button szegbp-forms-button-ghost" data-szegbp-clear>Adatok törlése</button>
                        <p class="szegbp-form-small-note">A PDF közvetlenül készül, nem a böngésző nyomtatási fejlécével/láblécével, ezért nem kerül rá az oldal URL-je.</p>

                        <hr class="szegbp-form-actions-divider">
                        <h3>Üres nyomtatvány</h3>
                        <?php echo $this->render_blank_download_links($slug, $form, $preview_token); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </aside>
                </div>
            </form>

            <?php if (trim($pdf_html_template) !== ''): ?>
                <template data-szegbp-pdf-html-template><?php echo wp_kses($pdf_html_template, $this->get_allowed_pdf_template_html()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></template>
            <?php endif; ?>

            <?php echo $this->render_print_preview($slug, $form, $pdf_html_template); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </section>
        <?php
        return ob_get_clean();
    }

    private function render_print_preview(string $slug, array $form, string $pdf_html_template = ''): string
    {
        if (trim($pdf_html_template) !== '') {
            return '<div class="szegbp-form-print-area szegbp-form-html-preview" data-szegbp-preview data-szegbp-html-preview><iframe class="szegbp-form-html-preview__frame" data-szegbp-html-preview-frame sandbox="allow-same-origin" title="Dokumentum előnézet"></iframe></div>';
        }

        return '<div class="szegbp-form-print-area szegbp-form-preview-missing" data-szegbp-preview><p><strong>Nincs HTML dokumentumsablon beállítva.</strong></p><p>A kitöltött PDF, a dokumentum-előnézet és a nyomtatás csak a mentett HTML sablonból készül. Az adminban tölts be vagy generálj HTML sablont, majd mentsd az űrlapot.</p></div>';
    }

    private function render_testneveles_print_preview(array $form): string
    {
        ob_start();
        ?>
        <div class="szegbp-form-print-area" data-szegbp-preview>
            <div class="szegbp-form-print-page szegbp-form-official-page">
                <div class="szegbp-form-official-top">
                    <div>
                        <p><span data-preview-field="igazgato_neve">—</span> igazgató részére</p>
                        <p>Budapest I. Kerületi Szilágyi Erzsébet Gimnázium</p>
                        <p>OM: 035219</p>
                        <p>1016 Budapest, Mészáros utca 5-7.</p>
                    </div>
                    <div><p>Intézményi ikt.sz.: <span data-preview-field="iktatoszam">—</span></p></div>
                </div>

                <div class="szegbp-form-official-title">
                    <h1>Felmentési kérelem</h1>
                    <h2>a mindennapos testnevelés keretében megszervezett tanórán való részvétel alól</h2>
                </div>

                <p class="szegbp-form-official-text">
                    Alulírott <strong data-preview-field="szulo_neve">—</strong> (szülő) a 2011. évi CXC. törvény 27. § (11) bekezdése alapján kérem hozzájárulását, hogy
                    <strong data-preview-field="tanulo_neve">—</strong> (gyermek, tanuló neve)
                    <strong data-preview-field="osztaly">—</strong> osztályos tanuló a mindennapos testnevelés keretében megszervezett heti öt testnevelés órából
                    a <strong data-preview-field="kivaltott_nap">—</strong> napon a <strong data-preview-field="ora_1">—</strong>. órát és a <strong data-preview-field="ora_2">—</strong>. órát
                    a heti edzéslátogatással válthassa ki.
                </p>

                <h3>Indoklás:</h3>
                <p class="szegbp-form-official-text">
                    Gyermekem igazolt sportolói jogviszonyban álló versenyző, versenyengedéllyel rendelkezik, a
                    <strong data-preview-field="sportszervezet_neve">—</strong> sportszervezet keretei között szervezett heti
                    <strong data-preview-field="edzes_alkalom">—</strong> alkalommal,
                    <strong data-preview-field="edzes_napok">—</strong> napokon edzéslátogatáson vesz részt.
                </p>

                <div class="szegbp-form-official-date-sign">
                    <p>Dátum: <span data-preview-field="keltezes_datuma">—</span></p>
                    <div><span></span><p>szülő / nagykorú tanuló aláírása</p></div>
                </div>

                <p class="szegbp-form-official-note">A versenyengedély bemutatása szükséges.</p>
                <hr>
                <h2 class="szegbp-form-official-section-title">Sportszervezet igazolása</h2>
                <p class="szegbp-form-official-text">Igazolom, hogy a fent nevezett tanuló egyesületünkkel <strong>igazolt sportolói jogviszonyban álló, versenyengedéllyel rendelkező</strong> versenyzője, aki az alábbiak szerint vesz részt az edzéseken:</p>

                <table class="szegbp-form-official-list"><tbody>
                    <tr><th>A sportszervezet/egyesület neve:</th><td data-preview-field="sportszervezet_neve">—</td></tr>
                    <tr><th>A tanuló sportága:</th><td data-preview-field="sportag">—</td></tr>
                    <tr><th>Versenyengedély száma:</th><td data-preview-field="versenyengedely_szama">—</td></tr>
                    <tr><th>Versenyengedély érvényessége:</th><td><span data-preview-field="versenyengedely_ervenyes_tol">—</span>-tól <span data-preview-field="versenyengedely_ervenyes_ig">—</span>-ig</td></tr>
                    <tr><th>Az edző neve:</th><td data-preview-field="edzo_neve">—</td></tr>
                    <tr><th>A tanuló edzéseinek időpontjai:</th><td data-preview-field="edzes_idopontok">—</td></tr>
                </tbody></table>

                <div class="szegbp-form-official-date-sign szegbp-form-official-date-sign-bottom">
                    <p>Dátum: <span data-preview-field="sport_igazolas_datuma">—</span></p>
                    <div><span></span><p>sportegyesület képviselőjének aláírása, bélyegzője</p></div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function render_field(array $field): string
    {
        $name = (string)$field['name'];
        $id = 'szegbp_field_' . sanitize_html_class($name) . '_' . wp_rand(1000, 9999);
        $type = (string)($field['type'] ?? 'text');
        $required = !empty($field['required']);
        $placeholder = (string)($field['placeholder'] ?? '');
        $autocomplete = (string)($field['autocomplete'] ?? '');

        ob_start();
        ?>
        <?php if ($type === 'section'): ?>
            <div class="szegbp-form-section" role="heading" aria-level="3">
                <h3><?php echo esc_html((string)$field['label']); ?></h3>
            </div>
        <?php else: ?>
        <div class="szegbp-field szegbp-field-<?php echo esc_attr($type); ?>">
            <?php if ($type === 'checkbox'): ?>
                <label class="szegbp-single-checkbox" for="<?php echo esc_attr($id); ?>">
                    <input id="<?php echo esc_attr($id); ?>" type="checkbox" name="fields[<?php echo esc_attr($name); ?>]" value="1" <?php echo $required ? 'required' : ''; ?>>
                    <span><?php echo esc_html((string)$field['label']); ?><?php if ($required): ?> <em aria-hidden="true">*</em><?php endif; ?></span>
                </label>
            <?php else: ?>
            <label for="<?php echo esc_attr($id); ?>">
                <?php echo esc_html($field['label']); ?>
                <?php if ($required): ?><span aria-hidden="true">*</span><?php endif; ?>
            </label>

            <?php if ($type === 'textarea'): ?>
                <textarea id="<?php echo esc_attr($id); ?>" name="fields[<?php echo esc_attr($name); ?>]" rows="5" <?php echo $required ? 'required' : ''; ?> placeholder="<?php echo esc_attr($placeholder); ?>"></textarea>
            <?php elseif ($type === 'select'): ?>
                <select id="<?php echo esc_attr($id); ?>" name="fields[<?php echo esc_attr($name); ?>]" <?php echo $required ? 'required' : ''; ?>>
                    <option value="">Válassz...</option>
                    <?php foreach (($field['options'] ?? []) as $value => $label): ?>
                        <option value="<?php echo esc_attr((string)$value); ?>"><?php echo esc_html((string)$label); ?></option>
                    <?php endforeach; ?>
                </select>
            <?php elseif ($type === 'radio'): ?>
                <fieldset class="szegbp-radio-group" data-szegbp-radio-group="<?php echo esc_attr($name); ?>">
                    <legend class="screen-reader-text"><?php echo esc_html((string)$field['label']); ?></legend>
                    <?php foreach (($field['options'] ?? []) as $value => $option_label): ?>
                        <?php $option_id = $id . '_' . sanitize_html_class((string)$value); ?>
                        <label class="szegbp-radio-option" for="<?php echo esc_attr($option_id); ?>">
                            <input id="<?php echo esc_attr($option_id); ?>" type="radio" name="fields[<?php echo esc_attr($name); ?>]" value="<?php echo esc_attr((string)$value); ?>" data-szegbp-radio-item="<?php echo esc_attr($name); ?>" data-option-label="<?php echo esc_attr((string)$option_label); ?>" <?php echo $required ? 'required' : ''; ?>>
                            <span><?php echo esc_html((string)$option_label); ?></span>
                        </label>
                    <?php endforeach; ?>
                </fieldset>
            <?php elseif ($type === 'checkbox_group'): ?>
                <fieldset class="szegbp-checkbox-group" data-szegbp-checkbox-group="<?php echo esc_attr($name); ?>">
                    <legend class="screen-reader-text"><?php echo esc_html((string)$field['label']); ?></legend>
                    <?php foreach (($field['options'] ?? []) as $value => $option_label): ?>
                        <?php $option_id = $id . '_' . sanitize_html_class((string)$value); ?>
                        <label class="szegbp-checkbox-option" for="<?php echo esc_attr($option_id); ?>">
                            <input id="<?php echo esc_attr($option_id); ?>" type="checkbox" name="fields[<?php echo esc_attr($name); ?>][]" value="<?php echo esc_attr((string)$value); ?>" data-szegbp-checkbox-group-item="<?php echo esc_attr($name); ?>" data-option-token="<?php echo esc_attr($name . '_' . sanitize_key((string)$value)); ?>" data-option-label="<?php echo esc_attr((string)$option_label); ?>">
                            <span><?php echo esc_html((string)$option_label); ?></span>
                        </label>
                    <?php endforeach; ?>
                </fieldset>
                <?php if ($required): ?><p class="szegbp-checkbox-group-note">Legalább egy lehetőséget válassz.</p><?php endif; ?>
            <?php elseif ($type === 'checkbox_matrix'): ?>
                <div class="szegbp-checkbox-matrix-wrap">
                    <table class="szegbp-checkbox-matrix">
                        <thead><tr><th><?php echo esc_html((string)$field['label']); ?></th>
                            <?php foreach ((array)($field['matrix_columns'] ?? []) as $column_label): ?><th><?php echo esc_html((string)$column_label); ?></th><?php endforeach; ?>
                        </tr></thead>
                        <tbody>
                        <?php foreach ((array)($field['matrix_rows'] ?? []) as $row_key => $row_label): ?>
                            <tr><th scope="row"><?php echo esc_html((string)$row_label); ?></th>
                            <?php foreach ((array)($field['matrix_columns'] ?? []) as $column_key => $column_label): ?>
                                <?php $cell_id = $id . '_' . sanitize_html_class((string)$row_key) . '_' . sanitize_html_class((string)$column_key); $cell_token = $this->matrix_cell_token($name, (string)$row_key, (string)$column_key); ?>
                                <td><label for="<?php echo esc_attr($cell_id); ?>"><input id="<?php echo esc_attr($cell_id); ?>" type="checkbox" name="fields[<?php echo esc_attr($name); ?>][<?php echo esc_attr((string)$row_key); ?>][]" value="<?php echo esc_attr((string)$column_key); ?>" data-szegbp-matrix-item="<?php echo esc_attr($name); ?>" data-row-key="<?php echo esc_attr((string)$row_key); ?>" data-column-key="<?php echo esc_attr((string)$column_key); ?>" data-option-token="<?php echo esc_attr($cell_token); ?>" data-cell-label="<?php echo esc_attr((string)$row_label . ' – ' . (string)$column_label); ?>"></label></td>
                            <?php endforeach; ?></tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($required): ?><p class="szegbp-checkbox-group-note">Legalább egy mezőt jelölj ki.</p><?php endif; ?>
            <?php elseif ($type === 'underline_choice'): ?>
                <fieldset class="szegbp-underline-choice" data-szegbp-underline-choice="<?php echo esc_attr($name); ?>">
                    <legend class="screen-reader-text"><?php echo esc_html((string)$field['label']); ?></legend>
                    <?php foreach (($field['options'] ?? []) as $value => $option_label): ?>
                        <?php $option_id = $id . '_' . sanitize_html_class((string)$value); ?>
                        <label class="szegbp-choice-option" for="<?php echo esc_attr($option_id); ?>">
                            <input id="<?php echo esc_attr($option_id); ?>" type="radio" name="fields[<?php echo esc_attr($name); ?>]" value="<?php echo esc_attr((string)$value); ?>" data-szegbp-underline-choice-item="<?php echo esc_attr($name); ?>" data-option-label="<?php echo esc_attr((string)$option_label); ?>" <?php echo $required ? 'required' : ''; ?>>
                            <span><?php echo esc_html((string)$option_label); ?></span>
                        </label>
                    <?php endforeach; ?>
                </fieldset>
            <?php else: ?>
                <input id="<?php echo esc_attr($id); ?>" type="<?php echo esc_attr($type); ?>" name="fields[<?php echo esc_attr($name); ?>]" <?php echo $required ? 'required' : ''; ?> placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $autocomplete !== '' ? 'autocomplete="' . esc_attr($autocomplete) . '"' : ''; ?>>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    private function checkbox_option_token(string $field_name, string $option_value): string
    {
        $field_name = $this->sanitize_field_name($field_name);
        $option_value = sanitize_key(remove_accents($option_value));
        return trim($field_name . '_' . $option_value, '_');
    }

    private function checkbox_group_tokens(array $field): array
    {
        $tokens = [];
        $name = $this->sanitize_field_name((string)($field['name'] ?? ''));
        if ($name === '' || (string)($field['type'] ?? '') !== 'checkbox_group') {
            return $tokens;
        }
        foreach ((array)($field['options'] ?? []) as $value => $label) {
            $token = $this->checkbox_option_token($name, (string)$value);
            if ($token !== '') {
                $tokens[$token] = (string)$label;
            }
        }
        return $tokens;
    }

    private function matrix_cell_token(string $field_name, string $row_key, string $column_key): string
    {
        return trim($this->sanitize_field_name($field_name) . '_' . sanitize_key(remove_accents($row_key)) . '_' . sanitize_key(remove_accents($column_key)), '_');
    }

    private function checkbox_matrix_tokens(array $field): array
    {
        $tokens = [];
        $name = $this->sanitize_field_name((string)($field['name'] ?? ''));
        if ($name === '' || (string)($field['type'] ?? '') !== 'checkbox_matrix') { return $tokens; }
        foreach ((array)($field['matrix_rows'] ?? []) as $row_key => $row_label) {
            foreach ((array)($field['matrix_columns'] ?? []) as $column_key => $column_label) {
                $token = $this->matrix_cell_token($name, (string)$row_key, (string)$column_key);
                if ($token !== '') { $tokens[$token] = (string)$row_label . ' – ' . (string)$column_label; }
            }
        }
        return $tokens;
    }

    private function radio_option_tokens(array $field): array
    {
        $tokens = [];
        $name = $this->sanitize_field_name((string)($field['name'] ?? ''));
        if ($name === '' || (string)($field['type'] ?? '') !== 'radio') { return $tokens; }
        foreach ((array)($field['options'] ?? []) as $value => $label) {
            $token = $this->checkbox_option_token($name, (string)$value);
            if ($token !== '') { $tokens[$token] = (string)$label; }
        }
        return $tokens;
    }

    private function validate_submitted_form_values(array $form, array $raw_fields): array
    {
        $values = [];
        $rows = [];
        $errors = [];

        foreach ((array)($form['fields'] ?? []) as $field) {
            $name = (string)($field['name'] ?? '');
            $label = (string)($field['label'] ?? $name);
            $type = (string)($field['type'] ?? 'text');

            if ($type === 'section') {
                continue;
            }

            if ($type === 'checkbox') {
                $checked = !empty($raw_fields[$name]) && (string)$raw_fields[$name] !== '0';
                if (!empty($field['required']) && !$checked) {
                    $errors[] = $label . ': a jelölőnégyzet kijelölése kötelező.';
                }
                $value = $checked ? '☒' : '☐';
                $values[$name] = $value;
                $rows[] = ['name' => $name, 'label' => $label, 'value' => $value];
                continue;
            }

            if ($type === 'checkbox_group') {
                $options = is_array($field['options'] ?? null) ? $field['options'] : [];
                $raw_selected = $raw_fields[$name] ?? [];
                if (!is_array($raw_selected)) {
                    $raw_selected = $raw_selected === '' ? [] : [$raw_selected];
                }
                $selected_keys = [];
                $selected_labels = [];
                foreach ($raw_selected as $raw_option) {
                    $key = sanitize_key((string)$raw_option);
                    if ($key === '' || !isset($options[$key]) || in_array($key, $selected_keys, true)) {
                        continue;
                    }
                    $selected_keys[] = $key;
                    $selected_labels[] = (string)$options[$key];
                }
                if (!empty($field['required']) && empty($selected_keys)) {
                    $errors[] = $label . ': legalább egy lehetőséget válassz.';
                }
                $values[$name] = implode(', ', $selected_labels);
                foreach ($options as $option_value => $option_label) {
                    $token = $this->checkbox_option_token($name, (string)$option_value);
                    if ($token !== '') {
                        $values[$token] = in_array((string)$option_value, $selected_keys, true) ? '☒' : '☐';
                    }
                }
                $rows[] = ['name' => $name, 'label' => $label, 'value' => implode(', ', $selected_labels)];
                continue;
            }

            if ($type === 'radio') {
                $options = is_array($field['options'] ?? null) ? $field['options'] : [];
                $raw_choice = sanitize_key((string)($raw_fields[$name] ?? ''));
                if ($raw_choice !== '' && !isset($options[$raw_choice])) {
                    $errors[] = $label . ': nem megengedett választás.';
                    $raw_choice = '';
                }
                if (!empty($field['required']) && $raw_choice === '') { $errors[] = $label . ': válassz egy lehetőséget.'; }
                $choice_label = $raw_choice !== '' ? (string)$options[$raw_choice] : '';
                $values[$name] = $choice_label;
                $values[$name . '__key'] = $raw_choice;
                foreach ($options as $option_value => $_option_label) {
                    $token = $this->checkbox_option_token($name, (string)$option_value);
                    if ($token !== '') { $values[$token] = ((string)$option_value === $raw_choice) ? '☒' : '☐'; }
                }
                $rows[] = ['name' => $name, 'label' => $label, 'value' => $choice_label];
                continue;
            }

            if ($type === 'checkbox_matrix') {
                $rows_def = (array)($field['matrix_rows'] ?? []);
                $cols_def = (array)($field['matrix_columns'] ?? []);
                $raw_matrix = $raw_fields[$name] ?? [];
                if (!is_array($raw_matrix)) { $raw_matrix = []; }
                $selected_labels = [];
                $selected_count = 0;
                foreach ($rows_def as $row_key => $row_label) {
                    $raw_cols = $raw_matrix[$row_key] ?? [];
                    if (!is_array($raw_cols)) { $raw_cols = [$raw_cols]; }
                    $selected_cols = array_values(array_unique(array_map('sanitize_key', array_map('strval', $raw_cols))));
                    foreach ($cols_def as $col_key => $col_label) {
                        $selected = in_array((string)$col_key, $selected_cols, true);
                        $token = $this->matrix_cell_token($name, (string)$row_key, (string)$col_key);
                        if ($token !== '') { $values[$token] = $selected ? '☒' : '☐'; }
                        if ($selected) { $selected_count++; $selected_labels[] = (string)$row_label . ' – ' . (string)$col_label; }
                    }
                }
                if (!empty($field['required']) && $selected_count === 0) { $errors[] = $label . ': legalább egy mezőt jelölj ki.'; }
                $values[$name] = implode(', ', $selected_labels);
                $rows[] = ['name' => $name, 'label' => $label, 'value' => implode(', ', $selected_labels)];
                continue;
            }

            if ($type === 'underline_choice') {
                $options = is_array($field['options'] ?? null) ? $field['options'] : [];
                $raw_choice = sanitize_key((string)($raw_fields[$name] ?? ''));
                if ($raw_choice !== '' && !isset($options[$raw_choice])) {
                    $errors[] = $label . ': nem megengedett választás.';
                    $raw_choice = '';
                }
                if (!empty($field['required']) && $raw_choice === '') {
                    $errors[] = $label . ': válassz egy lehetőséget.';
                }
                $choice_label = $raw_choice !== '' ? (string)$options[$raw_choice] : '';
                $values[$name] = $choice_label;
                $values[$name . '__key'] = $raw_choice;
                $rows[] = ['name' => $name, 'label' => $label, 'value' => $choice_label];
                continue;
            }

            $raw_value = $raw_fields[$name] ?? '';
            if (is_array($raw_value)) {
                $raw_value = '';
            }

            $value = (string)$raw_value;
            $value = $type === 'textarea' ? sanitize_textarea_field($value) : sanitize_text_field($value);
            $value = trim($value);
            $max_length = $type === 'textarea' ? 4000 : 300;
            if (function_exists('mb_strlen') && mb_strlen($value) > $max_length) {
                $errors[] = $label . ': legfeljebb ' . $max_length . ' karakter adható meg.';
                $value = mb_substr($value, 0, $max_length);
            } elseif (!function_exists('mb_strlen') && strlen($value) > $max_length * 4) {
                $errors[] = $label . ': a megadott szöveg túl hosszú.';
                $value = substr($value, 0, $max_length * 4);
            }

            if (!empty($field['required']) && $value === '') {
                $errors[] = $label . ': kötelező mező.';
            }

            if ($value !== '' && $type === 'email' && !is_email($value)) {
                $errors[] = $label . ': érvényes e-mail-címet adj meg.';
            }
            if ($value !== '' && $type === 'number' && !is_numeric(str_replace(',', '.', $value))) {
                $errors[] = $label . ': számértéket adj meg.';
            }
            if ($value !== '' && $type === 'date') {
                $date = DateTime::createFromFormat('Y-m-d', $value);
                if (!$date || $date->format('Y-m-d') !== $value) {
                    $errors[] = $label . ': érvényes dátumot adj meg.';
                }
            }
            if ($type === 'select') {
                $options = is_array($field['options'] ?? null) ? $field['options'] : [];
                $selected_key = sanitize_key((string)$value);
                if ($selected_key !== '' && !isset($options[$selected_key])) {
                    $errors[] = $label . ': nem megengedett választás.';
                    $value = '';
                    $selected_key = '';
                } elseif ($selected_key !== '') {
                    $value = (string)$options[$selected_key];
                }
                $values[$name . '__key'] = $selected_key;
            }
            if ($type === 'date' && $value !== '' && !str_contains(implode(' ', $errors), $label . ': érvényes dátumot')) {
                $value = $this->format_date_value($value);
            }

            $values[$name] = $value;
            $rows[] = ['name' => $name, 'label' => $label, 'value' => $value];
        }

        return ['values' => $values, 'rows' => $rows, 'errors' => array_values(array_unique($errors))];
    }


    private function document_preview_html(string $html): string
    {
        $html = $this->sanitize_pdf_html_template($html);
        $html = preg_replace_callback('/\{\{\s*([a-zA-Z0-9_-]+)\s*\}\}/', static function (array $m): string {
            $key = sanitize_key((string)$m[1]);
            return '<span class="szegbp-doc-preview-value" data-doc-preview-field="' . esc_attr($key) . '">—</span>';
        }, $html) ?? $html;
        $html = preg_replace_callback('/\[\[\s*([a-zA-Z0-9_-]+)\s*\]\]/', static function (array $m): string {
            $key = sanitize_key((string)$m[1]);
            return '<span class="szegbp-doc-preview-value" data-doc-preview-field="' . esc_attr($key) . '">—</span>';
        }, $html) ?? $html;
        return $html;
    }

    public function handle_admin_preview(): void
    {
        if (!$this->can_manage_content()) {
            wp_die('Nincs jogosultság az előnézethez.', 403);
        }
        $nonce = isset($_POST['szegbp_forms_preview_nonce']) ? sanitize_text_field((string)wp_unslash($_POST['szegbp_forms_preview_nonce'])) : '';
        if ($nonce === '' || !wp_verify_nonce($nonce, 'szegbp_forms_admin_preview')) {
            wp_die('Érvénytelen előnézeti kérés.', 403);
        }

        $slug = sanitize_key((string)($_POST['szegbp_forms_edit_slug'] ?? ''));
        $forms = $this->get_forms();
        if ($slug === '' || !isset($forms[$slug])) {
            wp_die('Az előnézethez tartozó űrlap nem található.', 404);
        }

        $form = $forms[$slug];
        $row = is_array($_POST['szegbp_forms'][$slug] ?? null) ? wp_unslash($_POST['szegbp_forms'][$slug]) : [];
        if (is_array($row)) {
            $title = sanitize_text_field((string)($row['title'] ?? $form['title'] ?? ''));
            $description = sanitize_textarea_field((string)($row['description'] ?? $form['description'] ?? ''));
            $fields = $this->parse_fields_definition((string)($row['fields_definition'] ?? ''), (array)($form['fields'] ?? []));
            $form['title'] = $title !== '' ? $title : (string)($form['title'] ?? $slug);
            $form['description'] = $description;
            $form['fields'] = $fields;
            if (array_key_exists('pdf_html_template', $row)) {
                $form['pdf_html_template'] = $this->sanitize_pdf_html_template((string)$row['pdf_html_template']);
            }
            if (array_key_exists('pdf_map_preview', $row)) {
                $form['pdf_map_preview'] = sanitize_text_field((string)$row['pdf_map_preview']);
            }
            if (array_key_exists('pdf_field_map', $row)) {
                $form['pdf_field_map'] = $this->sanitize_pdf_field_map($row['pdf_field_map'], $fields);
            }
        }
        $form['enabled'] = 1;

        // v0.3.21: az admin Előnézet közvetlenül a HTML-szerkesztő aktuális
        // tartalmát használja. Így a preview nem tud visszaesni egy korábban
        // generált fallback sablonra, ha a szerkesztőben már más HTML van.
        $direct_preview_html = isset($_POST['szegbp_preview_html'])
            ? $this->sanitize_pdf_html_template((string)wp_unslash($_POST['szegbp_preview_html']))
            : '';

        $token = wp_generate_password(28, false, false);
        set_transient('szegbp_forms_preview_' . $token, [
            'user_id' => get_current_user_id(),
            'slug' => $slug,
            'form' => $form,
        ], HOUR_IN_SECONDS);

        $this->register_assets();
        wp_enqueue_style('szegbp-forms-frontend');
        wp_enqueue_script('szegbp-forms-frontend');
        nocache_headers();
        show_admin_bar(false);
        status_header(200);

        $html_file = $this->get_form_template_file($form, 'html');
        $pdf_file = $this->get_form_template_file($form, 'pdf');

        if (trim($direct_preview_html) !== '') {
            $document_html = $direct_preview_html;
            $document_source_label = 'a HTML-szerkesztő aktuális tartalma';
        } else {
            $saved_custom_html = trim((string)($form['pdf_html_template'] ?? ''));
            if ($saved_custom_html !== '') {
                $document_html = $saved_custom_html;
                $document_source_label = 'mentett egyedi HTML dokumentumsablon';
            } else {
                $document_html = $this->get_pdf_html_template($slug, $form, true);
                $document_source_label = str_contains($document_html, 'szegbp-pdf-docx')
                    ? 'DOCX-ből generált HTML dokumentumsablon'
                    : 'általános HTML dokumentumsablon';
            }
        }

        $document_preview = $this->document_preview_html($document_html);
        $is_docx_html = str_contains($document_html, 'szegbp-pdf-docx');
        $document_html_length = strlen($document_html);
        $document_html_hash = substr(hash('sha256', $document_html), 0, 10);
        ?>
        <!doctype html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo esc_html('Előnézet – ' . (string)$form['title']); ?></title>
            <?php wp_head(); ?>
            <style>
                body{margin:0;padding:20px;background:#eef0ec;color:#4f585e;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
                .szegbp-forms-admin-previewbar{max-width:1240px;margin:0 auto 14px;padding:12px 14px;border:1px solid #d8d0b9;border-radius:12px;background:#fff;display:flex;gap:12px;align-items:center;justify-content:space-between;box-sizing:border-box;box-shadow:0 4px 16px rgba(0,0,0,.04)}
                .szegbp-forms-admin-previewbar strong{color:#4f585e}.szegbp-forms-admin-previewbar p{margin:3px 0 0;font-size:13px;color:#687078}.szegbp-forms-admin-preview-actions{display:flex;gap:7px;flex-wrap:wrap}
                .szegbp-forms-admin-preview-actions button,.szegbp-preview-tabs button{padding:8px 12px;border:1px solid #667c4f;border-radius:8px;background:#667c4f;color:#fff;font-weight:700;cursor:pointer}.szegbp-forms-admin-preview-actions button.secondary,.szegbp-preview-tabs button{background:#fff;color:#667c4f}.szegbp-preview-tabs button.is-active{background:#667c4f;color:#fff}
                .szegbp-preview-tabs{max-width:1240px;margin:0 auto 12px;display:flex;gap:8px}.szegbp-preview-pane{display:none}.szegbp-preview-pane.is-active{display:block}
                .szegbp-forms-preview-wrap{max-width:1240px;margin:0 auto}
                .szegbp-document-preview-shell{max-width:1240px;margin:0 auto}.szegbp-document-preview-meta{margin:0 0 10px;padding:9px 12px;border-radius:10px;background:#fff;border:1px solid #d8d0b9;font-size:13px}.szegbp-document-page{display:flex;justify-content:center;overflow:auto;padding:18px;border-radius:12px;background:#dfe3df;border:1px solid #d1d6d1}.szegbp-document-page .szegbp-pdf-page{box-shadow:0 8px 28px rgba(0,0,0,.16);transform-origin:top center}.szegbp-document-page iframe{width:min(900px,100%);height:1100px;border:0;background:#fff;box-shadow:0 8px 28px rgba(0,0,0,.16)} .szegbp-document-page #szegbp-html-document-preview{width:min(900px,100%);min-height:1120px}
                .szegbp-doc-preview-value{display:inline-block;min-width:28px;padding:0 2px;color:#2f6f3e;font-weight:700}
                @media(max-width:700px){body{padding:10px}.szegbp-forms-admin-previewbar{align-items:flex-start;flex-direction:column}.szegbp-preview-tabs{flex-wrap:wrap}.szegbp-document-page{padding:8px}}
            </style>
        </head>
        <body>
            <div class="szegbp-forms-admin-previewbar">
                <div><strong>Admin előnézet / tesztkitöltés</strong><p>Az Űrlap nézet a webes kitöltést, a Dokumentum nézet a nyomtatható sablont mutatja.</p></div>
                <div class="szegbp-forms-admin-preview-actions">
                    <button type="button" id="szegbp-preview-fill">Mintaadatok</button>
                    <button type="button" class="secondary" id="szegbp-preview-clear">Kiürítés</button>
                </div>
            </div>
            <div class="szegbp-preview-tabs" role="tablist">
                <button type="button" class="is-active" data-preview-tab="form">Űrlap nézet</button>
                <button type="button" data-preview-tab="document">Dokumentum nézet</button>
            </div>
            <div class="szegbp-preview-pane is-active" data-preview-pane="form">
                <div class="szegbp-forms-preview-wrap szegbp-forms-wrap szegbp-container szegbp-ui">
                    <?php echo $this->render_frontend_form_data($slug, $form, false, $token); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                </div>
            </div>
            <div class="szegbp-preview-pane" data-preview-pane="document">
                <div class="szegbp-document-preview-shell">
                    <div class="szegbp-document-preview-meta"><strong>Dokumentumforrás:</strong> <?php echo esc_html($document_source_label); ?> · <?php echo esc_html(number_format_i18n($document_html_length)); ?> karakter · azonosító: <code><?php echo esc_html($document_html_hash); ?></code><?php if ($is_docx_html): ?> · Wordből generált HTML.<?php endif; ?></div>
                    <div class="szegbp-document-page">
                        <?php if (trim($document_html) !== ''): ?>
                            <iframe id="szegbp-html-document-preview" srcdoc="<?php echo esc_attr($document_preview); ?>" sandbox="allow-same-origin" title="HTML dokumentumsablon előnézet"></iframe>
                        <?php elseif ($pdf_file !== null): ?>
                            <iframe src="<?php echo esc_url($pdf_file['url']); ?>#toolbar=0&navpanes=0" title="PDF dokumentum előnézet"></iframe>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <script>
            (function(){
                function fire(el){el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
                function getVal(form,key){
                    var escKey=key.replace(/"/g,'\\"');
                    var group=Array.prototype.slice.call(form.querySelectorAll('input[data-szegbp-checkbox-group-item="'+escKey+'"]'));
                    if(group.length){return group.filter(function(i){return i.checked;}).map(function(i){return i.getAttribute('data-option-label')||i.value||'';}).filter(Boolean).join(', ');}
                    var el=form.elements['fields['+key+']']; if(!el){return '';}
                    if(el.tagName==='SELECT'){return el.selectedIndex>0?el.options[el.selectedIndex].text:'';}
                    if((el.type||'').toLowerCase()==='checkbox'){return el.checked?'☒':'☐';}
                    return el.value||'';
                }
                function syncDocument(){
                    var form=document.querySelector('.szegbp-form'); if(!form){return;}
                    document.querySelectorAll('[data-doc-preview-field]').forEach(function(el){var v=getVal(form,el.getAttribute('data-doc-preview-field')||'').trim();el.textContent=v||'—';});
                }
                function fill(){
                    var form=document.querySelector('.szegbp-form'); if(!form){return;}
                    form.querySelectorAll('input,select,textarea').forEach(function(el){
                        if(!el.name || el.type==='hidden' || el.type==='submit' || el.type==='button'){return;}
                        var label=''; var wrap=el.closest('.szegbp-form-field'); if(wrap){var l=wrap.querySelector('label'); if(l){label=l.textContent.replace('*','').trim();}}
                        if(el.type==='checkbox' || el.type==='radio'){el.checked=true;fire(el);return;}
                        if(el.tagName==='SELECT'){for(var i=0;i<el.options.length;i++){if(el.options[i].value){el.selectedIndex=i;break;}}fire(el);return;}
                        if(el.type==='date'){el.value=new Date().toISOString().slice(0,10);fire(el);return;}
                        if(el.type==='email'){el.value='teszt@pelda.hu';fire(el);return;}
                        if(el.type==='number'){el.value='1';fire(el);return;}
                        if(el.type==='tel'){el.value='+36 30 123 4567';fire(el);return;}
                        el.value='Teszt – '+(label || 'adat'); fire(el);
                    }); syncDocument();
                }
                document.querySelectorAll('[data-preview-tab]').forEach(function(btn){btn.addEventListener('click',function(){var key=btn.getAttribute('data-preview-tab');document.querySelectorAll('[data-preview-tab]').forEach(function(b){b.classList.toggle('is-active',b===btn);});document.querySelectorAll('[data-preview-pane]').forEach(function(p){p.classList.toggle('is-active',p.getAttribute('data-preview-pane')===key);});if(key==='document'){syncDocument();}});});
                var form=document.querySelector('.szegbp-form'); if(form){form.addEventListener('input',syncDocument);form.addEventListener('change',syncDocument);}
                var f=document.getElementById('szegbp-preview-fill'); if(f){f.addEventListener('click',fill);}
                var c=document.getElementById('szegbp-preview-clear'); if(c){c.addEventListener('click',function(){var b=document.querySelector('[data-szegbp-clear]'); if(b){b.click(); setTimeout(syncDocument,0);}});}
                syncDocument();
            }());
            </script>
            <?php wp_footer(); ?>
        </body>
        </html>
        <?php
        exit;
    }

    private function get_preview_form_by_token(string $token, string $slug): ?array
    {
        $token = preg_replace('/[^A-Za-z0-9]/', '', $token) ?? '';
        if ($token === '' || !is_user_logged_in() || !$this->can_manage_content()) {
            return null;
        }
        $data = get_transient('szegbp_forms_preview_' . $token);
        if (!is_array($data) || (int)($data['user_id'] ?? 0) !== get_current_user_id() || sanitize_key((string)($data['slug'] ?? '')) !== $slug || !is_array($data['form'] ?? null)) {
            return null;
        }
        return $data['form'];
    }

    public function handle_docx_download(): void
    {
        if (!isset($_POST['szegbp_forms_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['szegbp_forms_nonce'])), self::NONCE_ACTION)) {
            wp_die('Érvénytelen kérés.', 403);
        }

        $slug = sanitize_key((string)($_POST['form_slug'] ?? ''));
        $preview_token = isset($_POST['preview_token']) ? sanitize_text_field((string)wp_unslash($_POST['preview_token'])) : '';
        $preview_form = $preview_token !== '' ? $this->get_preview_form_by_token($preview_token, $slug) : null;
        $forms = $this->get_forms();

        if ($preview_form === null && (!isset($forms[$slug]) || empty($forms[$slug]['enabled']))) {
            wp_die('Az űrlap nem érhető el.', 404);
        }

        if (!class_exists('ZipArchive')) {
            wp_die('A DOCX generáláshoz szükséges ZipArchive PHP bővítmény nem érhető el a szerveren.', 500);
        }

        $raw_fields = isset($_POST['fields']) && is_array($_POST['fields']) ? wp_unslash($_POST['fields']) : [];
        $form = $preview_form !== null ? $preview_form : $forms[$slug];
        $validated = $this->validate_submitted_form_values($form, $raw_fields);
        if (!empty($validated['errors'])) {
            $errors_html = '<h1>A DOCX dokumentum nem készíthető el</h1><p>Javítsd az alábbi mezőket, majd próbáld újra:</p><ul>';
            foreach ($validated['errors'] as $error) {
                $errors_html .= '<li>' . esc_html((string)$error) . '</li>';
            }
            $errors_html .= '</ul><p><a href="javascript:history.back()">Vissza az űrlaphoz</a></p>';
            wp_die($errors_html, 'Hiányos vagy hibás űrlapadatok', ['response' => 400]); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
        $values = $validated['values'];
        $rows = $validated['rows'];

        $filename = sanitize_title($form['title']) . '-' . gmdate('Ymd-His') . '.docx';
        $template = $this->get_form_template_file($form, 'docx');
        if ($template === null) {
            wp_die('Ehhez az űrlaphoz nincs kitöltési DOCX sablon beállítva. Tölts fel egy DOCX sablont {{mezőnév}} helyőrzőkkel.', 500);
        }
        $tmp = $this->create_docx_from_template_file($template['path'], $values, false, (array)$form['fields']);

        $this->platform_log('info', 'Kitöltött DOCX nyomtatvány letöltve.', ['slug' => $slug, 'field_count' => count($rows), 'template' => 'custom']);

        nocache_headers();
        header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($tmp));
        readfile($tmp); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
        @unlink($tmp);
        exit;
    }

    public function handle_blank_docx_download(): void
    {
        // v0.4.2: az üres DOCX kizárólag a külön feltöltött eredeti fájl lehet.
        $slug = isset($_GET['form_slug']) ? sanitize_key((string)wp_unslash($_GET['form_slug'])) : '';
        $preview_token = isset($_GET['preview_token']) ? sanitize_text_field((string)wp_unslash($_GET['preview_token'])) : '';
        $preview_form = $preview_token !== '' ? $this->get_preview_form_by_token($preview_token, $slug) : null;
        $forms = $this->get_forms();

        if ($preview_form === null && (!isset($forms[$slug]) || empty($forms[$slug]['enabled']))) {
            wp_die('Az űrlap nem érhető el.', 404);
        }

        $form = $preview_form !== null ? $preview_form : $forms[$slug];
        $blank_template = $this->get_form_template_file($form, 'blank_docx');
        if ($blank_template === null) {
            wp_die('Ehhez az űrlaphoz nincs külön üres DOCX nyomtatvány feltöltve.', 404);
        }

        $filename = sanitize_title($form['title']) . '-ures.docx';
        $this->platform_log('info', 'Üres DOCX nyomtatvány letöltve.', ['slug' => $slug, 'template' => 'separate-blank']);

        nocache_headers();
        header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($blank_template['path']));
        readfile($blank_template['path']); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
        exit;
    }


    private function create_docx_from_template_file(string $template_path, array $values, bool $blank = false, array $fields = []): string
    {
        if (!class_exists('DOMDocument')) {
            wp_die('A feltöltött DOCX-sablon feldolgozásához szükséges DOM XML PHP bővítmény nem érhető el a szerveren.', 500);
        }

        $tmp = tempnam(sys_get_temp_dir(), 'szegbp-template-docx-');
        if ($tmp === false || !copy($template_path, $tmp)) {
            wp_die('Nem sikerült a DOCX sablonból ideiglenes fájlt létrehozni.', 500);
        }

        $zip = new ZipArchive();
        if ($zip->open($tmp) !== true) {
            @unlink($tmp);
            wp_die('A feltöltött DOCX sablon nem nyitható meg.', 500);
        }

        $xml_entries = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (is_string($name) && preg_match('~^word/(document|header[0-9]+|footer[0-9]+)\.xml$~', $name)) {
                $xml_entries[] = $name;
            }
        }

        foreach ($xml_entries as $entry) {
            $xml = $zip->getFromName($entry);
            if (!is_string($xml)) {
                continue;
            }
            $xml = $this->replace_docx_template_placeholders($xml, $values, $blank, $fields);
            $zip->addFromString($entry, $xml);
        }

        $zip->close();
        return $tmp;
    }

    private function inspect_docx_template_placeholders(string $template_path, array $fields): array
    {
        $found = [];
        if (!class_exists('ZipArchive')) {
            return ['found' => [], 'missing' => array_column($fields, 'name'), 'unknown' => []];
        }
        $zip = new ZipArchive();
        if ($zip->open($template_path) !== true) {
            return ['found' => [], 'missing' => array_column($fields, 'name'), 'unknown' => []];
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry = $zip->getNameIndex($i);
            if (!is_string($entry) || !preg_match('~^word/(document|header[0-9]+|footer[0-9]+)\.xml$~', $entry)) {
                continue;
            }
            $xml = $zip->getFromName($entry);
            if (!is_string($xml)) {
                continue;
            }
            $text = $this->docx_xml_visible_text($xml);
            if (preg_match_all('/(?:\{\{|\[\[)\s*([a-zA-Z0-9_-]+)\s*(?:\}\}|\]\])/', $text, $matches)) {
                foreach ($matches[1] as $match) {
                    $found[] = sanitize_key((string)$match);
                }
            }
            if (preg_match_all('/\{\{\s*underline_choice:([a-zA-Z0-9_-]+)/', $text, $choice_matches)) {
                foreach ($choice_matches[1] as $match) { $found[] = sanitize_key((string)$match); }
            }
        }
        $zip->close();
        $found = array_values(array_unique(array_filter($found)));
        $expected = [];
        foreach ($fields as $field) {
            $field_type = (string)($field['type'] ?? '');
            if ($field_type === 'section') {
                continue;
            }
            if ($field_type === 'checkbox_group') {
                $expected = array_merge($expected, array_keys($this->checkbox_group_tokens((array)$field)));
            } elseif ($field_type === 'radio') {
                $expected[] = sanitize_key((string)($field['name'] ?? ''));
                $expected = array_merge($expected, array_keys($this->radio_option_tokens((array)$field)));
            } elseif ($field_type === 'checkbox_matrix') {
                $expected = array_merge($expected, array_keys($this->checkbox_matrix_tokens((array)$field)));
            } else {
                $expected[] = sanitize_key((string)($field['name'] ?? ''));
            }
        }
        $expected = array_values(array_unique(array_filter($expected)));
        return [
            'found' => $found,
            'missing' => array_values(array_diff($expected, $found)),
            'unknown' => array_values(array_diff($found, $expected)),
        ];
    }

    private function docx_xml_visible_text(string $xml): string
    {
        if (!class_exists('DOMDocument')) {
            $plain = preg_replace('/<[^>]+>/', '', $xml);
            return html_entity_decode((string)$plain, ENT_QUOTES | ENT_XML1, 'UTF-8');
        }

        $document = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $loaded = $document->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        if (!$loaded) {
            return '';
        }
        $xpath = new DOMXPath($document);
        $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
        $paragraphs = [];
        foreach ($xpath->query('//w:p') as $paragraph) {
            $text = '';
            foreach ($xpath->query('.//w:t', $paragraph) as $node) {
                $text .= $node->nodeValue;
            }
            $paragraphs[] = $text;
        }
        return implode("\n", $paragraphs);
    }

    private function replace_docx_template_placeholders(string $xml, array $values, bool $blank = false, array $fields = []): string
    {
        if (!class_exists('DOMDocument')) {
            foreach ($values as $name => $value) {
                $safe_value = $this->docx_template_plain_value((string)$value);
                $xml = str_replace(['{{' . $name . '}}', '[[' . $name . ']]'], $safe_value, $xml);
            }
            return $xml;
        }

        $document = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $loaded = $document->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        if (!$loaded) {
            return $xml;
        }

        $labels = [];
        $checkbox_tokens = [];
        foreach ($fields as $field) {
            if ((string)($field['type'] ?? '') === 'section') {
                continue;
            }
            $field_name = (string)($field['name'] ?? '');
            $labels[$field_name] = (string)($field['label'] ?? $field_name ?: 'Mező');
            if ((string)($field['type'] ?? '') === 'checkbox_group') {
                foreach ($this->checkbox_group_tokens((array)$field) as $token => $option_label) { $labels[$token] = (string)$option_label; $checkbox_tokens[$token] = true; }
            } elseif ((string)($field['type'] ?? '') === 'radio') {
                foreach ($this->radio_option_tokens((array)$field) as $token => $option_label) { $labels[$token] = (string)$option_label; $checkbox_tokens[$token] = true; }
            } elseif ((string)($field['type'] ?? '') === 'checkbox_matrix') {
                foreach ($this->checkbox_matrix_tokens((array)$field) as $token => $cell_label) { $labels[$token] = (string)$cell_label; $checkbox_tokens[$token] = true; }
            }
        }
        $xpath = new DOMXPath($document);
        $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
        $choice_fields = [];
        foreach ($fields as $field) {
            if (!in_array((string)($field['type'] ?? ''), ['select', 'radio', 'underline_choice'], true)) { continue; }
            $choice_name = $this->sanitize_field_name((string)($field['name'] ?? ''));
            if ($choice_name !== '') { $choice_fields[$choice_name] = (array)($field['options'] ?? []); }
        }
        foreach ($xpath->query('//w:p') as $paragraph) {
            while ($this->replace_underline_choice_in_docx_paragraph($document, $xpath, $paragraph, $values, $choice_fields)) {
                // Az összes aláhúzandó választás helyőrzőjét lecseréljük a bekezdésben.
            }
            foreach ($values as $name => $value) {
                $tokens = ['{{' . $name . '}}', '[[' . $name . ']]'];
                foreach ($tokens as $token) {
                    while ($this->replace_token_in_docx_paragraph($document, $xpath, $paragraph, $token, (string)$name, (string)$value, $blank && !isset($checkbox_tokens[(string)$name]), $labels[(string)$name] ?? (string)$name)) {
                        // Minden előfordulást lecserélünk, akkor is, ha a Word több futamra bontotta.
                    }
                }
            }
        }
        return (string)$document->saveXML();
    }

    private function replace_underline_choice_in_docx_paragraph(DOMDocument $document, DOMXPath $xpath, DOMNode $paragraph, array $values, array $choice_fields): bool
    {
        $nodes = [];
        $combined = '';
        foreach ($xpath->query('.//w:t', $paragraph) as $text_node) {
            $nodes[] = $text_node;
            $combined .= $text_node->nodeValue;
        }
        if ($combined === '' || !preg_match('/\{\{\s*underline_choice:([a-zA-Z0-9_-]+)(?:\|([^{}|]*?)\|([^{}]*?))?\s*\}\}/u', $combined, $match, PREG_OFFSET_CAPTURE)) {
            return false;
        }

        $token = (string)$match[0][0];
        $start = (int)$match[0][1];
        $name = $this->sanitize_field_name((string)$match[1][0]);
        if ($name === '' || !isset($choice_fields[$name])) {
            return false;
        }

        $options = (array)$choice_fields[$name];
        $option_keys = array_keys($options);
        $option_labels = array_values($options);
        $first = trim((string)($match[2][0] ?? ''));
        $second = trim((string)($match[3][0] ?? ''));
        if ($first === '') { $first = (string)($option_labels[0] ?? 'Igen'); }
        if ($second === '') { $second = (string)($option_labels[1] ?? 'Nem'); }
        $selected_key = sanitize_key((string)($values[$name . '__key'] ?? ''));
        $underline_first = isset($option_keys[0]) && $selected_key === (string)$option_keys[0];
        $underline_second = isset($option_keys[1]) && $selected_key === (string)$option_keys[1];

        $end = $start + strlen($token);
        $cursor = 0;
        $start_index = null;
        $end_index = null;
        $start_offset = 0;
        $end_offset = 0;
        foreach ($nodes as $index => $node) {
            $length = strlen($node->nodeValue);
            if ($start_index === null && $start >= $cursor && $start < $cursor + $length) {
                $start_index = $index;
                $start_offset = $start - $cursor;
            }
            if ($end_index === null && $end > $cursor && $end <= $cursor + $length) {
                $end_index = $index;
                $end_offset = $end - $cursor;
                break;
            }
            $cursor += $length;
        }
        if ($start_index === null || $end_index === null) { return false; }

        $prefix = substr($nodes[$start_index]->nodeValue, 0, $start_offset);
        $suffix = substr($nodes[$end_index]->nodeValue, $end_offset);
        $reference_text_node = $nodes[$start_index];
        $nodes[$start_index]->nodeValue = $prefix;
        for ($i = $start_index + 1; $i <= $end_index; $i++) { $nodes[$i]->nodeValue = ''; }

        $anchor = $this->docx_direct_paragraph_child($reference_text_node, $paragraph);
        if ($anchor === null || $anchor->parentNode === null) { return false; }
        $parent = $anchor->parentNode;
        foreach ([[$first, $underline_first], [' / ', false], [$second, $underline_second], [$suffix, false]] as $piece) {
            if ($piece[0] === '') { continue; }
            $run = $this->create_docx_text_run_node($document, $xpath, $reference_text_node, (string)$piece[0], (bool)$piece[1]);
            if ($run === null) { continue; }
            if ($anchor->nextSibling !== null) { $parent->insertBefore($run, $anchor->nextSibling); }
            else { $parent->appendChild($run); }
            $anchor = $run;
        }
        return true;
    }

    private function create_docx_text_run_node(DOMDocument $document, DOMXPath $xpath, DOMNode $reference_text_node, string $text, bool $underline): ?DOMNode
    {
        $ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
        $reference_run = $reference_text_node;
        while ($reference_run !== null && !($reference_run instanceof DOMElement && $reference_run->namespaceURI === $ns && $reference_run->localName === 'r')) {
            $reference_run = $reference_run->parentNode;
        }
        $run = $document->createElementNS($ns, 'w:r');
        $rpr = null;
        if ($reference_run instanceof DOMElement) {
            foreach ($reference_run->childNodes as $child) {
                if ($child instanceof DOMElement && $child->namespaceURI === $ns && $child->localName === 'rPr') {
                    $rpr = $child->cloneNode(true);
                    break;
                }
            }
        }
        if (!$rpr instanceof DOMElement && $underline) { $rpr = $document->createElementNS($ns, 'w:rPr'); }
        if ($rpr instanceof DOMElement && $underline) {
            foreach (iterator_to_array($rpr->childNodes) as $child) {
                if ($child instanceof DOMElement && $child->namespaceURI === $ns && $child->localName === 'u') { $rpr->removeChild($child); }
            }
            $u = $document->createElementNS($ns, 'w:u');
            $u->setAttributeNS($ns, 'w:val', 'single');
            $rpr->appendChild($u);
        }
        if ($rpr instanceof DOMElement) { $run->appendChild($rpr); }
        $t = $document->createElementNS($ns, 'w:t');
        $t->setAttribute('xml:space', 'preserve');
        $t->appendChild($document->createTextNode($text));
        $run->appendChild($t);
        return $run;
    }

    private function replace_token_in_docx_paragraph(DOMDocument $document, DOMXPath $xpath, DOMNode $paragraph, string $token, string $name, string $value, bool $blank, string $label): bool
    {
        $nodes = [];
        $combined = '';
        foreach ($xpath->query('.//w:t', $paragraph) as $text_node) {
            $nodes[] = $text_node;
            $combined .= $text_node->nodeValue;
        }
        $start = strpos($combined, $token);
        if ($start === false) {
            return false;
        }
        $end = $start + strlen($token);
        $cursor = 0;
        $start_index = null;
        $end_index = null;
        $start_offset = 0;
        $end_offset = 0;
        foreach ($nodes as $index => $node) {
            $length = strlen($node->nodeValue);
            if ($start_index === null && $start >= $cursor && $start < $cursor + $length) {
                $start_index = $index;
                $start_offset = $start - $cursor;
            }
            if ($end_index === null && $end > $cursor && $end <= $cursor + $length) {
                $end_index = $index;
                $end_offset = $end - $cursor;
                break;
            }
            $cursor += $length;
        }
        if ($start_index === null || $end_index === null) {
            return false;
        }

        $prefix = substr($nodes[$start_index]->nodeValue, 0, $start_offset);
        $suffix = substr($nodes[$end_index]->nodeValue, $end_offset);
        if (!$blank) {
            $nodes[$start_index]->nodeValue = $prefix . $this->docx_template_text_value($value) . ($start_index === $end_index ? $suffix : '');
            for ($i = $start_index + 1; $i <= $end_index; $i++) {
                $nodes[$i]->nodeValue = $i === $end_index ? $suffix : '';
            }
            return true;
        }

        $nodes[$start_index]->nodeValue = $prefix;
        for ($i = $start_index + 1; $i <= $end_index; $i++) {
            $nodes[$i]->nodeValue = $i === $end_index ? $suffix : '';
        }
        if ($start_index === $end_index) {
            $nodes[$start_index]->nodeValue = $prefix;
        }
        $direct_child = $this->docx_direct_paragraph_child($nodes[$start_index], $paragraph);
        if ($direct_child === null || $direct_child->parentNode === null) {
            return false;
        }
        $control = $this->create_docx_field_dom_node($document, $name, $label);
        if ($control === null) {
            return false;
        }
        if ($direct_child->nextSibling !== null) {
            $direct_child->parentNode->insertBefore($control, $direct_child->nextSibling);
        } else {
            $direct_child->parentNode->appendChild($control);
        }
        if ($start_index === $end_index && $suffix !== '') {
            $suffix_run = $direct_child->cloneNode(true);
            foreach ($xpath->query('.//w:t', $suffix_run) as $suffix_node) {
                $suffix_node->nodeValue = $suffix;
                break;
            }
            if ($control->nextSibling !== null) {
                $control->parentNode->insertBefore($suffix_run, $control->nextSibling);
            } else {
                $control->parentNode->appendChild($suffix_run);
            }
        }
        return true;
    }

    private function docx_direct_paragraph_child(DOMNode $node, DOMNode $paragraph): ?DOMNode
    {
        $current = $node;
        while ($current->parentNode !== null && $current->parentNode !== $paragraph) {
            $current = $current->parentNode;
        }
        return $current->parentNode === $paragraph ? $current : null;
    }

    private function create_docx_field_dom_node(DOMDocument $document, string $name, string $label): ?DOMNode
    {
        $fragment_doc = new DOMDocument();
        $field_xml = '<root xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' .
            $this->docx_field_run($name, $label, 'Kattints ide a kitöltéshez', ['color' => '777777']) . '</root>';
        if (!$fragment_doc->loadXML($field_xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING)) {
            return null;
        }
        $node = $fragment_doc->documentElement->firstChild;
        return $node ? $document->importNode($node, true) : null;
    }

    private function docx_template_text_value(string $value): string
    {
        return str_replace(["\r\n", "\r", "\n"], ' / ', $value);
    }

    private function docx_template_plain_value(string $value): string
    {
        return esc_html($this->docx_template_text_value($value));
    }

    private function create_testneveles_docx_file(array $v, bool $blank = false): string
    {
        return $this->create_docx_package($this->docx_testneveles_document($v, $blank));
    }

    private function create_docx_file(string $title, string $description, array $rows, bool $blank = false): string
    {
        return $this->create_docx_package($this->docx_document($title, $description, $rows, $blank));
    }

    private function create_docx_package(string $document_xml): string
    {
        $tmp = tempnam(sys_get_temp_dir(), 'szegbp-docx-');
        if ($tmp === false) {
            wp_die('Nem sikerült ideiglenes DOCX fájlt létrehozni.', 500);
        }

        $zip = new ZipArchive();
        if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
            wp_die('Nem sikerült DOCX csomagot létrehozni.', 500);
        }

        $zip->addFromString('[Content_Types].xml', $this->docx_content_types());
        $zip->addFromString('_rels/.rels', $this->docx_root_rels());
        $zip->addFromString('word/_rels/document.xml.rels', $this->docx_document_rels());
        $zip->addFromString('word/styles.xml', $this->docx_styles());
        $zip->addFromString('word/document.xml', $document_xml);
        $zip->close();

        return $tmp;
    }

    private function docx_testneveles_document(array $v, bool $blank = false): string
    {
        $body = '';

        $body .= $this->docx_paragraph_runs([
            $this->docx_value_run($v['igazgato_neve'] ?? '', 'igazgato_neve', 'Igazgató neve', $blank, '……………………………', ['underline' => true]),
            $this->docx_run(' igazgató részére    Intézményi ikt.sz.: '),
            $this->docx_value_run($v['iktatoszam'] ?? '', 'iktatoszam', 'Intézményi iktatószám', $blank, '……………………', ['underline' => true]),
        ], 'Normal');

        $body .= $this->docx_paragraph('Budapest I. Kerületi Szilágyi Erzsébet Gimnázium', 'SchoolHeader');
        $body .= $this->docx_paragraph('OM: 035219', 'SchoolHeader');
        $body .= $this->docx_paragraph('1016 Budapest, Mészáros utca 5-7.', 'SchoolHeader');

        $body .= $this->docx_paragraph('Felmentési kérelem', 'OfficialTitle', 'center');
        $body .= $this->docx_paragraph('a mindennapos testnevelés keretében megszervezett tanórán való részvétel alól', 'OfficialSubtitle', 'center');

        $body .= $this->docx_paragraph_runs([
            $this->docx_run('Alulírott '),
            $this->docx_value_run($v['szulo_neve'] ?? '', 'szulo_neve', 'Szülő / nagykorú tanuló neve', $blank, '………………………………………………', ['bold' => true, 'underline' => true]),
            $this->docx_run(' (szülő) a 2011. évi CXC. törvény 27. § (11) bekezdése alapján kérem hozzájárulását, hogy '),
            $this->docx_value_run($v['tanulo_neve'] ?? '', 'tanulo_neve', 'Tanuló neve', $blank, '………………………………………………', ['bold' => true, 'underline' => true]),
            $this->docx_run(' (gyermek, tanuló neve) '),
            $this->docx_value_run($v['osztaly'] ?? '', 'osztaly', 'Osztály', $blank, '…………', ['bold' => true, 'underline' => true]),
            $this->docx_run(' osztályos tanuló a mindennapos testnevelés keretében megszervezett heti öt testnevelés órából a '),
            $this->docx_value_run($v['kivaltott_nap'] ?? '', 'kivaltott_nap', 'Kiváltott nap', $blank, '………………', ['bold' => true, 'underline' => true]),
            $this->docx_run(' napon a '),
            $this->docx_value_run($v['ora_1'] ?? '', 'ora_1', 'Kiváltott testnevelésóra 1.', $blank, '……', ['bold' => true, 'underline' => true]),
            $this->docx_run('. órát'),
            $this->docx_run(' és a '),
            $this->docx_value_run($v['ora_2'] ?? '', 'ora_2', 'Kiváltott testnevelésóra 2.', $blank, '……', ['bold' => true, 'underline' => true]),
            $this->docx_run('. órát a heti edzéslátogatással válthassa ki.'),
        ], 'OfficialText');

        $body .= $this->docx_paragraph('Indoklás:', 'SectionTitle');
        $body .= $this->docx_paragraph_runs([
            $this->docx_run('Gyermekem igazolt sportolói jogviszonyban álló versenyző, versenyengedéllyel rendelkezik, a '),
            $this->docx_value_run($v['sportszervezet_neve'] ?? '', 'sportszervezet_neve', 'Sportszervezet / egyesület neve', $blank, '………………………………………………………………………………………………', ['bold' => true, 'underline' => true]),
            $this->docx_run(' sportszervezet keretei között szervezett heti '),
            $this->docx_value_run($v['edzes_alkalom'] ?? '', 'edzes_alkalom', 'Heti edzések száma', $blank, '……', ['bold' => true, 'underline' => true]),
            $this->docx_run(' alkalommal, '),
            $this->docx_value_run($v['edzes_napok'] ?? '', 'edzes_napok', 'Edzésnapok', $blank, '…………………………………………', ['bold' => true, 'underline' => true]),
            $this->docx_run(' napokon edzéslátogatáson vesz részt.'),
        ], 'OfficialText');

        $body .= $this->docx_signature_row(
            $this->docx_value_run($v['keltezes_datuma'] ?? '', 'keltezes_datuma', 'Kérelem dátuma', $blank, '………………………………', ['underline' => true]),
            'szülő / nagykorú tanuló aláírása'
        );

        $body .= $this->docx_paragraph('A versenyengedély bemutatása szükséges.', 'Small');
        $body .= $this->docx_paragraph('Sportszervezet igazolása', 'SectionTitle', 'center');
        $body .= $this->docx_paragraph('Igazolom, hogy a fent nevezett tanuló egyesületünkkel igazolt sportolói jogviszonyban álló, versenyengedéllyel rendelkező versenyzője, aki az alábbiak szerint vesz részt az edzéseken:', 'OfficialText');

        $body .= $this->docx_info_table([
            ['A sportszervezet/egyesület neve:', 'sportszervezet_neve', 'Sportszervezet / egyesület neve', $v['sportszervezet_neve'] ?? '', '…………………………………………………………'],
            ['A tanuló sportága:', 'sportag', 'A tanuló sportága', $v['sportag'] ?? '', '……………………………………………………………………'],
            ['Versenyengedély száma:', 'versenyengedely_szama', 'Versenyengedély száma', $v['versenyengedely_szama'] ?? '', '…………………………………………'],
            ['Versenyengedély érvényessége:', 'versenyengedely_ervenyesseg', 'Versenyengedély érvényessége', trim(($v['versenyengedely_ervenyes_tol'] ?? '') . ' - ' . ($v['versenyengedely_ervenyes_ig'] ?? '')), '202………………….-tól 202……………………-ig'],
            ['Az edző neve:', 'edzo_neve', 'Edző neve', $v['edzo_neve'] ?? '', '………………………………………………………………………'],
            ['A tanuló edzéseinek időpontjai:', 'edzes_idopontok', 'A tanuló edzéseinek időpontjai', $v['edzes_idopontok'] ?? '', '…… napon, …… napon, …… napon'],
        ], $blank);

        $body .= $this->docx_signature_row(
            $this->docx_value_run($v['sport_igazolas_datuma'] ?? '', 'sport_igazolas_datuma', 'Sportszervezeti igazolás dátuma', $blank, '………………………………', ['underline' => true]),
            'sportegyesület képviselőjének aláírása, bélyegzője'
        );

        return $this->docx_wrap_document($body, 720, 720, 720, 720);
    }

    private function docx_document(string $title, string $description, array $rows, bool $blank = false): string
    {
        $body = '';
        $body .= $this->docx_paragraph('Szilágyi Erzsébet Gimnázium', 'Subtitle');
        $body .= $this->docx_paragraph($title, 'Title');

        if ($description !== '') {
            $body .= $this->docx_paragraph($description, 'Normal');
        }

        $body .= '<w:tbl>';
        $body .= '<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="8800" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:left w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:right w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/></w:tblBorders></w:tblPr>';
        $body .= '<w:tblGrid><w:gridCol w:w="3200"/><w:gridCol w:w="5600"/></w:tblGrid>';

        foreach ($rows as $row) {
            $name = sanitize_key((string)($row['name'] ?? sanitize_title((string)$row['label'])));
            $label = (string)$row['label'];
            $value = trim((string)$row['value']);
            $body .= '<w:tr>';
            $body .= $this->docx_cell($label, true);
            if ($blank && $value === '') {
                $body .= $this->docx_cell_xml($this->docx_paragraph_runs([
                    $this->docx_field_run($name, $label, '……………………………………', ['underline' => true, 'color' => '777777']),
                ], 'Normal'));
            } else {
                $body .= $this->docx_cell($value !== '' ? $value : '—', false);
            }
            $body .= '</w:tr>';
        }
        $body .= '</w:tbl>';

        $body .= $this->docx_paragraph('', 'Normal');
        $body .= $this->docx_paragraph('Kelt: ________________________________', 'Normal');
        $body .= $this->docx_paragraph('', 'Normal');
        $body .= $this->docx_paragraph('________________________________        ________________________________', 'Normal');
        $body .= $this->docx_paragraph('szülő / gondviselő aláírása                 átvevő / ügyintéző', 'Small');

        return $this->docx_wrap_document($body, 1134, 1134, 1134, 1134);
    }

    private function docx_wrap_document(string $body, int $top, int $right, int $bottom, int $left): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">' .
            '<w:body>' . $body .
            '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="' . $top . '" w:right="' . $right . '" w:bottom="' . $bottom . '" w:left="' . $left . '" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>' .
            '</w:body></w:document>';
    }

    private function docx_signature_row(string $date_run_xml, string $signature_label): string
    {
        $p1 = $this->docx_paragraph_runs([
            $this->docx_run('Dátum: '),
            $date_run_xml,
        ], 'Normal');
        $p2 = $this->docx_paragraph('____________________________________', 'Normal', 'center');
        $p3 = $this->docx_paragraph($signature_label, 'Small', 'center');

        return '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders></w:tblPr>' .
            '<w:tblGrid><w:gridCol w:w="4300"/><w:gridCol w:w="5200"/></w:tblGrid><w:tr>' .
            $this->docx_cell_xml($p1, '4300') . $this->docx_cell_xml($p2 . $p3, '5200') .
            '</w:tr></w:tbl>';
    }

    private function docx_info_table(array $rows, bool $blank): string
    {
        $xml = '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders></w:tblPr>';
        $xml .= '<w:tblGrid><w:gridCol w:w="3600"/><w:gridCol w:w="5900"/></w:tblGrid>';
        foreach ($rows as $row) {
            [$label, $name, $alias, $value, $placeholder] = $row;
            $xml .= '<w:tr>';
            $xml .= $this->docx_cell_xml($this->docx_paragraph($label, 'TableLabel'), '3600');
            $xml .= $this->docx_cell_xml($this->docx_paragraph_runs([
                $this->docx_value_run((string)$value, (string)$name, (string)$alias, $blank, (string)$placeholder, ['underline' => true]),
            ], 'Normal'), '5900');
            $xml .= '</w:tr>';
        }
        $xml .= '</w:tbl>';
        return $xml;
    }

    private function docx_cell(string $text, bool $bold = false): string
    {
        return '<w:tc><w:tcPr><w:tcW w:w="0" w:type="auto"/><w:shd w:val="clear" w:color="auto" w:fill="' . ($bold ? 'F3F7ED' : 'FFFFFF') . '"/></w:tcPr>' .
            $this->docx_paragraph($text, $bold ? 'TableLabel' : 'Normal') .
            '</w:tc>';
    }

    private function docx_cell_xml(string $inner_xml, string $width = '0'): string
    {
        return '<w:tc><w:tcPr><w:tcW w:w="' . esc_attr($width) . '" w:type="dxa"/></w:tcPr>' . $inner_xml . '</w:tc>';
    }

    private function docx_paragraph(string $text, string $style = 'Normal', string $align = ''): string
    {
        return $this->docx_paragraph_runs([$this->docx_run($text)], $style, $align);
    }

    private function docx_paragraph_runs(array $runs, string $style = 'Normal', string $align = ''): string
    {
        $ppr = '';
        if ($style !== 'Normal' || $align !== '') {
            $ppr .= '<w:pPr>';
            if ($style !== 'Normal') {
                $ppr .= '<w:pStyle w:val="' . esc_attr($style) . '"/>';
            }
            if ($align !== '') {
                $ppr .= '<w:jc w:val="' . esc_attr($align) . '"/>';
            }
            $ppr .= '</w:pPr>';
        }
        return '<w:p>' . $ppr . implode('', $runs) . '</w:p>';
    }

    private function docx_value_run(string $value, string $name, string $label, bool $blank, string $placeholder, array $opts = []): string
    {
        $value = trim($value);
        if ($blank) {
            return $this->docx_field_run($name, $label, $placeholder, $opts);
        }
        return $this->docx_run($value !== '' ? $value : $placeholder, $opts);
    }

    private function docx_field_run(string $name, string $label, string $placeholder, array $opts = []): string
    {
        $id = (string)wp_rand(100000, 999999999);
        $tag = sanitize_key($name);
        return '<w:sdt><w:sdtPr><w:alias w:val="' . esc_attr($label) . '"/><w:tag w:val="' . esc_attr($tag) . '"/><w:id w:val="' . esc_attr($id) . '"/><w:showingPlcHdr/></w:sdtPr><w:sdtContent>' .
            $this->docx_run($placeholder, array_merge(['color' => '777777'], $opts)) .
            '</w:sdtContent></w:sdt>';
    }

    private function docx_run(string $text, array $opts = []): string
    {
        $rpr = '';
        if (!empty($opts['bold']) || !empty($opts['underline']) || !empty($opts['color']) || !empty($opts['size'])) {
            $rpr .= '<w:rPr>';
            if (!empty($opts['bold'])) {
                $rpr .= '<w:b/>';
            }
            if (!empty($opts['underline'])) {
                $rpr .= '<w:u w:val="single"/>';
            }
            if (!empty($opts['color'])) {
                $rpr .= '<w:color w:val="' . esc_attr((string)$opts['color']) . '"/>';
            }
            if (!empty($opts['size'])) {
                $rpr .= '<w:sz w:val="' . esc_attr((string)$opts['size']) . '"/>';
            }
            $rpr .= '</w:rPr>';
        }
        return '<w:r>' . $rpr . $this->docx_text($text) . '</w:r>';
    }

    private function docx_text(string $text): string
    {
        $parts = preg_split('/\R/u', $text);
        if (!$parts) {
            $parts = [''];
        }
        $xml = '';
        foreach ($parts as $index => $part) {
            if ($index > 0) {
                $xml .= '<w:br/>';
            }
            $xml .= '<w:t xml:space="preserve">' . esc_html($part) . '</w:t>';
        }
        return $xml;
    }

    private function docx_content_types(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' .
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' .
            '<Default Extension="xml" ContentType="application/xml"/>' .
            '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' .
            '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>' .
            '</Types>';
    }

    private function docx_root_rels(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' .
            '</Relationships>';
    }

    private function docx_document_rels(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' .
            '</Relationships>';
    }

    private function docx_styles(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' .
            '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:pPr><w:spacing w:after="60" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="21"/></w:rPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:color w:val="2E2257"/><w:sz w:val="34"/></w:rPr><w:pPr><w:spacing w:after="240"/></w:pPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:color w:val="5F7A48"/><w:sz w:val="22"/></w:rPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="SchoolHeader"><w:name w:val="SchoolHeader"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="0"/></w:pPr><w:rPr><w:sz w:val="20"/></w:rPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="OfficialTitle"><w:name w:val="OfficialTitle"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:before="140" w:after="40"/></w:pPr><w:rPr><w:b/><w:sz w:val="30"/></w:rPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="OfficialSubtitle"><w:name w:val="OfficialSubtitle"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="160"/></w:pPr><w:rPr><w:b/><w:sz w:val="21"/></w:rPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="OfficialText"><w:name w:val="OfficialText"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="80"/></w:pPr><w:rPr><w:sz w:val="20"/></w:rPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="SectionTitle"><w:name w:val="SectionTitle"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:before="80" w:after="60"/></w:pPr><w:rPr><w:b/><w:sz w:val="23"/></w:rPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="Small"><w:name w:val="Small"/><w:basedOn w:val="Normal"/><w:rPr><w:color w:val="666666"/><w:sz w:val="18"/></w:rPr><w:pPr><w:spacing w:after="40"/></w:pPr></w:style>' .
            '<w:style w:type="paragraph" w:styleId="TableLabel"><w:name w:val="TableLabel"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:color w:val="2E2257"/><w:sz w:val="20"/></w:rPr><w:pPr><w:spacing w:after="20"/></w:pPr></w:style>' .
            '<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:left w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:right w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="D9E6C6"/></w:tblBorders></w:tblPr></w:style>' .
            '</w:styles>';
    }

    private function get_preview_labels(array $form): array
    {
        $labels = [];
        foreach ($form['fields'] as $field) {
            if ((string)($field['type'] ?? '') === 'section') {
                continue;
            }
            $labels[(string)$field['name']] = (string)$field['label'];
        }
        return $labels;
    }

    private function get_forms(): array
    {
        $forms = $this->get_default_forms();
        $settings = get_option(self::OPTION_NAME, []);
        if (!is_array($settings)) {
            $settings = [];
        }

        $deleted_defaults = is_array($settings['_deleted_forms'] ?? null) ? $settings['_deleted_forms'] : [];
        $deleted_defaults = array_values(array_unique(array_filter(array_map('sanitize_key', $deleted_defaults))));

        foreach ($forms as $slug => &$form) {
            if (in_array($slug, $deleted_defaults, true)) {
                unset($forms[$slug]);
                continue;
            }
            $form['custom'] = false;
            if (isset($settings[$slug]) && is_array($settings[$slug])) {
                $form = $this->merge_saved_form_settings($form, $settings[$slug], false);
            }
        }
        unset($form);

        if (isset($settings['_custom_forms']) && is_array($settings['_custom_forms'])) {
            foreach ($settings['_custom_forms'] as $slug => $form) {
                $slug = sanitize_key((string)$slug);
                if ($slug === '' || isset($forms[$slug]) || !is_array($form)) {
                    continue;
                }
                $title = trim((string)($form['title'] ?? ''));
                if ($title === '') {
                    continue;
                }
                $forms[$slug] = $this->merge_saved_form_settings([
                    'custom' => true,
                    'enabled' => true,
                    'title' => $title,
                    'description' => '',
                    'fields' => [],
                ], $form, true);
            }
        }

        return $forms;
    }

    private function merge_saved_form_settings(array $form, array $saved, bool $custom): array
    {
        $form['custom'] = $custom;
        $form['enabled'] = !empty($saved['enabled']);
        if (isset($saved['title']) && trim((string)$saved['title']) !== '') {
            $form['title'] = (string)$saved['title'];
        }
        if (isset($saved['description'])) {
            $form['description'] = (string)$saved['description'];
        }
        if (isset($saved['fields']) && is_array($saved['fields']) && !empty($saved['fields'])) {
            $form['fields'] = $this->normalize_saved_fields($saved['fields']);
        }
        foreach (['docx_template', 'blank_docx', 'pdf_template', 'pdf_html_file', 'pdf_html_template', 'pdf_map_preview'] as $key) {
            if (isset($saved[$key])) {
                $form[$key] = (string)$saved[$key];
            }
        }
        if (isset($saved['pdf_field_map'])) {
            $form['pdf_field_map'] = $this->sanitize_pdf_field_map($saved['pdf_field_map'], (array)($form['fields'] ?? []));
        }
        if (isset($saved['template_origin'])) {
            $form['template_origin'] = sanitize_key((string)$saved['template_origin']);
        }
        if (isset($saved['docx_pairing_report']) && is_array($saved['docx_pairing_report'])) {
            $form['docx_pairing_report'] = $this->sanitize_docx_pairing_report($saved['docx_pairing_report']);
        }
        return $form;
    }

    private function normalize_saved_fields(array $fields): array
    {
        $definition = $this->fields_to_definition($fields);
        return $this->parse_fields_definition($definition, []);
    }

    private function get_default_forms(): array
    {
        return [
            'igazolasi-kerelem' => [
                'enabled' => true,
                'title' => 'Igazolási kérelem',
                'description' => 'Hiányzás, távollét vagy egyéb igazolási ügy nyomtatható kérelme.',
                'fields' => [
                    ['name' => 'tanulo_neve', 'label' => 'Tanuló neve', 'type' => 'text', 'required' => true, 'autocomplete' => 'name'],
                    ['name' => 'osztaly', 'label' => 'Osztály', 'type' => 'text', 'required' => true, 'placeholder' => 'pl. 9.A'],
                    ['name' => 'szulo_neve', 'label' => 'Szülő / gondviselő neve', 'type' => 'text', 'required' => true],
                    ['name' => 'datum_tol', 'label' => 'Érintett időszak kezdete', 'type' => 'date', 'required' => true],
                    ['name' => 'datum_ig', 'label' => 'Érintett időszak vége', 'type' => 'date', 'required' => false],
                    ['name' => 'ok', 'label' => 'Kérelem oka', 'type' => 'select', 'required' => true, 'options' => [
                        'betegseg' => 'Betegség',
                        'csaladi_ok' => 'Családi ok',
                        'verseny' => 'Verseny / iskolai program',
                        'egyeb' => 'Egyéb',
                    ]],
                    ['name' => 'indoklas', 'label' => 'Rövid indoklás', 'type' => 'textarea', 'required' => false],
                    ['name' => 'keltezes_helye', 'label' => 'Keltezés helye', 'type' => 'text', 'required' => false, 'placeholder' => 'Budapest'],
                    ['name' => 'keltezes_datuma', 'label' => 'Keltezés dátuma', 'type' => 'date', 'required' => false],
                ],
            ],
            'szuloi-kerelem' => [
                'enabled' => true,
                'title' => 'Szülői kérelem',
                'description' => 'Általános szülői kérelem, amely nyomtatható vagy DOCX-ként letölthető.',
                'fields' => [
                    ['name' => 'tanulo_neve', 'label' => 'Tanuló neve', 'type' => 'text', 'required' => true, 'autocomplete' => 'name'],
                    ['name' => 'osztaly', 'label' => 'Osztály', 'type' => 'text', 'required' => true, 'placeholder' => 'pl. 10.B'],
                    ['name' => 'szulo_neve', 'label' => 'Szülő / gondviselő neve', 'type' => 'text', 'required' => true],
                    ['name' => 'szulo_email', 'label' => 'Szülő e-mail-címe', 'type' => 'email', 'required' => false],
                    ['name' => 'kerelem_tipusa', 'label' => 'Kérelem típusa', 'type' => 'select', 'required' => true, 'options' => [
                        'tavollet' => 'Távollét engedélyezése',
                        'felmentes' => 'Felmentés kérése',
                        'adatmodositas' => 'Adatmódosítás',
                        'egyeb' => 'Egyéb kérelem',
                    ]],
                    ['name' => 'kerelem_szovege', 'label' => 'Kérelem szövege', 'type' => 'textarea', 'required' => true, 'placeholder' => 'Írd le röviden a kérelem lényegét.'],
                    ['name' => 'keltezes_helye', 'label' => 'Keltezés helye', 'type' => 'text', 'required' => false, 'placeholder' => 'Budapest'],
                    ['name' => 'keltezes_datuma', 'label' => 'Keltezés dátuma', 'type' => 'date', 'required' => false],
                ],
            ],
            'adatvaltozas-bejelento' => [
                'enabled' => true,
                'title' => 'Adatváltozás bejelentő',
                'description' => 'Lakcím, telefonszám, e-mail-cím vagy más fontos adat változásának bejelentése.',
                'fields' => [
                    ['name' => 'tanulo_neve', 'label' => 'Tanuló neve', 'type' => 'text', 'required' => true, 'autocomplete' => 'name'],
                    ['name' => 'osztaly', 'label' => 'Osztály', 'type' => 'text', 'required' => true, 'placeholder' => 'pl. 11.C'],
                    ['name' => 'szulo_neve', 'label' => 'Bejelentő neve', 'type' => 'text', 'required' => true],
                    ['name' => 'valtozas_tipusa', 'label' => 'Változás típusa', 'type' => 'select', 'required' => true, 'options' => [
                        'lakcim' => 'Lakcím',
                        'email' => 'E-mail-cím',
                        'telefon' => 'Telefonszám',
                        'gondviselo' => 'Gondviselői adat',
                        'egyeb' => 'Egyéb adat',
                    ]],
                    ['name' => 'uj_adat', 'label' => 'Új / módosított adat', 'type' => 'textarea', 'required' => true],
                    ['name' => 'ervenyesseg_datuma', 'label' => 'Érvényesség kezdete', 'type' => 'date', 'required' => false],
                    ['name' => 'megjegyzes', 'label' => 'Megjegyzés', 'type' => 'textarea', 'required' => false],
                    ['name' => 'keltezes_helye', 'label' => 'Keltezés helye', 'type' => 'text', 'required' => false, 'placeholder' => 'Budapest'],
                    ['name' => 'keltezes_datuma', 'label' => 'Keltezés dátuma', 'type' => 'date', 'required' => false],
                ],
            ],
            'testneveles-felmentes' => [
                'enabled' => true,
                'title' => 'Mindennapos testnevelés felmentési kérelem',
                'description' => 'Sportolói jogviszony és versenyengedély alapján kérhető felmentés egyes testnevelésórák látogatása alól.',
                'pdf_file' => 'testneveles_felmentes.pdf',
                'fields' => [
                    ['name' => 'igazgato_neve', 'label' => 'Igazgató neve', 'type' => 'text', 'required' => false, 'placeholder' => 'pl. Dr. Minta Mária'],
                    ['name' => 'iktatoszam', 'label' => 'Intézményi iktatószám', 'type' => 'text', 'required' => false, 'placeholder' => 'Ezt az iskola töltheti ki'],
                    ['name' => 'szulo_neve', 'label' => 'Szülő / nagykorú tanuló neve', 'type' => 'text', 'required' => true],
                    ['name' => 'tanulo_neve', 'label' => 'Tanuló neve', 'type' => 'text', 'required' => true, 'autocomplete' => 'name'],
                    ['name' => 'osztaly', 'label' => 'Osztály', 'type' => 'text', 'required' => true, 'placeholder' => 'pl. 9.A'],
                    ['name' => 'kivaltott_nap', 'label' => 'Melyik napon váltja ki az órát?', 'type' => 'select', 'required' => true, 'options' => [
                        'hétfő' => 'hétfő',
                        'kedd' => 'kedd',
                        'szerda' => 'szerda',
                        'csütörtök' => 'csütörtök',
                        'péntek' => 'péntek',
                    ]],
                    ['name' => 'ora_1', 'label' => 'Kiváltott testnevelésóra 1.', 'type' => 'number', 'required' => true, 'placeholder' => 'pl. 6'],
                    ['name' => 'ora_2', 'label' => 'Kiváltott testnevelésóra 2.', 'type' => 'number', 'required' => false, 'placeholder' => 'pl. 7'],
                    ['name' => 'sportszervezet_neve', 'label' => 'Sportszervezet / egyesület neve', 'type' => 'text', 'required' => true],
                    ['name' => 'edzes_alkalom', 'label' => 'Heti edzések száma', 'type' => 'number', 'required' => true, 'placeholder' => 'pl. 3'],
                    ['name' => 'edzes_napok', 'label' => 'Edzésnapok', 'type' => 'text', 'required' => true, 'placeholder' => 'pl. hétfőn, szerdán és pénteken'],
                    ['name' => 'keltezes_datuma', 'label' => 'Kérelem dátuma', 'type' => 'date', 'required' => true],
                    ['name' => 'sportag', 'label' => 'A tanuló sportága', 'type' => 'text', 'required' => true],
                    ['name' => 'versenyengedely_szama', 'label' => 'Versenyengedély száma', 'type' => 'text', 'required' => true],
                    ['name' => 'versenyengedely_ervenyes_tol', 'label' => 'Versenyengedély érvényes -tól', 'type' => 'date', 'required' => true],
                    ['name' => 'versenyengedely_ervenyes_ig', 'label' => 'Versenyengedély érvényes -ig', 'type' => 'date', 'required' => true],
                    ['name' => 'edzo_neve', 'label' => 'Edző neve', 'type' => 'text', 'required' => true],
                    ['name' => 'edzes_idopontok', 'label' => 'A tanuló edzéseinek időpontjai', 'type' => 'textarea', 'required' => true, 'placeholder' => 'pl. hétfő 17:00, szerda 17:30, péntek 16:00'],
                    ['name' => 'sport_igazolas_datuma', 'label' => 'Sportszervezeti igazolás dátuma', 'type' => 'date', 'required' => false],
                ],
            ],

        ];
    }



    public function register_file_transfers($file_transfers = null): void
    {
        if (!is_object($file_transfers) || !method_exists($file_transfers, 'register')) {
            return;
        }
        $file_transfers->register('szegbp-forms.template-upload', [
            'label' => 'Űrlap sablonfájl feltöltése',
            'module' => 'szegbp-forms',
            'group' => 'Űrlapok és Nyomtatványok',
            'description' => 'DOCX/PDF/HTML sablonfájlt rendel a kiválasztott űrlaphoz a meglévő sablonkezelő logikával.',
            'direction' => 'upload',
            'accepts' => ['docx', 'pdf', 'html', 'htm'],
            'max_size_mb' => 8,
            'capability' => $this->content_menu_capability(),
            'params' => [
                'form_slug' => [
                    'type' => 'select',
                    'label' => 'Űrlap',
                    'required' => true,
                    'options' => $this->platform_form_options(),
                ],
                'template_type' => [
                    'type' => 'select',
                    'label' => 'Sablon típusa',
                    'default' => 'docx',
                    'options' => [
                        'docx' => 'DOCX sablon',
                        'pdf' => 'PDF nyomtatvány',
                        'html' => 'PDF HTML sablon',
                    ],
                ],
            ],
        ], [$this, 'handle_platform_template_upload']);
    }

    private function platform_form_options(): array
    {
        $options = [];
        foreach ($this->get_forms() as $slug => $form) {
            $options[(string)$slug] = (string)($form['title'] ?? $slug);
        }
        return $options;
    }

    public function handle_platform_template_upload($file, array $params = []): array
    {
        if (!$this->can_manage_content()) {
            return ['status' => 'error', 'message' => 'Nincs jogosultság.'];
        }
        $slug = isset($params['form_slug']) ? sanitize_key((string)wp_unslash($params['form_slug'])) : '';
        $type = isset($params['template_type']) ? sanitize_key((string)wp_unslash($params['template_type'])) : 'docx';
        if (!in_array($type, ['docx', 'pdf', 'html'], true)) {
            $type = 'docx';
        }
        $forms = $this->get_forms();
        if ($slug === '' || !isset($forms[$slug])) {
            return ['status' => 'error', 'message' => 'A kiválasztott űrlap nem található.'];
        }
        if (!is_array($file) || empty($file['tmp_name']) || empty($file['name'])) {
            return ['status' => 'error', 'message' => 'Nem érkezett sablonfájl.'];
        }
        $extension = strtolower((string)pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        if (($type === 'docx' && $extension !== 'docx') || ($type === 'pdf' && $extension !== 'pdf') || ($type === 'html' && !in_array($extension, ['html', 'htm'], true))) {
            return ['status' => 'error', 'message' => 'A fájl kiterjesztése nem illik a kiválasztott sablontípushoz.'];
        }
        $settings = get_option(self::OPTION_NAME, []);
        $settings = is_array($settings) ? $settings : [];
        $target_is_custom = !empty($forms[$slug]['custom']);
        if ($target_is_custom) {
            if (!isset($settings['_custom_forms'][$slug]) || !is_array($settings['_custom_forms'][$slug])) {
                $settings['_custom_forms'][$slug] = $forms[$slug];
            }
            $target =& $settings['_custom_forms'][$slug];
        } else {
            if (!isset($settings[$slug]) || !is_array($settings[$slug])) {
                $settings[$slug] = $forms[$slug];
            }
            $target =& $settings[$slug];
        }
        $messages = [];
        $input_name = 'szegbp_forms_platform_template_upload';
        $_FILES[$input_name] = [
            'name' => (string)$file['name'],
            'type' => (string)($file['type'] ?? ''),
            'tmp_name' => (string)$file['tmp_name'],
            'error' => UPLOAD_ERR_OK,
            'size' => (int)($file['size'] ?? 0),
        ];
        $stored = $this->store_uploaded_template_file($input_name, $slug, $type, $messages, (string)($forms[$slug]['title'] ?? $slug));
        unset($_FILES[$input_name]);
        if ($stored === '') {
            return ['status' => 'warning', 'message' => $messages ? implode(' ', $messages) : 'A sablonfájl feltöltése nem sikerült.'];
        }
        if ($type === 'docx') {
            $this->delete_stored_template_file((string)($target['docx_template'] ?? ''));
            $target['docx_template'] = $stored;
        } elseif ($type === 'pdf') {
            $this->delete_stored_template_file((string)($target['pdf_template'] ?? ''));
            $target['pdf_template'] = $stored;
        } else {
            $this->delete_stored_template_file((string)($target['pdf_html_file'] ?? ''));
            $target['pdf_html_file'] = $stored;
            $html_file = $this->get_template_file_from_relative($stored, 'html');
            if ($html_file !== null) {
                $contents = file_get_contents($html_file['path']); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
                if (is_string($contents)) {
                    $target['pdf_html_template'] = $this->sanitize_pdf_html_template($contents);
                }
            }
        }
        unset($target);
        update_option(self::OPTION_NAME, $settings, false);
        $this->platform_log('info', 'Űrlap sablonfájl feltöltve Platform Adatbetöltésekből.', ['slug' => $slug, 'template_type' => $type, 'file' => $stored]);
        return ['status' => 'ok', 'message' => 'Sablonfájl feltöltve és hozzárendelve: ' . $slug . ' / ' . strtoupper($type) . '.'];
    }

    public function register_platform_services(): void
    {
        if (!function_exists('szegbp_platform_register_plugin')) {
            return;
        }

        szegbp_platform_register_plugin('szegbp-forms', [
            'name' => 'SZEGBP Űrlapok és Nyomtatványok',
            'version' => self::VERSION,
            'type' => 'module',
            'status' => 'active',
            'source' => 'plugin',
            'admin_url' => admin_url('admin.php?page=szegbp-forms'),
            'description' => 'Böngészőben kitölthető, letölthető és nyomtatható iskolai nyomtatványok.',
            'requires' => [
                'szegbp-platform-services' => '1.5.2',
            ],
        ]);
    }

    private function platform_available(): bool
    {
        return function_exists('szegbp_platform');
    }

    private function platform_log(string $level, string $message, array $context = []): void
    {
        if (!function_exists('szegbp_platform')) {
            return;
        }

        $context = array_merge([
            'module' => 'szegbp-forms',
            'version' => self::VERSION,
        ], $context);

        szegbp_platform()->logger()->log($level, $message, $context);
    }

    private function platform_status_data(): array
    {
        $forms = $this->get_forms();
        $enabled = 0;
        $custom = 0;
        $with_docx_template = 0;
        $with_pdf_template = 0;

        foreach ($forms as $form) {
            if (!empty($form['enabled'])) {
                $enabled++;
            }
            if (!empty($form['custom'])) {
                $custom++;
            }
            if (!empty($form['docx_template'])) {
                $with_docx_template++;
            }
            if (!empty($form['pdf_template']) || !empty($form['pdf_file'])) {
                $with_pdf_template++;
            }
        }

        $storage = $this->get_template_storage();

        return [
            'platform' => $this->platform_available(),
            'forms_total' => count($forms),
            'forms_enabled' => $enabled,
            'forms_custom' => $custom,
            'docx_templates' => $with_docx_template,
            'pdf_templates' => $with_pdf_template,
            'storage_dir' => (string)($storage['dir'] ?? ''),
            'storage_writable' => !empty($storage['dir']) && wp_mkdir_p((string)$storage['dir']) && is_writable((string)$storage['dir']),
            'ziparchive' => class_exists('ZipArchive'),
            'domdocument' => class_exists('DOMDocument'),
        ];
    }

    private function render_platform_status_card(): void
    {
        $status = $this->platform_status_data();
        ?>
        <section class="szegbp-admin-card szegbp-forms-admin-card" style="margin:16px 0;">
            <div class="szegbp-forms-card-header">
                <div>
                    <h2>Platform Services kapcsolat</h2>
                    <p class="description">A modul a központi SZEGBP Platform Services Registry és Logger szolgáltatásait használja, ha a Platform aktív.</p>
                </div>
                <span class="szegbp-admin-version"><?php echo $status['platform'] ? 'Platform aktív' : 'Platform nem aktív'; ?></span>
            </div>
            <table class="widefat striped" style="margin-top:10px;">
                <tbody>
                    <tr><th>Registry slug</th><td><code>szegbp-forms</code></td></tr>
                    <tr><th>Platform Adatbetöltések</th><td>DOCX/PDF/HTML sablonfeltöltés regisztrálva, ha a Platform Services v1.5.2+ aktív.</td></tr>
                    <tr><th>Modulverzió</th><td><?php echo esc_html(self::VERSION); ?></td></tr>
                    <tr><th>Űrlapok összesen / engedélyezve</th><td><?php echo esc_html((string)$status['forms_total']); ?> / <?php echo esc_html((string)$status['forms_enabled']); ?></td></tr>
                    <tr><th>Egyedi űrlapok</th><td><?php echo esc_html((string)$status['forms_custom']); ?></td></tr>
                    <tr><th>Sablontároló írható</th><td><?php echo $status['storage_writable'] ? 'Igen' : 'Nem'; ?></td></tr>
                    <tr><th>DOCX motor</th><td><?php echo $status['ziparchive'] ? 'ZipArchive elérhető' : 'ZipArchive hiányzik'; ?>, <?php echo $status['domdocument'] ? 'DOMDocument elérhető' : 'DOMDocument hiányzik'; ?></td></tr>
                </tbody>
            </table>
        </section>
        <?php
    }

    public function render_platform_page(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Nincs jogosultságod az oldal megtekintéséhez.', 'szegbp-forms'));
        }

        $status = $this->platform_status_data();
        ?>
        <div class="wrap szegbp-admin-page szegbp-forms-admin">
            <h1>Űrlapok és nyomtatványok – Platform Services</h1>
            <p class="description">Állapotkép a központi Platform Services integrációhoz. A nyilvános űrlapkitöltés és a letöltések személyes adatai nem kerülnek a Platform naplóba.</p>
            <section class="szegbp-admin-card szegbp-forms-admin-card" style="margin-top:16px;">
                <h2>Kapcsolat és diagnosztika</h2>
                <table class="widefat striped">
                    <tbody>
                        <tr><th>Platform Services</th><td><?php echo $status['platform'] ? 'Elérhető' : 'Nem elérhető'; ?></td></tr>
                        <tr><th>Registry slug</th><td><code>szegbp-forms</code></td></tr>
                        <tr><th>Modulverzió</th><td><?php echo esc_html(self::VERSION); ?></td></tr>
                        <tr><th>Űrlapok összesen</th><td><?php echo esc_html((string)$status['forms_total']); ?></td></tr>
                        <tr><th>Engedélyezett űrlapok</th><td><?php echo esc_html((string)$status['forms_enabled']); ?></td></tr>
                        <tr><th>Egyedi űrlapok</th><td><?php echo esc_html((string)$status['forms_custom']); ?></td></tr>
                        <tr><th>DOCX sablonnal rendelkező űrlapok</th><td><?php echo esc_html((string)$status['docx_templates']); ?></td></tr>
                        <tr><th>PDF sablonnal vagy PDF fájllal rendelkező űrlapok</th><td><?php echo esc_html((string)$status['pdf_templates']); ?></td></tr>
                        <tr><th>Sablontároló</th><td><code><?php echo esc_html($status['storage_dir']); ?></code></td></tr>
                        <tr><th>Sablontároló írható</th><td><?php echo $status['storage_writable'] ? 'Igen' : 'Nem'; ?></td></tr>
                        <tr><th>DOCX generáláshoz szükséges bővítmények</th><td><?php echo $status['ziparchive'] ? 'ZipArchive OK' : 'ZipArchive hiányzik'; ?> / <?php echo $status['domdocument'] ? 'DOMDocument OK' : 'DOMDocument hiányzik'; ?></td></tr>
                    </tbody>
                </table>
            </section>
        </div>
        <?php
    }

    private function format_date_value(string $value): string
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return $value;
        }
        [$y, $m, $d] = explode('-', $value);
        return $y . '. ' . $m . '. ' . $d . '.';
    }
}


/**
 * Az Űrlapok modul saját capability-jének bejelentése a közös
 * SZEGBP Jogosultságkezelő modulregiszterébe.
 *
 * A callback csak akkor végez regisztrációt, ha a Jogosultságkezelő aktív.
 * A plugin önállóan is működőképes marad: az adminisztrátor számára a
 * manage_options kompatibilitási hozzáférés továbbra is rendelkezésre áll.
 */
if (!function_exists('szegbp_forms_register_permission_module')) {
    function szegbp_forms_register_permission_module(): void
    {
        if (!function_exists('szegbp_permissions_register_module')) {
            return;
        }

        szegbp_permissions_register_module('forms', [
            'label'         => 'SZEGBP Űrlapok és Nyomtatványok',
            'short_label'   => 'Űrlapok',
            'capability'    => SZEGBP_Forms_Plugin::CONTENT_CAPABILITY,
            'plugin_file'   => plugin_basename(__FILE__),
            'default_roles' => [
                'editor',
                'szegbp_tartalomkezelo',
                'administrator',
            ],
        ]);
    }
}
add_action('szegbp_permissions_register_modules', 'szegbp_forms_register_permission_module');

SZEGBP_Forms_Plugin::instance();
